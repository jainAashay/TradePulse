# delta-agent — Agentic Trading Bot for Delta Exchange

A 24/7 autonomous trading agent for Delta Exchange perpetual futures. Uses local technical analysis to filter entry signals, invokes an LLM (Gemini via LiteLLM) for CoT-based decisions, enforces hard risk rules, executes bracket orders, monitors active positions on every closed candle for early exit, and continuously learns from closed trades via ChromaDB vector memory.

---

## System Diagram

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║                          DELTA AGENT — 24/7 RUNTIME                            ║
╚══════════════════════════════════════════════════════════════════════════════════╝

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                        STAGE 1 — MARKET DATA & SCREENER                     │
  │                                                                             │
  │   Delta Exchange WebSocket (wss://)                                         │
  │   ┌─────────────────────────────┐                                           │
  │   │  candlestick_1m / _5m feed  │  auto-reconnect (exp backoff 1s→60s)     │
  │   └────────────┬────────────────┘                                           │
  │                │ closed bar only                                             │
  │                ▼                                                             │
  │   ┌────────────────────┐    push()    ┌─────────────────────────────────┐  │
  │   │     DeltaFeed      │ ──────────▶  │  BarStore (deque maxlen=200*)   │  │
  │   │   (feed.py)        │              │  keyed by (symbol, timeframe)   │  │
  │   └────────────────────┘              └──────────────┬──────────────────┘  │
  │                                                       │ get_df()            │
  │                                                       ▼                     │
  │                                        ┌─────────────────────────┐         │
  │                                        │   IndicatorRunner       │         │
  │                                        │   EMA · RSI · MACD      │         │
  │                                        │   Bollinger · CrossEvt  │         │
  │                                        └──────────────┬──────────┘         │
  │                                                       │ signals dict        │
  │                                                       ▼                     │
  │                                   open position?                            │
  │                                  ┌──────┴──────┐                           │
  │                                 YES            NO                           │
  │                                  │              │                           │
  │                                  │              ▼                           │
  │                                  │   ┌─────────────────────┐               │
  │                                  │   │    TriggerGate      │               │
  │                                  │   │ Python rule registry│               │
  │                                  │   │ YAML thresholds     │               │
  │                                  │   │ cooldown + dedup    │               │
  │                                  │   └──────────┬──────────┘               │
  │                                  │              │                           │
  │                    push directly │    TriggerEvent (rule_matched)           │
  │                    every candle  │              │                           │
  │                    (watch_mode)  │              │                           │
  └──────────────────────────────────┴──────────────┼──────────────────────────┘
                                                     │
  ┌──────────────────────────────────────────────────▼──────────────────────────┐
  │                   STAGE 2 — AGENT LOOP (two-mode state machine)              │
  │                                                                             │
  │   on TriggerEvent:                                                          │
  │   ┌───────────────────────────────────────────────────────────────────────┐ │
  │   │  open position for symbol?                                            │ │
  │   │         │                                                             │ │
  │   │    ┌────┴────┐                                                        │ │
  │   │   YES        NO                                                       │ │
  │   │    │          │                                                        │ │
  │   │    ▼          ▼                                                        │ │
  │   │ WATCH MODE  SCAN MODE                                                  │ │
  │   │ every candle  rule-gated                                               │ │
  │   └────┬──────────┬────────────────────────────────────────────────────────┘ │
  │        │          │                                                           │
  └────────┼──────────┼───────────────────────────────────────────────────────────┘
           │          │
  ┌────────────────────────────────────────────────────────────────────────────────┐
  │                    ANALYZER (LLM BRAIN) — both modes                          │
  │                                                                               │
  │   Context Assembly (shared)                                                   │
  │   ┌──────────────────┐  ┌───────────────────────┐  ┌───────────────────────┐ │
  │   │   Indicators     │  │  NewsCache            │  │  ChromaDB RAG         │ │
  │   │  EMA 9/21/50/200 │  │  CryptoNews API       │  │  top-K lessons        │ │
  │   │  RSI 14          │  │  age + sentiment       │  │  injected FIRST       │ │
  │   │  MACD line/sig/  │  │  poll 60s / TTL 2m    │  │                       │ │
  │   │    hist + cross  │  │  hard cap 1000 chars  │  │                       │ │
  │   │  Bollinger upper/│  └──────────┬────────────┘  └──────────┬────────────┘ │
  │   │    lower/mid/%B/ │             │                           │              │
  │   │    bandwidth     │             └──────────────┬────────────┘              │
  │   │  ATR 14          │                            │                           │
  │   │  VWAP            │◀── live signals ───────────┘                           │
  │   │  Stoch %K/%D +   │                            │                           │
  │   │    cross         │                            ▼                           │
  │   │  Cross events:   │             ┌──────────────────────────┐               │
  │   │  · ema_cross_up  │             │      System Prompt       │               │
  │   │  · ema_cross_dn  │             │  [1] Prior Lessons (RAG) │               │
  │   │  · ema_trend_    │             │  [2] Indicators (all)    │               │
  │   │    bullish       │             │  [3] News + timestamps   │               │
  │   │  · ema_longterm_ │             │                          │               │
  │   │    bullish       │   SCAN MODE │  [4] Risk Parameters     │               │
  │   │  · macd_cross_up │  ──────────▶  WATCH MODE adds:        │               │
  │   │  · macd_cross_dn │             │  [5] Entry price         │               │
  │   │  · macd_above_   │             │  [6] Current price       │               │
  │   │    zero          │             │  [7] Unrealised PnL%     │               │
  │   │  · stoch_cross_  │             │  [8] Time held (mins)    │               │
  │   │    up/down       │             │  [9] SL / TP levels      │               │
  │   └──────────────────┘             └──────────────┬───────────┘               │
  │                                                   │                           │
  │                                    ┌──────────────▼──────────┐                │
  │                                    │  LLM (Gemini/LiteLLM)   │                │
  │                                    │  CoT → JSON decision     │                │
  │                                    └──────────────┬──────────┘                │
  │                                                   │                           │
  │              SCAN MODE returns:    LONG / SHORT / HOLD                        │
  │              WATCH MODE returns:   HOLD / EXIT                                │
  └────────────────────────────────────────────────────────────────────────────────┘
        │                                    │
        │ EXIT                               │ LONG / SHORT
        ▼                                    ▼
  cancel bracket             ┌──────────────────────────────────────────────────┐
  market close               │              STAGE 3 — RISK ENGINE               │
  → reflection               │  ✓ confidence · leverage · positions · daily     │
                             │    orders · daily loss · consecutive losses       │
                             │    circuit breaker · trading_enabled              │
                             └────────────────────┬─────────────────────────────┘
                                                  │ APPROVED
                                                  ▼
                             ┌──────────────────────────────────────────────────┐
                             │              STAGE 4 — EXECUTION                  │
                             │  bracket order: entry + SL + TP                  │
                             │  persist → SQLite · timeout watcher               │
                             │  Telegram alert                                   │
                             └────────────────────┬─────────────────────────────┘
                                                  │ trade closes
                                                  ▼
                             ┌──────────────────────────────────────────────────┐
                             │           STAGE 5 — REFLECTION & LEARNING         │
                             │  batch fills poll → intersect unreflected orders  │
                             │  LLM post-mortem → compact lesson → ChromaDB      │
                             │  mark_reflected() · update risk counters          │
                             └──────────────────────────────────────────────────┘
                                      │ lessons loop back into Stage 2 RAG ▲
                                      └─────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════════
  BACKGROUND SERVICES (always running in parallel)
═══════════════════════════════════════════════════════════════════════════════════

  ┌─────────────────────┐   ┌──────────────────────┐   ┌──────────────────────┐
  │   NewsPoller        │   │  TelegramBot          │   │  Health Server       │
  │                     │   │                       │   │                      │
  │  CryptoNews API     │   │  /pause  → DB flag    │   │  GET /health         │
  │  poll every 60s*    │   │  /resume → DB flag    │   │  POST /reset-cb      │
  │  TTL cache 120s*    │   │  /status → live state │   │  port :8080          │
  │  age label per item │   │  /reset  → clear CB   │   │                      │
  └─────────────────────┘   └──────────────────────┘   └──────────────────────┘

  * configurable via news.poll_interval_seconds / news.cache_ttl_seconds

═══════════════════════════════════════════════════════════════════════════════════
  PERSISTENCE (SQLite — survives restarts)
═══════════════════════════════════════════════════════════════════════════════════

  analysis_cycles   IN_FLIGHT cycles → marked CRASHED on restart (no double-entry)
  orders            PENDING→OPEN→CLOSED + PnL + reflected flag; reconciled on startup
  risk_state        daily counters recomputed from orders table on startup
  agent_config      trading_enabled flag (Telegram-controlled, persists across restarts)

  * bar_history_size configurable in settings.yaml (default 200)
```

---

## Two-Mode Agent Loop

The core innovation of delta-agent is that the LLM has **full visibility into active trades** and can act on them in real time.

| Mode | When active | Trigger | LLM decision |
|---|---|---|---|
| **Scan** | No open position for symbol | Rule fires (RSI, EMA cross, momentum, etc.) + cooldown elapsed | `LONG` / `SHORT` / `HOLD` |
| **Watch** | Open position exists for symbol | Every closed candle — no rule gate, no cooldown | `HOLD` / `EXIT` |

**Watch mode injects into the prompt:**
- Entry price, current price, unrealised PnL%
- Time held (minutes)
- Stop-loss and take-profit levels
- Live indicator values and timestamped news

If the LLM returns `EXIT`, the agent cancels the bracket order and closes the position at market immediately. The outcome feeds into reflection and ChromaDB as a richer lesson than a bare SL hit.

---

## Key Design Decisions

| Topic | Decision |
|---|---|
| Exchange API | CCXT async for balance/positions/orders/cancel; Delta REST (`/v2/orders`) for bracket orders and market close |
| WebSocket | Native `websockets` lib; auto-reconnect with exponential backoff (1s→60s cap) |
| Trigger rules | Python function registry (`@rule("name")` decorator); thresholds per symbol in `watchlist.yaml`; OR semantics by default |
| Trigger dedup | Latest-wins map per symbol — stale pending triggers replaced, no queue backlog |
| Two-mode loop | Scan mode = rule-gated entry; Watch mode = every candle while position open, LLM can call early EXIT |
| Early exit | Cancel bracket + `reduce_only` market order; reflected into ChromaDB as a learning event |
| LLM provider | Gemini via LiteLLM; swap model/provider in `settings.yaml` with no code changes |
| Vector memory | ChromaDB + `all-MiniLM-L6-v2` local embeddings; lessons ≤400 chars; injected at top of system prompt |
| Position sizing | Fixed `quantity` + `leverage` from `watchlist.yaml` |
| Risk engine | Stateless validator; daily counters recomputed from SQLite on startup |
| Reflection dedup | `reflected` flag in SQLite; `mark_reflected()` only after ChromaDB write succeeds; `replay_unreflected()` on startup |
| Fills API | Batch call capped at `fills_lookback_hours` (default 24h) |
| Restart resilience | `IN_FLIGHT` cycles crashed on boot; order reconciliation; trading_enabled persisted in SQLite |
| Kill switch | Telegram `/pause /resume /status /reset` — no redeploy needed |
| News | CryptoNews API; poll interval + TTL configurable; age label per headline; hard char cap on prompt injection |
| Cloud | Docker + supervisord; `data/` volume for SQLite + ChromaDB persistence |

---

## Package Structure

```
src/delta_agent/
  config/           YAML + env config, watchlist, RiskConfig, ScreenerConfig, NewsConfig
  screener/         bar_store.py, feed.py, indicators.py, rules.py, trigger.py
  analyzer/         context.py (OpenPosition + dual-mode), prompts.py (scan + watch), decision.py
  risk/             engine.py (stateless validator), state.py (SQLite-persisted counters)
  agent/            loop.py (scan mode + watch mode state machine)
  execution/        client.py (CCXT + Delta REST + close_position), manager.py (exit_position), orders.py
  reflection/       detector.py (batch fills + intersection), pipeline.py (post-mortem → ChromaDB)
  memory/           protocols.py, chroma_store.py (ChromaDB), stub.py
  llm/              protocols.py, litellm_client.py, factory.py, langchain_bridge.py
  news/             poller.py (CryptoNews API + NewsCache with configurable TTL)
  health/           server.py (FastAPI /health), alerter.py (Telegram), telegram_bot.py
  persistence/      db.py (SQLite: analysis_cycles, orders, risk_state, agent_config)
  logging_setup.py  structlog JSON logs
  __main__.py       boots all subsystems, runs asyncio.gather
```

---

## SQLite Tables

| Table | Purpose |
|---|---|
| `analysis_cycles` | Per-trigger cycle state (`IN_FLIGHT`→`COMPLETED`/`REJECTED`/`CRASHED`) for crash recovery |
| `orders` | Full order lifecycle (PENDING→OPEN→CLOSED), PnL, `reflected` flag for dedup |
| `risk_state` | Daily counters: orders placed, loss USD, consecutive losses, circuit breaker flag |
| `agent_config` | Runtime flags: `trading_enabled` (toggled via Telegram) |

---

## Indicators

All indicators are computed on every closed candle and passed to the LLM in both scan and watch mode.

**Scalar values:**

| Indicator | Signal key(s) | Description |
|---|---|---|
| EMA | `ema_9`, `ema_21`, `ema_50`, `ema_200` | Exponential moving averages |
| RSI | `rsi_14` | Relative strength index |
| MACD | `macd_line_12_26_9`, `macd_signal_12_26_9`, `macd_hist_12_26_9` | MACD line, signal, histogram |
| Bollinger | `bollinger_upper_20_2.0`, `bollinger_lower_20_2.0`, `bollinger_mid_20_2.0` | Band levels |
| Bollinger %B | `bollinger_pct_b_20_2.0` | Price position within band (0=lower, 1=upper) |
| Bollinger BW | `bollinger_bandwidth_20_2.0` | Band width % — volatility squeeze detector |
| ATR | `atr_14` | Average true range — absolute volatility |
| VWAP | `vwap` | Volume-weighted average price |
| Stochastic | `stoch_k_14_3_3`, `stoch_d_14_3_3` | %K and %D oscillator |

**Cross / event signals (boolean as float 1.0 / 0.0):**

| Signal key | Meaning |
|---|---|
| `ema_fast_cross_up` | EMA 9 crossed above EMA 21 on this candle |
| `ema_fast_cross_down` | EMA 9 crossed below EMA 21 on this candle |
| `ema_trend_bullish` | EMA 9 currently above EMA 21 |
| `ema_longterm_bullish` | EMA 50 currently above EMA 200 |
| `macd_cross_up` | MACD line crossed above signal line |
| `macd_cross_down` | MACD line crossed below signal line |
| `macd_above_zero` | MACD line is positive (bullish momentum) |
| `stoch_cross_up` | Stoch %K crossed above %D |
| `stoch_cross_down` | Stoch %K crossed below %D |

---

## Screener Rules

Rules are plain Python functions registered with `@rule("name")` in `screener/rules.py`. Thresholds come from `watchlist.yaml` per symbol.

| Rule | Signal used | Key thresholds |
|---|---|---|
| `rsi_oversold` | `rsi_14` | `threshold` (default 30) |
| `rsi_overbought` | `rsi_14` | `threshold` (default 70) |
| `ema_cross_up` | `ema_fast_cross_up` | — |
| `ema_cross_down` | `ema_fast_cross_down` | — |
| `candle_momentum` | `close` | `candles`, `min_pct`, `direction` |
| `volume_spike` | `volume` | `lookback`, `multiplier` |
| `price_near_ema` | `close`, `ema_N` | `ema_length`, `within_pct` |

Rules only apply in **scan mode**. Watch mode fires on every candle unconditionally.

---

## Risk Rules (all must pass — scan mode only)

| Rule | Config key | Default |
|---|---|---|
| Confidence ≥ threshold | `risk.min_confidence` | 0.65 |
| Leverage ≤ cap | `risk.max_leverage` | 20x |
| Open positions < max | `risk.max_positions` | 3 |
| Daily orders < max | `risk.max_orders_per_day` | 20 |
| Daily loss < max | `risk.max_daily_loss_usd` | $100 |
| Consecutive losses < max | `risk.max_consecutive_losses` | 3 |
| Circuit breaker OFF | auto-trips on consecutive loss limit | — |
| `trading_enabled` | Telegram `/pause` | true |

---

## Configuration

**`config/settings.yaml`** — all tunable parameters:

| Key | Default | Description |
|---|---|---|
| `active_profile` | `india_testnet` | Switch between testnet and mainnet |
| `screener.bar_history_size` | 200 | Rolling OHLCV window per symbol/timeframe |
| `screener.trigger_cooldown_minutes` | 5 | Min gap between scan-mode triggers per symbol |
| `screener.default_rules.*` | RSI 30/70 + EMA cross | Fallback if symbol has no rules in watchlist |
| `risk.*` | see table above | All risk limits |
| `llm.model` | `gemini/gemini-2.0-flash` | Any LiteLLM-supported model |
| `memory.rag_top_k` | 5 | Lessons injected per analysis cycle |
| `memory.max_lesson_chars` | 400 | Lesson size cap before ChromaDB storage |
| `execution.unfilled_limit_timeout_seconds` | 120 | Auto-cancel timeout for unfilled orders |
| `execution.fills_lookback_hours` | 24 | Exchange fill fetch window |
| `news.poll_interval_seconds` | 60 | How often to fetch news |
| `news.cache_ttl_seconds` | 120 | How long cached news stays fresh |
| `news.max_news_chars` | 1000 | Hard cap on news text injected into LLM prompt |

**`config/watchlist.yaml`** — per-symbol config:

```yaml
- symbol: BTCUSD
  quantity: 1
  leverage: 10
  indicators:
    - name: ema
      length: 9
    - name: ema
      length: 21
    - name: rsi
      length: 14
  rules:                        # scan-mode entry rules only
    - name: rsi_oversold
      thresholds:
        threshold: 30
    - name: candle_momentum
      thresholds:
        candles: 4
        min_pct: 0.1
        direction: up
```

---

## Telegram Commands

| Command | Effect |
|---|---|
| `/pause` | Stops all new trades (scan + watch EXIT both blocked) |
| `/resume` | Re-enables trading |
| `/status` | Shows enabled flag, open positions, daily PnL, circuit breaker |
| `/reset` | Manually resets circuit breaker |

---

## Environment Variables

```
DELTA_AGENT_ENV=india_testnet      # or india_mainnet
DELTA_API_KEY=
DELTA_API_SECRET=
GEMINI_API_KEY=
TELEGRAM_BOT_TOKEN=               # optional
TELEGRAM_CHAT_ID=                 # optional
CRYPTONEWS_API_KEY=               # optional — news disabled silently if missing
```

---

## Milestone Status

| Milestone | What | Status |
|---|---|---|
| M1 | Config, logging, LLM factory, memory interfaces | ✅ Done |
| M2 | WebSocket feed, BarStore, indicators, trigger gate | ✅ Done |
| M3 | Agent loop, analyzer, risk engine, SQLite persistence | ✅ Done |
| M4 | Exchange client (CCXT + Delta REST bracket orders), order lifecycle, startup reconciliation | ✅ Done |
| M5 | ChromaDB vector store, reflection pipeline, RAG injection | ✅ Done |
| M6 | News poller, Telegram alerts + bot, health endpoint, Docker + supervisord | ✅ Done |
| M7 | Two-mode agent loop: scan (entry) + watch (per-candle position monitoring + early EXIT) | ✅ Done |
