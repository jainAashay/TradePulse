"""Execution manager: bracket submit, timeout watcher, fill poller, startup reconciliation."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.config.settings import AppSettings
from delta_agent.execution.client import DeltaExchangeClient
from delta_agent.execution.orders import Order, OrderStatus
from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database

if TYPE_CHECKING:
    from delta_agent.reflection.pipeline import ReflectionPipeline

log = get_logger(__name__)


class ExecutionManager:
    """Manages the full order lifecycle from entry through closure."""

    def __init__(
        self,
        client: DeltaExchangeClient,
        db: Database,
        settings: AppSettings,
        reflection: Optional["ReflectionPipeline"] = None,
    ) -> None:
        self._client = client
        self._db = db
        self._timeout_s = settings.execution.unfilled_limit_timeout_seconds
        self._reflection = reflection
        self._timeout_tasks: Dict[int, asyncio.Task] = {}

    async def reconcile_on_startup(self) -> int:
        """
        Diff exchange state vs SQLite on startup.
        Returns count of positions currently open on exchange.
        """
        log.info("startup_reconciliation_begin")
        open_db_orders = self._db.get_open_orders()
        db_by_ext_id = {o["external_order_id"]: o for o in open_db_orders if o["external_order_id"]}

        # Fetch from exchange
        try:
            exchange_orders = await self._client.get_open_orders()
        except Exception as exc:
            log.error("reconcile_fetch_failed", error=str(exc))
            return 0

        exchange_ext_ids = {str(o.get("id", o.get("order_id", ""))) for o in exchange_orders}

        # Orphan recovery: exchange order not in SQLite
        for eo in exchange_orders:
            ext_id = str(eo.get("id", eo.get("order_id", "")))
            if ext_id not in db_by_ext_id:
                log.warning("orphan_order_recovered", external_order_id=ext_id)
                self._db.upsert_order_by_external_id(
                    ext_id,
                    symbol=eo.get("product_symbol", ""),
                    side=eo.get("side", ""),
                    quantity=float(eo.get("size", 0)),
                    leverage=int(eo.get("leverage", 1)),
                    entry_price=float(eo.get("limit_price", 0)),
                    sl_price=0.0,
                    tp_prices=[],
                    status=OrderStatus.OPEN,
                )

        # Mark closed: SQLite OPEN not on exchange
        for ext_id, db_order in db_by_ext_id.items():
            if ext_id not in exchange_ext_ids:
                log.info("order_closed_while_offline", external_order_id=ext_id)
                self._db.update_order_status(
                    db_order["id"], OrderStatus.CLOSED,
                    closed_at=datetime.now(timezone.utc).isoformat(),
                )
                if self._reflection:
                    await self._reflection.trigger(db_order["id"], pnl_usd=None)

        # Re-attach timeout watchers for PENDING orders
        for db_order in open_db_orders:
            if db_order["status"] == OrderStatus.PENDING and db_order["external_order_id"]:
                self._attach_timeout(db_order["id"], db_order["external_order_id"], db_order["symbol"])

        # Count open positions from exchange
        try:
            positions = await self._client.get_positions()
            open_count = len([p for p in positions if float(p.get("size", 0)) != 0])
        except Exception:
            open_count = 0

        log.info("startup_reconciliation_done", open_positions=open_count)
        return open_count

    async def enter(self, symbol: str, decision: TradeDecision) -> int:
        """Submit bracket order, persist to DB, attach timeout watcher. Returns local order_id."""
        # Determine side
        side = "buy" if decision.action == "LONG" else "sell"

        # Get current price for entry
        ticker = await self._client.get_ticker(symbol)
        if decision.action == "LONG":
            entry_price = float(ticker.get("ask", ticker.get("last", 0)))
        else:
            entry_price = float(ticker.get("bid", ticker.get("last", 0)))

        # Compute bracket prices
        sl_pct = decision.sl_pct / 100.0
        if decision.action == "LONG":
            sl_price = entry_price * (1 - sl_pct)
            tp_price = entry_price * (1 + decision.tp_pcts[0] / 100.0)
        else:
            sl_price = entry_price * (1 + sl_pct)
            tp_price = entry_price * (1 - decision.tp_pcts[0] / 100.0)

        # Get quantity from watchlist (not from decision)
        quantity = 1  # default; caller should pass watchlist quantity

        # Persist PENDING
        order_id = self._db.insert_order(
            symbol=symbol,
            side=side,
            quantity=quantity,
            leverage=decision.leverage,
            entry_price=entry_price,
            sl_price=sl_price,
            tp_prices=decision.tp_pcts,
        )

        # Submit to exchange
        try:
            result = await self._client.place_bracket_order(
                symbol=symbol,
                side=side,
                quantity=quantity,
                limit_price=entry_price,
                sl_price=sl_price,
                tp_price=tp_price,
                leverage=decision.leverage,
            )
            ext_id = str(result.get("result", {}).get("id", ""))
            self._db.update_order_status(order_id, OrderStatus.PENDING, external_order_id=ext_id)
            self._attach_timeout(order_id, ext_id, symbol)
            log.info("order_submitted", order_id=order_id, external_order_id=ext_id)
        except Exception as exc:
            self._db.update_order_status(order_id, OrderStatus.CANCELLED)
            raise RuntimeError(f"Order submission failed: {exc}") from exc

        return order_id

    async def exit_position(self, order: Dict[str, Any]) -> None:
        """
        Early exit: cancel bracket + market-close the position.
        Called by AgentLoop when watch-mode LLM returns EXIT.
        """
        order_id = order["id"]
        symbol = order["symbol"]
        side = order["side"]
        quantity = float(order["quantity"])
        ext_id = order.get("external_order_id", "")

        log.info("early_exit_initiated", order_id=order_id, symbol=symbol)

        # Cancel timeout watcher if still pending
        task = self._timeout_tasks.pop(order_id, None)
        if task and not task.done():
            task.cancel()

        try:
            await self._client.close_position(symbol, side, quantity)
            self._db.update_order_status(
                order_id, OrderStatus.CLOSED,
                closed_at=datetime.now(timezone.utc).isoformat(),
            )
            log.info("early_exit_complete", order_id=order_id, symbol=symbol)
        except Exception as exc:
            log.error("early_exit_failed", order_id=order_id, error=str(exc))
            raise

    def _attach_timeout(self, order_id: int, ext_id: str, symbol: str) -> None:
        task = asyncio.create_task(self._timeout_watcher(order_id, ext_id, symbol))
        self._timeout_tasks[order_id] = task

    async def _timeout_watcher(self, order_id: int, ext_id: str, symbol: str) -> None:
        await asyncio.sleep(self._timeout_s)
        # Check if still PENDING
        open_orders = self._db.get_open_orders()
        match = next((o for o in open_orders if o["id"] == order_id and o["status"] == OrderStatus.PENDING), None)
        if match:
            log.warning("order_timeout_cancelling", order_id=order_id, external_order_id=ext_id)
            try:
                await self._client.cancel_order(ext_id, symbol)
                self._db.update_order_status(
                    order_id, OrderStatus.CANCELLED,
                    closed_at=datetime.now(timezone.utc).isoformat(),
                )
            except Exception as exc:
                log.error("cancel_failed", order_id=order_id, error=str(exc))
        self._timeout_tasks.pop(order_id, None)
