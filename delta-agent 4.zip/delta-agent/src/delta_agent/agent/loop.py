"""Main agent loop: scan mode (trigger-gated entry) + watch mode (per-candle position monitoring)."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from delta_agent.analyzer.context import Analyzer, OpenPosition
from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database
from delta_agent.risk.engine import RiskEngine
from delta_agent.risk.state import RiskState
from delta_agent.screener.trigger import TriggerEvent, TriggerMap

if TYPE_CHECKING:
    from delta_agent.execution.manager import ExecutionManager
    from delta_agent.health.alerter import Alerter

log = get_logger(__name__)


class AgentLoop:
    """
    Two-mode async state machine:

    SCAN MODE  (no open position on symbol)
      Waits for TriggerEvent from TriggerGate (rule-filtered).
      Calls Analyzer → RiskEngine → ExecutionManager.enter().

    WATCH MODE  (open position exists on symbol)
      Every TriggerEvent for that symbol bypasses rule filtering
      (BarStore fires on every closed candle in on_bar, but TriggerGate
      is short-circuited by AgentLoop before it reaches rule evaluation).
      Calls Analyzer with OpenPosition context → if EXIT → ExecutionManager.exit_position().

    Transitions:
      SCAN → WATCH: order placed successfully
      WATCH → SCAN: position closed (EXIT decision, SL/TP hit, or timeout cancel)
    """

    def __init__(
        self,
        trigger_map: TriggerMap,
        analyzer: Analyzer,
        risk_engine: RiskEngine,
        risk_state: RiskState,
        db: Database,
        execution_manager: Optional["ExecutionManager"] = None,
        alerter: Optional["Alerter"] = None,
    ) -> None:
        self._triggers = trigger_map
        self._analyzer = analyzer
        self._risk_engine = risk_engine
        self._risk_state = risk_state
        self._db = db
        self._execution = execution_manager
        self._alerter = alerter
        self._running = False

    def startup(self) -> None:
        crashed = self._db.crash_inflight_cycles()
        if crashed:
            log.warning("startup_crashed_inflight_cycles", count=crashed)

    async def run(self) -> None:
        self._running = True
        log.info("agent_loop_started")
        while self._running:
            try:
                await self._process_next()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.error("agent_loop_unhandled_error", error=str(exc), exc_info=True)
                await asyncio.sleep(1)

    async def stop(self) -> None:
        self._running = False

    async def _process_next(self) -> None:
        self._risk_state.maybe_reset_for_new_day(self._db)

        event = await self._triggers.get_next()
        log.info("trigger_received", symbol=event.symbol, timeframe=event.timeframe,
                 rule=event.rule_matched)

        if not self._db.is_trading_enabled():
            log.info("trading_disabled_skipping_trigger", symbol=event.symbol)
            return

        if self._risk_state.circuit_breaker_active:
            log.info("circuit_breaker_active_skipping", symbol=event.symbol)
            return

        # Check for open position → determines mode
        open_order = self._db.get_open_position_for_symbol(event.symbol)

        if open_order:
            await self._watch_cycle(event, open_order)
        else:
            await self._scan_cycle(event)

    # ── Scan mode ─────────────────────────────────────────────────────────────

    async def _scan_cycle(self, event: TriggerEvent) -> None:
        """Rule-filtered entry: LONG / SHORT / HOLD."""
        cycle_id = self._db.create_cycle(
            event.symbol, event.timeframe,
            datetime.fromtimestamp(event.timestamp, tz=timezone.utc).isoformat(),
        )
        try:
            decision = await self._analyzer.analyze(event, open_position=None)

            trading_enabled = self._db.is_trading_enabled()
            verdict = self._risk_engine.validate(decision, self._risk_state, trading_enabled)

            if not verdict.approved:
                log.info("scan_rejected", symbol=event.symbol, reason=verdict.reason)
                self._db.update_cycle(cycle_id, "REJECTED", rejection_reason=verdict.reason)
                if self._alerter:
                    await self._alerter.send_rejection(event.symbol, verdict.reason)
                if "consecutive_losses" in verdict.reason:
                    self._risk_state.trip_circuit_breaker(self._db)
                    if self._alerter:
                        await self._alerter.send_circuit_breaker_tripped()
                return

            self._db.update_cycle(cycle_id, "IN_FLIGHT",
                                  decision_json=json.dumps(decision.model_dump()))

            if self._execution:
                order_id = await self._execution.enter(event.symbol, decision)
                self._risk_state.record_order_placed(self._db)
                self._risk_state.open_positions += 1
                log.info("order_placed", symbol=event.symbol, order_id=order_id,
                         action=decision.action)
                if self._alerter:
                    await self._alerter.send_trade_entry(event.symbol, decision, order_id)
            else:
                log.info("execution_dry_run", symbol=event.symbol, action=decision.action,
                         confidence=decision.confidence)

            self._db.update_cycle(cycle_id, "COMPLETED",
                                  decision_json=json.dumps(decision.model_dump()))

        except Exception as exc:
            log.error("scan_cycle_error", cycle_id=cycle_id, symbol=event.symbol,
                      error=str(exc), exc_info=True)
            self._db.update_cycle(cycle_id, "CRASHED", rejection_reason=str(exc))

    # ── Watch mode ────────────────────────────────────────────────────────────

    async def _watch_cycle(self, event: TriggerEvent, open_order: dict) -> None:
        """Per-candle monitoring: HOLD or EXIT."""
        import json as _json
        tp_prices = _json.loads(open_order.get("tp_prices") or "[]")
        tp_price = tp_prices[0] if tp_prices else 0.0

        pos = OpenPosition(
            order_id=open_order["id"],
            symbol=open_order["symbol"],
            side=open_order["side"],
            entry_price=float(open_order.get("entry_price") or 0),
            sl_price=float(open_order.get("sl_price") or 0),
            tp_price=tp_price,
            created_at=open_order.get("created_at", ""),
        )

        try:
            decision = await self._analyzer.analyze(event, open_position=pos)
        except Exception as exc:
            log.error("watch_cycle_analyze_error", symbol=event.symbol, error=str(exc))
            return

        log.info("watch_decision", symbol=event.symbol, action=decision.action,
                 confidence=decision.confidence, reasoning=decision.reasoning[:80])

        if decision.action == "EXIT":
            log.info("watch_exit_triggered", symbol=event.symbol,
                     confidence=decision.confidence)
            if self._execution:
                try:
                    await self._execution.exit_position(open_order)
                    self._risk_state.open_positions = max(0, self._risk_state.open_positions - 1)
                    if self._alerter:
                        await self._alerter.send(
                            f"Early EXIT: {event.symbol} — {decision.reasoning}"
                        )
                except Exception as exc:
                    log.error("watch_exit_failed", symbol=event.symbol, error=str(exc))
            else:
                log.info("watch_exit_dry_run", symbol=event.symbol,
                         reasoning=decision.reasoning)
        # HOLD → do nothing, continue watching next candle
