"""
Closed trade detector.

Approach: every poll interval, fetch ALL fills from the exchange in one batch call,
then intersect with SQLite orders where reflected=0.
Only orders present in both sets (closed on exchange + unreflected locally) trigger reflection.
This avoids per-order API calls and ensures learning only happens on final settled PnL.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database

if TYPE_CHECKING:
    from delta_agent.execution.client import DeltaExchangeClient

log = get_logger(__name__)


@dataclass
class ClosedTradeEvent:
    order_id: int
    external_order_id: str
    symbol: str
    pnl_usd: Optional[float]
    hold_seconds: float
    closed_at: str


class ClosedTradeDetector:
    """
    Polls exchange fills in one batch call every `poll_interval` seconds.
    Intersects with SQLite unresolved orders (reflected=0).
    Emits ClosedTradeEvent only for the intersection — no duplicate reflections possible.
    """

    def __init__(
        self,
        client: "DeltaExchangeClient",
        db: Database,
        poll_interval: int = 30,
        fills_lookback_hours: int = 24,
    ) -> None:
        self._client = client
        self._db = db
        self._interval = poll_interval
        self._lookback_hours = fills_lookback_hours
        self._queue: asyncio.Queue[ClosedTradeEvent] = asyncio.Queue()
        self._running = False

    @property
    def queue(self) -> asyncio.Queue[ClosedTradeEvent]:
        return self._queue

    async def run(self) -> None:
        self._running = True
        while self._running:
            await asyncio.sleep(self._interval)
            try:
                await self._poll()
            except Exception as exc:
                log.error("detector_poll_error", error=str(exc))

    async def stop(self) -> None:
        self._running = False

    async def _poll(self) -> None:
        # Step 1: SQLite — orders not yet reflected (source of truth for what we care about)
        unresolved = self._db.get_unresolved_orders()
        if not unresolved:
            return

        # Build lookup: external_order_id -> local DB row
        local_by_ext_id = {row["external_order_id"]: row for row in unresolved}

        # Step 2: Exchange — fetch fills/closed orders in one batch call
        try:
            exchange_fills = await self._client.get_fills(lookback_hours=self._lookback_hours)
        except Exception as exc:
            log.warning("fills_fetch_failed", error=str(exc))
            return

        # Build set of external IDs that are closed on exchange
        closed_ext_ids = {
            str(f.get("order_id", f.get("id", "")))
            for f in exchange_fills
        }

        # Step 3: Intersection — only orders closed on exchange AND unreflected locally
        to_reflect = {
            ext_id: local_by_ext_id[ext_id]
            for ext_id in closed_ext_ids
            if ext_id in local_by_ext_id
        }

        if not to_reflect:
            return

        log.info("fills_intersected", total_fills=len(exchange_fills),
                 unresolved_local=len(unresolved), to_reflect=len(to_reflect))

        # Step 4: Emit events for each matched order
        fills_by_ext_id = {
            str(f.get("order_id", f.get("id", ""))): f for f in exchange_fills
        }

        for ext_id, db_row in to_reflect.items():
            fill = fills_by_ext_id.get(ext_id, {})
            pnl = fill.get("realized_pnl") or fill.get("pnl")
            closed_at = datetime.now(timezone.utc).isoformat()

            # Compute hold time from DB timestamps
            try:
                created_dt = datetime.fromisoformat(db_row["created_at"])
                hold_s = (datetime.now(timezone.utc) - created_dt).total_seconds()
            except Exception:
                hold_s = 0.0

            # Update SQLite status to CLOSED with final PnL
            self._db.close_order(
                db_row["id"],
                pnl_usd=float(pnl) if pnl is not None else None,
                closed_at=closed_at,
            )

            evt = ClosedTradeEvent(
                order_id=db_row["id"],
                external_order_id=ext_id,
                symbol=db_row["symbol"],
                pnl_usd=float(pnl) if pnl is not None else None,
                hold_seconds=hold_s,
                closed_at=closed_at,
            )
            await self._queue.put(evt)
            log.info("trade_queued_for_reflection", order_id=db_row["id"],
                     symbol=db_row["symbol"], pnl=pnl)
