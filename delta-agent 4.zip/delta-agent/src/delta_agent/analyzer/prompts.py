"""Prompt templates for scan mode (entry) and watch mode (position monitoring)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from delta_agent.llm.protocols import ChatMessage


# ── Scan mode (no open position — looking for entry) ─────────────────────────

SCAN_SYSTEM_TEMPLATE = """\
You are a disciplined quantitative trading analyst for Delta Exchange perpetual futures.
Your decisions are directly executed on a live account. Be conservative and precise.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{lessons}

## Current Market State
Symbol: {symbol} | Timeframe: {timeframe} | Timestamp: {timestamp}
Indicators:
{indicators}

## News Sentiment
{news}

## Risk Parameters
Max leverage: {max_leverage}x | Min confidence to trade: {min_confidence}
"""

SCAN_USER_PROMPT = """\
Analyse the above context and produce a trade decision as a single JSON object only. \
No markdown, no prose outside the JSON.

Schema:
{
  "action": "LONG" | "SHORT" | "HOLD",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<chain-of-thought, 2-3 sentences>",
  "leverage": <int>,
  "sl_pct": <float, stop-loss distance as % of entry price>,
  "tp_pcts": [<float>, ...]
}

For HOLD: leverage, sl_pct, tp_pcts may be omitted or set to null.
"""


# ── Watch mode (open position — monitoring for early exit) ───────────────────

WATCH_SYSTEM_TEMPLATE = """\
You are a disciplined quantitative trading analyst monitoring an active position on Delta Exchange.
Your job is to decide whether to hold or exit early. Be objective — do not let loss aversion or \
greed override the technicals.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{lessons}

## Active Position
Symbol: {symbol} | Side: {side} | Timeframe: {timeframe}
Entry price:   {entry_price}
Current price: {current_price}
Unrealised PnL: {unrealised_pnl_pct:.2f}%
Time held:     {hold_minutes} minutes
Stop-loss at:  {sl_price}
Take-profit at: {tp_price}

## Current Market State
Timestamp: {timestamp}
Indicators:
{indicators}

## News Sentiment
{news}
"""

WATCH_USER_PROMPT = """\
Based on the active position and current market context, decide whether to HOLD or EXIT early. \
Produce a single JSON object only. No markdown, no prose outside the JSON.

Schema:
{
  "action": "HOLD" | "EXIT",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<chain-of-thought, 2-3 sentences explaining hold or early exit rationale>"
}

EXIT means: cancel the bracket order and flatten the position immediately at market.
Only EXIT if you see clear evidence the trade thesis has broken down.
"""


def build_scan_messages(
    symbol: str,
    timeframe: str,
    timestamp: str,
    indicators: Dict[str, float],
    lessons: str,
    news: Optional[str],
    max_leverage: int,
    min_confidence: float,
) -> List[ChatMessage]:
    indicator_lines = _format_indicators(indicators)
    news_text = news or "Unavailable (poller not yet run or API key missing)"
    system = SCAN_SYSTEM_TEMPLATE.format(
        lessons=lessons or "No prior lessons yet.",
        symbol=symbol,
        timeframe=timeframe,
        timestamp=timestamp,
        indicators=indicator_lines,
        news=news_text,
        max_leverage=max_leverage,
        min_confidence=min_confidence,
    )
    return [
        ChatMessage(role="system", content=system),
        ChatMessage(role="user", content=SCAN_USER_PROMPT),
    ]


def build_watch_messages(
    symbol: str,
    side: str,
    timeframe: str,
    timestamp: str,
    entry_price: float,
    current_price: float,
    sl_price: float,
    tp_price: float,
    hold_minutes: int,
    indicators: Dict[str, float],
    lessons: str,
    news: Optional[str],
) -> List[ChatMessage]:
    if entry_price > 0:
        if side == "buy":
            pnl_pct = (current_price - entry_price) / entry_price * 100
        else:
            pnl_pct = (entry_price - current_price) / entry_price * 100
    else:
        pnl_pct = 0.0

    indicator_lines = _format_indicators(indicators)
    news_text = news or "Unavailable"
    system = WATCH_SYSTEM_TEMPLATE.format(
        lessons=lessons or "No prior lessons yet.",
        symbol=symbol,
        side=side,
        timeframe=timeframe,
        timestamp=timestamp,
        entry_price=entry_price,
        current_price=current_price,
        unrealised_pnl_pct=pnl_pct,
        hold_minutes=hold_minutes,
        sl_price=sl_price,
        tp_price=tp_price,
        indicators=indicator_lines,
        news=news_text,
    )
    return [
        ChatMessage(role="system", content=system),
        ChatMessage(role="user", content=WATCH_USER_PROMPT),
    ]


# kept for backward compat — scan mode alias
def build_messages(
    symbol: str,
    timeframe: str,
    timestamp: str,
    indicators: Dict[str, float],
    lessons: str,
    news: Optional[str],
    max_leverage: int,
    min_confidence: float,
) -> List[ChatMessage]:
    return build_scan_messages(
        symbol, timeframe, timestamp, indicators, lessons, news, max_leverage, min_confidence
    )


def _format_indicators(indicators: Dict[str, Any]) -> str:
    lines = "\n".join(
        f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}"
        for k, v in sorted(indicators.items())
        if not (isinstance(v, float) and v != v)  # skip NaN
    )
    return lines or "  (no indicators computed yet)"
