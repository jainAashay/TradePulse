"""Analyzer: assembles context and invokes LLM for a TradeDecision."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.analyzer.prompts import build_scan_messages, build_watch_messages
from delta_agent.config.settings import RiskConfig
from delta_agent.llm.protocols import LLMRuntime
from delta_agent.logging_setup import get_logger
from delta_agent.screener.indicators import IndicatorRunner
from delta_agent.screener.trigger import TriggerEvent

log = get_logger(__name__)


@dataclass
class OpenPosition:
    """Snapshot of an active order passed to watch-mode analysis."""
    order_id: int
    symbol: str
    side: str           # "buy" | "sell"
    entry_price: float
    sl_price: float
    tp_price: float     # first TP level
    created_at: str     # ISO timestamp


class Analyzer:
    """
    Dual-mode analyzer:
      - Scan mode  (open_position=None): trigger-gated entry analysis
      - Watch mode (open_position set):  per-candle monitoring of active position
    """

    def __init__(
        self,
        llm_runtime: LLMRuntime,
        indicator_runner: IndicatorRunner,
        risk_config: RiskConfig,
        news_cache=None,
        max_news_chars: int = 1000,
    ) -> None:
        self._llm = llm_runtime
        self._indicators = indicator_runner
        self._risk = risk_config
        self._news_cache = news_cache
        self._max_news_chars = max_news_chars

    async def analyze(
        self,
        event: TriggerEvent,
        open_position: Optional[OpenPosition] = None,
    ) -> TradeDecision:
        """
        Scan mode:  open_position=None  → LONG / SHORT / HOLD decision
        Watch mode: open_position set   → HOLD / EXIT decision
        """
        symbol = event.symbol
        timeframe = event.timeframe

        signals = await self._indicators.compute(symbol, timeframe)
        merged_signals = {**event.signals, **signals}

        news_text = self._get_news_text(symbol)
        records = self._fetch_rag(symbol, timeframe, merged_signals)
        lessons = self._llm.format_learnings_for_prompt(records)

        ts = datetime.now(timezone.utc).isoformat()

        if open_position is not None:
            messages = self._build_watch_messages(
                open_position, event, merged_signals, lessons, news_text, ts
            )
            mode = "watch"
        else:
            messages = build_scan_messages(
                symbol=symbol,
                timeframe=timeframe,
                timestamp=ts,
                indicators=merged_signals,
                lessons=lessons,
                news=news_text,
                max_leverage=self._risk.max_leverage,
                min_confidence=self._risk.min_confidence,
            )
            mode = "scan"

        log.info("analyzer_calling_llm", symbol=symbol, timeframe=timeframe,
                 mode=mode, rag_lessons=len(records))
        raw = self._llm.client.complete_json(messages)

        try:
            decision = TradeDecision.model_validate(raw)
        except Exception as exc:
            raise ValueError(f"LLM output failed validation: {exc}. Raw: {json.dumps(raw)[:200]}")

        log.info("analyzer_decision", symbol=symbol, action=decision.action,
                 confidence=decision.confidence, mode=mode)
        return decision

    # ── helpers ──────────────────────────────────────────────────────────────

    def _get_news_text(self, symbol: str) -> Optional[str]:
        if self._news_cache is None:
            return None
        summary = self._news_cache.get(symbol)
        return summary.as_text(max_chars=self._max_news_chars) if summary else None

    def _fetch_rag(self, symbol: str, timeframe: str, signals: Dict[str, Any]):
        rsi_val = signals.get("rsi_14", float("nan"))
        cross_up = bool(signals.get("ema_fast_cross_up", 0))
        trend = "bullish" if cross_up else "bearish"
        rsi_str = f"{rsi_val:.1f}" if rsi_val == rsi_val else "n/a"
        query = f"{symbol} perpetual {timeframe} RSI={rsi_str} trend={trend}"
        return self._llm.fetch_learnings(query)

    def _build_watch_messages(
        self,
        pos: OpenPosition,
        event: TriggerEvent,
        signals: Dict[str, Any],
        lessons: str,
        news_text: Optional[str],
        ts: str,
    ):
        # Compute hold time
        try:
            created_dt = datetime.fromisoformat(pos.created_at)
            hold_minutes = int((datetime.now(timezone.utc) - created_dt).total_seconds() / 60)
        except Exception:
            hold_minutes = 0

        # Current price from signals or fall back to entry
        current_price = float(signals.get("close", pos.entry_price))

        return build_watch_messages(
            symbol=pos.symbol,
            side=pos.side,
            timeframe=event.timeframe,
            timestamp=ts,
            entry_price=pos.entry_price,
            current_price=current_price,
            sl_price=pos.sl_price,
            tp_price=pos.tp_price,
            hold_minutes=hold_minutes,
            indicators=signals,
            lessons=lessons,
            news=news_text,
        )
