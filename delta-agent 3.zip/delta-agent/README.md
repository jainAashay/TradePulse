# delta-agent — Agentic Trading Bot for Delta Exchange

A 24/7 autonomous trading agent for Delta Exchange perpetual futures. Uses local technical analysis to filter signals, invokes an LLM (Gemini via LiteLLM) for CoT-based decisions, enforces hard risk rules, executes bracket orders, and continuously learns from closed trades via ChromaDB vector memory.

---

## System Diagram

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║                          DELTA AGENT — 24/7 RUNTIME                            ║
╚══════════════════════════════════════════════════════════════════════════════════╝

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                        STAGE 1 — MARKET DATA & SCREENER                     │
  │                                                                             │
  │   Delta Exchange WebSocket (wss://)                                         │
  │   ┌─────────────────────────────┐                                           │
  │   │  candlestick_1m / _5m feed  │  auto-reconnect (exp backoff 1s→60s)     │
  │   └────────────┬────────────────┘                                           │
  │                │ closed bar only                                             │
  │                ▼                                                             │
  │   ┌────────────────────┐    push()    ┌─────────────────────────────────┐  │
  │   │     DeltaFeed      │ ──────────▶  │  BarStore (deque maxlen=200*)   │  │
  │   │   (feed.py)        │              │  keyed by (symbol, timeframe)   │  │
  │   └────────────────────┘              └──────────────┬──────────────────┘  │
  │                                                       │ get_df()            │
  │                                                       ▼                     │
  │                                        ┌─────────────────────────┐         │
  │                                        │   IndicatorRunner       │         │
  │                                        │   EMA · RSI · MACD      │         │
  │                                        │   Bollinger · CrossEvt  │         │
  │                                        └──────────────┬──────────┘         │
  │                                                       │ signals dict        │
  │                                                       ▼                     │
  │                                        ┌─────────────────────────┐         │
  │                                        │     TriggerGate         │         │
  │                                        │  Python rule registry   │         │
  │                                        │  YAML thresholds/symbol │         │
  │                                        │  per-symbol cooldown    │         │
  │                                        │  latest-wins dedup map  │         │
  │                                        └──────────────┬──────────┘         │
  │                                                       │ TriggerEvent        │
  └───────────────────────────────────────────────────────┼─────────────────────┘
                                                          │
  ┌───────────────────────────────────────────────────────▼─────────────────────┐
  │                        STAGE 2 — ANALYZER (LLM BRAIN)                       │
  │                                                                             │
  │   ┌──────────────────────────────────────────────────────────────────────┐  │
  │   │                        Context Assembly                              │  │
  │   │                                                                      │  │
  │   │  ┌──────────────┐   ┌──────────────────┐   ┌────────────────────┐  │  │
  │   │  │  Indicators  │   │  NewsCache        │   │  ChromaDB RAG      │  │  │
  │   │  │  (live vals) │   │  CryptoNews API   │   │  top-K lessons     │  │  │
  │   │  │              │   │  poll 60s/TTL 2m  │   │  injected FIRST    │  │  │
  │   │  │              │   │  age + sentiment  │   │                    │  │  │
  │   │  └──────┬───────┘   └────────┬──────────┘   └────────┬──────────┘  │  │
  │   │         └───────────────────┬┘                        │             │  │
  │   │                             └────────────┬────────────┘             │  │
  │   │                                          ▼                          │  │
  │   │                          ┌──────────────────────────┐               │  │
  │   │                          │      System Prompt       │               │  │
  │   │                          │  [1] Prior Lessons (RAG) │               │  │
  │   │                          │  [2] Market State        │               │  │
  │   │                          │  [3] News + timestamps   │               │  │
  │   │                          │  [4] Risk Parameters     │               │  │
  │   │                          └──────────────┬───────────┘               │  │
  │   └─────────────────────────────────────────┼───────────────────────────┘  │
  │                                             │                               │
  │                                             ▼                               │
  │                               ┌─────────────────────────┐                  │
  │                               │   LLM (Gemini/LiteLLM)  │                  │
  │                               │   CoT reasoning → JSON  │                  │
  │                               └──────────────┬──────────┘                  │
  │                                              │ TradeDecision               │
  │                                              │ action/confidence/           │
  │                                              │ leverage/SL%/TP%            │
  └──────────────────────────────────────────────┼──────────────────────────────┘
                                                 │
  ┌──────────────────────────────────────────────▼──────────────────────────────┐
  │                        STAGE 3 — RISK ENGINE (IMMUTABLE)                    │
  │                                                                             │
  │   ┌──────────────────────────────────────────────────────────────────────┐  │
  │   │  Hard Rules (all must pass)          RiskState (from SQLite)        │  │
  │   │  ✓ confidence ≥ 0.65                 · daily_orders                 │  │
  │   │  ✓ leverage ≤ 20x                    · daily_loss_usd               │  │
  │   │  ✓ open_positions < 3                · consecutive_losses           │  │
  │   │  ✓ daily_orders < 20                 · circuit_breaker_active       │  │
  │   │  ✓ daily_loss < $100                 · trading_enabled (Telegram)   │  │
  │   │  ✓ consecutive_losses < 3                                           │  │
  │   │  ✓ circuit_breaker OFF                                              │  │
  │   │  ✓ trading_enabled = true                                           │  │
  │   └─────────────────────┬──────────────────────────────────────────────┘  │
  │                         │                                                   │
  │              ┌──────────┴──────────┐                                        │
  │              ▼                     ▼                                        │
  │         APPROVED               REJECTED ──▶ logged + Telegram alert         │
  └──────────────┼──────────────────────────────────────────────────────────────┘
                 │
  ┌──────────────▼──────────────────────────────────────────────────────────────┐
  │                        STAGE 4 — EXECUTION ENGINE                           │
  │                                                                             │
  │   ┌────────────────────────────────────────────┐                           │
  │   │            ExecutionManager                │                           │
  │   │                                            │                           │
  │   │  1. Fetch best bid/ask via CCXT            │                           │
  │   │  2. Compute SL price + TP price            │                           │
  │   │  3. POST /v2/orders (Delta REST)           │   ◀── bracket order        │
  │   │     · post_only limit entry                │       (SL + TP attached)  │
  │   │     · bracket_stop_loss_price              │                           │
  │   │     · bracket_take_profit_price            │                           │
  │   │  4. Persist → SQLite orders table          │                           │
  │   │  5. Timeout watcher (asyncio.Task)         │   auto-cancel if unfilled │
  │   │     cancels via CCXT after N seconds       │                           │
  │   └────────────────────┬───────────────────────┘                           │
  │                        │                                                    │
  │            ┌───────────▼──────────┐                                         │
  │            │  Telegram Alert      │  entry: symbol · side · price · SL · TP │
  │            └──────────────────────┘                                         │
  └─────────────────────────────────────────────────────────────────────────────┘
                        │ trade closes (SL / TP / timeout)
  ┌─────────────────────▼───────────────────────────────────────────────────────┐
  │                        STAGE 5 — REFLECTION & LEARNING                      │
  │                                                                             │
  │   ┌────────────────────────────────────────────────────────────────────┐   │
  │   │  ClosedTradeDetector (polls every 30s)                            │   │
  │   │  · batch-fetches fills from exchange (last 24h only)              │   │
  │   │  · intersects with SQLite orders WHERE reflected=0                │   │
  │   │  · emits ClosedTradeEvent only for matched, unreflected orders    │   │
  │   └─────────────────────────────┬──────────────────────────────────────┘   │
  │                                 │                                           │
  │                                 ▼                                           │
  │   ┌────────────────────────────────────────────────────────────────────┐   │
  │   │  ReflectionPipeline                                               │   │
  │   │                                                                    │   │
  │   │  Original hypothesis (from SQLite)  +  Actual outcome             │   │
  │   │                    │                                               │   │
  │   │                    ▼                                               │   │
  │   │             LLM post-mortem → raw lesson                          │   │
  │   │                    │                                               │   │
  │   │                    ▼                                               │   │
  │   │        LLMBackedLearningRefiner → compact lesson (≤400 chars)     │   │
  │   │                    │                                               │   │
  │   │                    ▼                                               │   │
  │   │        ChromaDB.add_learning()  ← tagged: symbol · win/loss       │   │
  │   │                    │             · side · PnL · hold_mins         │   │
  │   │                    │                                               │   │
  │   │        mark_reflected(order_id) — idempotency gate in SQLite      │   │
  │   │        RiskState.consecutive_losses updated                        │   │
  │   └────────────────────┬───────────────────────────────────────────────┘   │
  │                        │                                                    │
  │            ┌───────────▼──────────┐                                         │
  │            │  Telegram Alert      │  close: PnL · duration · outcome        │
  │            └──────────────────────┘                                         │
  └─────────────────────────────────────────────────────────────────────────────┘
          │ lessons available for next analysis cycle ▲
          └─────────────────────────────────────────────┘  (RAG loop)

═══════════════════════════════════════════════════════════════════════════════════
  BACKGROUND SERVICES (always running in parallel)
═══════════════════════════════════════════════════════════════════════════════════

  ┌─────────────────────┐   ┌──────────────────────┐   ┌──────────────────────┐
  │   NewsPoller        │   │  TelegramBot          │   │  Health Server       │
  │                     │   │                       │   │                      │
  │  CryptoNews API     │   │  /pause  → DB flag    │   │  GET /health         │
  │  poll every 60s*    │   │  /resume → DB flag    │   │  POST /reset-cb      │
  │  TTL cache 120s*    │   │  /status → live state │   │  port :8080          │
  │  age label per item │   │  /reset  → clear CB   │   │                      │
  └─────────────────────┘   └──────────────────────┘   └──────────────────────┘

  * configurable via news.poll_interval_seconds / news.cache_ttl_seconds

═══════════════════════════════════════════════════════════════════════════════════
  PERSISTENCE (SQLite — survives restarts)
═══════════════════════════════════════════════════════════════════════════════════

  analysis_cycles   IN_FLIGHT cycles → marked CRASHED on restart (no double-entry)
  orders            PENDING→OPEN→CLOSED + PnL + reflected flag; reconciled on startup
  risk_state        daily counters recomputed from orders table on startup
  agent_config      trading_enabled flag (Telegram-controlled, persists across restarts)

  * bar_history_size configurable in settings.yaml (default 200)
```

---

## Key Design Decisions

| Topic | Decision |
|---|---|
| Exchange API | CCXT async for balance/positions/orders/cancel; Delta REST (`/v2/orders`) for bracket orders (SL+TP) — CCXT doesn't expose bracket params |
| WebSocket | Native `websockets` lib (not CCXT streaming); auto-reconnect with exponential backoff (1s→60s cap) |
| Trigger rules | Python function registry (`@rule("name")` decorator); thresholds configured per symbol in `watchlist.yaml`; OR semantics by default, AND optional |
| Trigger dedup | Latest-wins map per symbol — replaces stale pending triggers, no queue backlog |
| LLM provider | Gemini via LiteLLM; swap model/provider in `settings.yaml` with no code changes |
| Vector memory | ChromaDB + `all-MiniLM-L6-v2` local embeddings (no API cost); lessons pre-compressed to ≤400 chars by LLM before storage; injected at top of system prompt before market state on every analysis cycle |
| Position sizing | Fixed `quantity` + `leverage` from `watchlist.yaml`; LLM leverage suggestion capped by `max_leverage` |
| Risk engine | Stateless validator; daily counters recomputed from SQLite on startup (not in-memory) |
| Reflection dedup | `reflected` flag in SQLite orders table; `mark_reflected()` called only after ChromaDB write succeeds; `replay_unreflected()` on startup covers crash recovery |
| Fills API | Batch call with `fills_lookback_hours` cap (default 24h) — response stays bounded regardless of trading history length |
| Restart resilience | `IN_FLIGHT` cycles marked `CRASHED` on boot; order reconciliation diffs exchange vs SQLite; trading_enabled flag persisted in SQLite |
| Kill switch | Telegram `/pause` `/resume` `/status` `/reset` — no redeploy needed |
| News | CryptoNews API; poll interval + TTL both configurable; headline age label injected so LLM can weigh recency; hard char cap prevents token blowout |
| Cloud | Docker + supervisord; `data/` volume for SQLite + ChromaDB persistence |

---

## Package Structure

```
src/delta_agent/
  config/           YAML + env config, watchlist, RiskConfig, ScreenerConfig, NewsConfig
  screener/         bar_store.py, feed.py, indicators.py, rules.py, trigger.py
  analyzer/         context.py (prompt assembly), prompts.py, decision.py (TradeDecision)
  risk/             engine.py (stateless validator), state.py (SQLite-persisted counters)
  agent/            loop.py (state machine orchestrator)
  execution/        client.py (CCXT + Delta REST), orders.py, manager.py
  reflection/       detector.py (batch fills + intersection), pipeline.py (post-mortem → ChromaDB)
  memory/           protocols.py, chroma_store.py (ChromaDB), stub.py
  llm/              protocols.py, litellm_client.py, factory.py, langchain_bridge.py
  news/             poller.py (CryptoNews API + NewsCache with configurable TTL)
  health/           server.py (FastAPI /health), alerter.py (Telegram), telegram_bot.py
  persistence/      db.py (SQLite: analysis_cycles, orders, risk_state, agent_config)
  logging_setup.py  structlog JSON logs
  __main__.py       boots all subsystems, runs asyncio.gather
```

---

## SQLite Tables

| Table | Purpose |
|---|---|
| `analysis_cycles` | Per-trigger cycle state (`IN_FLIGHT`→`COMPLETED`/`REJECTED`/`CRASHED`) for crash recovery |
| `orders` | Full order lifecycle (PENDING→OPEN→CLOSED), PnL, `reflected` flag for dedup |
| `risk_state` | Daily counters: orders placed, loss USD, consecutive losses, circuit breaker flag |
| `agent_config` | Runtime flags: `trading_enabled` (toggled via Telegram) |

---

## Screener Rules

Rules are plain Python functions registered with `@rule("name")` in `screener/rules.py`. Thresholds come from `watchlist.yaml` per symbol — no code changes needed to tune sensitivity.

**Built-in rules:**

| Rule | Signal used | Key thresholds |
|---|---|---|
| `rsi_oversold` | `rsi_14` | `threshold` (default 30) |
| `rsi_overbought` | `rsi_14` | `threshold` (default 70) |
| `ema_cross_up` | `ema_fast_cross_up` | — |
| `ema_cross_down` | `ema_fast_cross_down` | — |
| `candle_momentum` | `close` price | `candles`, `min_pct`, `direction` |
| `volume_spike` | `volume` | `lookback`, `multiplier` |
| `price_near_ema` | `close`, `ema_N` | `ema_length`, `within_pct` |

---

## Risk Rules (all must pass)

| Rule | Config key | Default |
|---|---|---|
| Confidence ≥ threshold | `risk.min_confidence` | 0.65 |
| Leverage ≤ cap | `risk.max_leverage` | 20x |
| Open positions < max | `risk.max_positions` | 3 |
| Daily orders < max | `risk.max_orders_per_day` | 20 |
| Daily loss < max | `risk.max_daily_loss_usd` | $100 |
| Consecutive losses < max | `risk.max_consecutive_losses` | 3 |
| Circuit breaker OFF | auto-trips on consecutive loss limit | resets at UTC midnight |
| `trading_enabled` | Telegram `/pause` | true |

---

## Configuration

**`config/settings.yaml`** — all tunable parameters:

| Key | Default | Description |
|---|---|---|
| `active_profile` | `india_testnet` | Switch between testnet and mainnet |
| `screener.bar_history_size` | 200 | Rolling OHLCV window per symbol/timeframe |
| `screener.trigger_cooldown_minutes` | 5 | Min gap between triggers per symbol |
| `screener.default_rules.*` | RSI 30/70 + EMA cross | Fallback if symbol has no rules in watchlist |
| `risk.*` | see above | All risk limits |
| `llm.model` | `gemini/gemini-2.0-flash` | Any LiteLLM-supported model |
| `memory.rag_top_k` | 5 | Lessons injected per analysis cycle |
| `memory.max_lesson_chars` | 400 | Lesson size cap before ChromaDB storage |
| `execution.unfilled_limit_timeout_seconds` | 120 | Auto-cancel timeout for unfilled orders |
| `execution.fills_lookback_hours` | 24 | Exchange fill fetch window |
| `news.poll_interval_seconds` | 60 | How often to fetch news |
| `news.cache_ttl_seconds` | 120 | How long cached news stays fresh |
| `news.max_news_chars` | 1000 | Hard cap on news text injected into LLM prompt |

**`config/watchlist.yaml`** — per-symbol config:

```yaml
- symbol: BTCUSD
  quantity: 1
  leverage: 10
  indicators:
    - name: ema
      length: 9
  rules:
    - name: rsi_oversold
      thresholds:
        threshold: 30
    - name: candle_momentum
      thresholds:
        candles: 4
        min_pct: 0.1
        direction: up
```

---

## Telegram Commands

| Command | Effect |
|---|---|
| `/pause` | Stops new trades (risk engine rejects all actions) |
| `/resume` | Re-enables trading |
| `/status` | Shows enabled flag, open positions, daily PnL, circuit breaker |
| `/reset` | Manually resets circuit breaker |

---

## Environment Variables

```
DELTA_AGENT_ENV=india_testnet      # or india_mainnet
DELTA_API_KEY=
DELTA_API_SECRET=
GEMINI_API_KEY=
TELEGRAM_BOT_TOKEN=               # optional
TELEGRAM_CHAT_ID=                 # optional
CRYPTONEWS_API_KEY=               # optional — news disabled silently if missing
```

---

## Milestone Status

| Milestone | What | Status |
|---|---|---|
| M1 | Config, logging, LLM factory, memory interfaces | ✅ Done |
| M2 | WebSocket feed, BarStore, indicators, trigger gate | ✅ Done |
| M3 | Agent loop, analyzer, risk engine, SQLite persistence | ✅ Done |
| M4 | Exchange client (CCXT + Delta REST bracket orders), order lifecycle, startup reconciliation | ✅ Done |
| M5 | ChromaDB vector store, reflection pipeline, RAG injection | ✅ Done |
| M6 | News poller, Telegram alerts + bot, health endpoint, Docker + supervisord | ✅ Done |
