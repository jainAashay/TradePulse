# Delta Agent — Low Level Design

## Overview

delta-agent is a single Python process running an `asyncio` event loop. All subsystems are coroutines launched via `asyncio.gather()`. There is no thread pool — all I/O is async. SQLite is the only shared mutable state across subsystems; all access goes through `Database` which enforces WAL mode + connection-per-call.

---

## Module Map

```
src/delta_agent/
├── __main__.py              Boot sequence + asyncio.gather
├── config/
│   └── settings.py          Pydantic models; load_settings() merges YAML + env
├── screener/
│   ├── feed.py              DeltaFeed — WebSocket consumer
│   ├── bar_store.py         BarStore — rolling OHLCV deque per (symbol, timeframe)
│   ├── indicators.py        IndicatorRunner — pandas-ta compute on DataFrame
│   ├── rules.py             Rule registry — @rule("name") decorator + built-ins
│   └── trigger.py           TriggerGate + TriggerMap (latest-wins dedup)
├── analyzer/
│   ├── context.py           Analyzer — assembles prompt, calls LLM, returns TradeDecision
│   ├── prompts.py           build_messages() — system + user prompt templates
│   └── decision.py          TradeDecision pydantic model
├── risk/
│   ├── engine.py            RiskEngine — stateless hard-rule validator
│   └── state.py             RiskState — loaded from SQLite, mutated in-process
├── agent/
│   └── loop.py              AgentLoop — top-level state machine
├── execution/
│   ├── client.py            DeltaExchangeClient — CCXT async + Delta REST
│   ├── manager.py           ExecutionManager — bracket order + timeout watcher
│   └── orders.py            Order dataclass
├── reflection/
│   ├── detector.py          ClosedTradeDetector — batch fills poll + intersection
│   └── pipeline.py          ReflectionPipeline — post-mortem LLM + ChromaDB
├── memory/
│   ├── protocols.py         VectorMemory protocol
│   ├── chroma_store.py      ChromaVectorMemoryStore
│   └── stub.py              NoopMemory for testing
├── llm/
│   ├── protocols.py         LLMRuntime + LLMClient protocols
│   ├── litellm_client.py    LiteLLMClient — complete_json()
│   ├── langchain_bridge.py  LLMRuntime impl: fetch_learnings + format_learnings
│   └── factory.py           create_llm_runtime()
├── news/
│   └── poller.py            NewsPoller + NewsCache + SentimentSummary
├── health/
│   ├── server.py            FastAPI health endpoints
│   ├── alerter.py           Alerter — fire-and-forget Telegram messages
│   └── telegram_bot.py      TelegramCommandHandler — /pause /resume /status /reset
├── persistence/
│   └── db.py                Database — SQLite WAL, all table access
└── logging_setup.py         structlog JSON configuration
```

---

## Boot Sequence (`__main__.py`)

```
load_dotenv()
load_settings()          ← merges settings.yaml + watchlist.yaml + env vars
configure_logging()

Database.init()          ← CREATE TABLE IF NOT EXISTS, WAL mode
create_llm_runtime()     ← LiteLLMClient + ChromaVectorMemoryStore
RiskState.load(db)       ← recompute daily counters from orders table

register_builtins()      ← populate IndicatorRunner registry
BarStore(history_size)
TriggerMap()
TriggerGate(trigger_map, cooldown_minutes)
IndicatorRunner(bar_store)

_symbol_rules = {        ← pre-build RuleConfig lists from watchlist.yaml
  symbol: [RuleConfig(name, thresholds), ...]
}

DeltaExchangeClient(settings).init_ccxt()
Alerter()
NewsCache(ttl_seconds)
NewsPoller(config, symbols, cache)

ClosedTradeDetector(client, db, fills_lookback_hours)
ReflectionPipeline(detector, llm_runtime, memory, db, risk_state, alerter)

ExecutionManager(client, db, settings, reflection)
ExecutionManager.reconcile_on_startup()   ← diff exchange vs SQLite open orders
ReflectionPipeline.replay_unreflected()  ← catch any crash mid-reflection

Analyzer(llm_runtime, indicator_runner, risk_config, news_cache, max_news_chars)
RiskEngine(risk_config)

AgentLoop(...).startup()  ← crash IN_FLIGHT analysis_cycles
TelegramCommandHandler(alerter, db, risk_state)

asyncio.gather(
  feed.run(),
  agent_loop.run(),
  news_poller.run(),
  detector.run(),
  reflection.run(),
  tg_bot.run(),
  start_health_server(db, risk_state),
)
```

---

## Stage 1 — Screener Data Flow

### 1.1 WebSocket Feed (`feed.py`)

```
DeltaFeed.run()
  └─ connect to wss://<profile.ws_url>
     subscribe: {"type": "subscribe", "payload": {"channels": [
       {"name": "candlestick_1m", "symbols": [...]},
       {"name": "candlestick_5m", "symbols": [...]}
     ]}}
     
     on message:
       parse JSON → extract symbol, timeframe, bar dict {open, high, low, close, volume, timestamp}
       if bar.timestamp > last_seen_timestamp[symbol][timeframe]:   ← closed bar detection
         last_seen_timestamp[symbol][timeframe] = bar.timestamp
         await on_bar(symbol, timeframe, bar)
     
     on disconnect: exponential backoff (1s → 2s → 4s → ... → 60s cap) then reconnect
```

### 1.2 Bar Store (`bar_store.py`)

```
BarStore
  _bars: dict[(symbol, timeframe)] → asyncio.Lock + deque(maxlen=history_size)

push(symbol, timeframe, bar: dict):
  async with lock:
    deque.append(bar)

get_df(symbol, timeframe) → Optional[pd.DataFrame]:
  async with lock:
    if len(deque) == 0: return None
    return pd.DataFrame(list(deque))   ← copy, not view
    columns: open, high, low, close, volume, timestamp
```

### 1.3 Indicator Runner (`indicators.py`)

```
IndicatorRunner.compute(symbol, timeframe) → dict[str, float]:
  df = await bar_store.get_df(symbol, timeframe)
  if df is None or len(df) < min_periods: return {}
  
  for each registered indicator:
    apply pandas-ta function to df
    extract scalar value from last row
  
  _add_cross_events(df, signals):
    ema_fast_cross_up  = ema_fast[-1] > ema_slow[-1] and ema_fast[-2] <= ema_slow[-2]
    ema_fast_cross_down = ema_fast[-1] < ema_slow[-1] and ema_fast[-2] >= ema_slow[-2]
  
  return signals  ← {rsi_14: float, ema_9: float, ema_21: float, ...}
```

### 1.4 Rule Registry (`rules.py`)

```
_RULES: dict[str, RuleFn] = {}

RuleFn = Callable[[pd.DataFrame, dict[str, float], dict[str, Any]], bool]

@rule("name")              ← registers fn in _RULES at import time
def fn(df, signals, thresholds) -> bool: ...

Built-in rules:
  rsi_oversold(df, signals, t):    signals["rsi_14"] < t.get("threshold", 30)
  rsi_overbought(df, signals, t):  signals["rsi_14"] > t.get("threshold", 70)
  ema_cross_up(df, signals, t):    bool(signals.get("ema_fast_cross_up", 0))
  ema_cross_down(df, signals, t):  bool(signals.get("ema_fast_cross_down", 0))
  candle_momentum(df, signals, t): pct_change over last N candles vs min_pct + direction
  volume_spike(df, signals, t):    current vol > N-bar avg vol × multiplier
  price_near_ema(df, signals, t):  |close - ema_N| / ema_N × 100 <= within_pct
```

### 1.5 Trigger Gate (`trigger.py`)

```
TriggerGate.evaluate(symbol, timeframe, df, signals, rules, match_all=False):
  key = (symbol, timeframe)
  now = time.monotonic()
  
  # Cooldown check
  if now - last_trigger[key] < cooldown_s: return False
  
  # Evaluate each rule
  results = []
  for RuleConfig(name, thresholds) in rules:
    fn = get_rule(name)          ← lookup from registry
    passed = fn(df, signals, thresholds)
    results.append((name, passed))
  
  # OR semantics (default): any rule fires
  # AND semantics (match_all=True): all rules must fire
  triggered, fired_rule = ...
  
  if triggered:
    last_trigger[key] = now
    await trigger_map.put(TriggerEvent(symbol, timeframe, timestamp, signals, fired_rule))
    return True

TriggerMap (latest-wins dedup):
  _map: dict[symbol, TriggerEvent]     ← only one pending event per symbol
  _lock: asyncio.Lock
  _event: asyncio.Event

  put(evt):
    async with lock: _map[evt.symbol] = evt   ← replaces stale event
    _event.set()

  get_next() → TriggerEvent:           ← blocks until event available
    await _event.wait()
    async with lock: pop first symbol from _map
```

---

## Stage 2 — Analyzer Data Flow

### 2.1 Context Assembly (`context.py`)

```
Analyzer.analyze(event: TriggerEvent) → TradeDecision:

  1. Re-fetch live indicator signals
     signals = await indicator_runner.compute(event.symbol, event.timeframe)
     merged  = {**event.signals, **signals}    ← live values override snapshot

  2. News sentiment
     summary = news_cache.get(event.symbol)    ← None if stale/missing
     news_text = summary.as_text(max_chars=max_news_chars) if summary else None
     
     as_text() format:
       "Bullish: 6/10  Bearish: 3/10  Neutral: 1/10
        Headlines:
          [12m ago][Positive] Bitcoin breaks $70k resistance...
          [45m ago][Negative] Fed signals higher rates..."

  3. RAG query
     query = f"{symbol} {timeframe} RSI={rsi:.1f} trend={bullish|bearish}"
     records = llm_runtime.fetch_learnings(query)     ← ChromaDB top-K cosine search
     lessons = llm_runtime.format_learnings_for_prompt(records)

  4. Build prompt
     messages = build_messages(symbol, timeframe, ts, merged, lessons, news_text, ...)

  5. LLM call
     raw = llm_runtime.client.complete_json(messages)

  6. Parse + validate
     return TradeDecision.model_validate(raw)
```

### 2.2 Prompt Structure (`prompts.py`)

```
System message:
  "You are a disciplined quantitative trading analyst..."

  ## Prior Lessons          ← RAG lessons injected FIRST
  {lessons}

  ## Current Market State
  Symbol: {symbol} | Timeframe: {timeframe} | Timestamp: {ts}
  Indicators:
    ema_9:  67234.1234
    ema_21: 67100.5678
    rsi_14: 28.3200
    ...                     ← NaN values filtered out

  ## News Sentiment
  Bullish: 6/10  Bearish: 3/10  Neutral: 1/10
  Headlines:
    [12m ago][Positive] ...
    ...                     ← hard-capped at max_news_chars (default 1000)

  ## Risk Parameters
  Max leverage: {max_leverage}x | Min confidence: {min_confidence}

User message:
  "Analyse the above context and produce a trade decision as a single JSON object only..."
  Schema: { action, confidence, reasoning, leverage, sl_pct, tp_pcts }
```

### 2.3 TradeDecision (`decision.py`)

```python
class TradeDecision(BaseModel):
    action:     Literal["LONG", "SHORT", "HOLD"]
    confidence: float           # 0.0 – 1.0
    reasoning:  str             # CoT, 2-3 sentences
    leverage:   int             # suggested, capped by max_leverage
    sl_pct:     float           # stop-loss % distance from entry
    tp_pcts:    list[float]     # one or more take-profit % levels
```

---

## Stage 3 — Risk Engine Data Flow

### 3.1 RiskEngine (`engine.py`)

```
RiskEngine.validate(decision, state, trading_enabled) → RiskVerdict:

  Rules evaluated in order (first failure = rejected):
  1. trading_enabled == True
  2. state.circuit_breaker_active == False
  3. decision.action != "HOLD"
  4. decision.confidence >= cfg.min_confidence
  5. decision.leverage <= cfg.max_leverage
  6. state.open_positions < cfg.max_positions
  7. state.daily_orders < cfg.max_orders_per_day
  8. state.daily_loss_usd < cfg.max_daily_loss_usd
  9. state.consecutive_losses < cfg.max_consecutive_losses

  Returns RiskVerdict(approved: bool, reason: str)
```

### 3.2 RiskState (`state.py`)

```
RiskState:
  open_positions:       int     ← from reconcile_on_startup()
  daily_orders:         int     ← COUNT(orders WHERE date=today)
  daily_loss_usd:       float   ← SUM(pnl_usd WHERE pnl_usd < 0 AND date=today)
  consecutive_losses:   int     ← trailing streak from orders table
  circuit_breaker_active: bool  ← persisted in risk_state table
  trading_enabled:      bool    ← from agent_config table

RiskState.load(db):
  reads risk_state table for circuit_breaker + recomputes all counters from orders
  → guarantees correct state after any restart
```

---

## Stage 4 — Execution Data Flow

### 4.1 Order Placement (`manager.py`, `client.py`)

```
ExecutionManager.place_order(symbol, decision, quantity, leverage):

  1. Fetch orderbook
     ticker = await ccxt.fetch_ticker(symbol)
     entry_price = bid (LONG) or ask (SHORT)

  2. Compute prices
     sl_price = entry × (1 - sl_pct/100)  for LONG
                entry × (1 + sl_pct/100)  for SHORT
     tp_price = entry × (1 + tp_pcts[0]/100) for LONG
                entry × (1 - tp_pcts[0]/100) for SHORT

  3. Place bracket order via Delta REST POST /v2/orders
     payload = {
       "product_symbol": symbol,
       "order_type": "limit_order",
       "side": "buy"|"sell",
       "limit_price": entry_price,
       "size": quantity,
       "post_only": True,
       "leverage": leverage,
       "bracket_stop_loss_price": sl_price,
       "bracket_take_profit_price": tp_price,
     }
     signed with HMAC-SHA256(api_secret, timestamp + method + path + body)

  4. Persist to SQLite
     db.insert_order(symbol, side, entry_price, quantity, leverage,
                     sl_price, tp_price, external_order_id, status=PENDING)

  5. Launch timeout watcher
     asyncio.create_task(_cancel_if_unfilled(order_id, timeout_s))
     → after timeout: ccxt.cancel_order(external_order_id)
                      db.update_order_status(order_id, CANCELLED)

  6. Telegram alert
     alerter.send(f"Order placed: {symbol} {side} @ {entry_price} SL={sl_price} TP={tp_price}")
```

### 4.2 Startup Reconciliation

```
ExecutionManager.reconcile_on_startup():
  local_open   = db.get_open_orders()
  exchange_ids = {o["id"] for o in await ccxt.fetch_open_orders()}

  for order in local_open:
    if order.external_id NOT in exchange_ids:
      db.close_order(order.id, pnl_usd=None, closed_at=now)   ← filled or cancelled externally
    else:
      re-attach timeout watcher
  
  return count of still-open positions  →  risk_state.open_positions
```

---

## Stage 5 — Reflection Data Flow

### 5.1 ClosedTradeDetector (`detector.py`)

```
ClosedTradeDetector.run():
  loop every poll_interval (30s):
    await _poll()

_poll():
  1. unresolved = db.get_unresolved_orders()       ← WHERE reflected=0 AND status!=CANCELLED
     if empty: return

  2. local_by_ext_id = {row.external_order_id: row for row in unresolved}

  3. exchange_fills = await client.get_fills(lookback_hours=24)
     ← CCXT fetch_closed_orders(since=now-24h) OR Delta REST /v2/fills?start_time=
     ← bounded response regardless of trading history length

  4. closed_ext_ids = {str(f["order_id"]) for f in exchange_fills}

  5. to_reflect = intersection(closed_ext_ids, local_by_ext_id.keys())
     ← only orders that are: closed on exchange AND unreflected in SQLite

  6. for each matched order:
       pnl   = fill.get("realized_pnl") or fill.get("pnl")
       hold_s = (now - db_row.created_at).total_seconds()
       db.close_order(order_id, pnl_usd=pnl, closed_at=now)
       await queue.put(ClosedTradeEvent(...))
```

### 5.2 ReflectionPipeline (`pipeline.py`)

```
ReflectionPipeline.run():
  loop:
    evt = await detector.queue.get()   ← ClosedTradeEvent
    await _reflect(evt)

_reflect(evt):
  1. Load original analysis from db.get_analysis_cycle(evt.order_id)
     hypothesis = cycle.llm_reasoning

  2. Build post-mortem prompt
     "Trade: {symbol} {side}. Entry: {price}. PnL: {pnl}. Hold: {mins}m.
      Original hypothesis: {hypothesis}
      What can be learned for future trades? Be concise."

  3. LLM call → raw_lesson (free-form text)

  4. Refine lesson
     "Compress this lesson to ≤400 chars without losing key insight: {raw_lesson}"
     → compact_lesson

  5. ChromaDB write
     memory.add_learning(compact_lesson, metadata={
       symbol, side, pnl_usd, hold_minutes,
       outcome: "win"|"loss", timeframe
     })

  6. Idempotency gate
     db.mark_reflected(evt.order_id)     ← only after ChromaDB write succeeds

  7. Update risk counters
     if pnl < 0: risk_state.consecutive_losses += 1
     else:       risk_state.consecutive_losses = 0
     if consecutive_losses >= max: risk_state.circuit_breaker_active = True

  8. Telegram alert
     alerter.send(f"Trade closed: {symbol} PnL={pnl} ({win|loss})")

replay_unreflected():   ← called once on startup
  orders = db.get_unreflected_closed_orders()
  for each: await _reflect(synthetic_event)
  ← covers crash recovery if agent was down during reflection
```

---

## News Poller Data Flow

```
NewsPoller.run():
  if no api_key: return (disabled silently)
  await _fetch_all()          ← initial fetch on boot
  loop every poll_interval_seconds (default 60):
    await _fetch_all()

_fetch(symbol):
  ticker = symbol.replace("USD","").replace("PERP","")
  GET https://cryptonews-api.com/api/v1/crypto-ticker-news
    ?tickers={ticker}&items=10&token={api_key}

  for each article:
    sentiment = article["sentiment"]   ← "Positive" | "Negative" | "Neutral"
    date_str  = article["date"]        ← "Mon, 02 Jun 2025 14:30:00 -0400"

  SentimentSummary(
    bullish_count, bearish_count, neutral_count,
    top_headlines = [(title, date_str, sentiment), ...][:5]
  )
  cache.put(symbol, summary)

NewsCache.get(symbol):
  if summary.is_stale(ttl_seconds): return None   ← ttl default 120s
  return summary

SentimentSummary.as_text(max_chars=1000):
  "Bullish: 6/10  Bearish: 3/10  Neutral: 1/10
   Headlines:
     [12m ago][Positive] Bitcoin breaks...   ← age computed from date_str
     [45m ago][Negative] Fed signals..."
  ← budget-based truncation per headline (150 char cap) + final [:max_chars] slice
```

---

## Persistence Layer (`db.py`)

### Schema

```sql
CREATE TABLE analysis_cycles (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol        TEXT NOT NULL,
  timeframe     TEXT NOT NULL,
  triggered_at  TEXT NOT NULL,
  status        TEXT NOT NULL,    -- IN_FLIGHT | COMPLETED | REJECTED | CRASHED
  llm_reasoning TEXT,
  order_id      INTEGER
);

CREATE TABLE orders (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  external_order_id   TEXT UNIQUE,
  symbol              TEXT NOT NULL,
  side                TEXT NOT NULL,    -- buy | sell
  entry_price         REAL,
  quantity            REAL,
  leverage            INTEGER,
  sl_price            REAL,
  tp_price            REAL,
  status              TEXT NOT NULL,    -- PENDING | OPEN | CLOSED | CANCELLED
  pnl_usd             REAL,
  reflected           INTEGER NOT NULL DEFAULT 0,   -- idempotency flag
  created_at          TEXT NOT NULL,
  closed_at           TEXT
);

CREATE TABLE risk_state (
  id                    INTEGER PRIMARY KEY DEFAULT 1,
  daily_orders          INTEGER DEFAULT 0,
  daily_loss_usd        REAL DEFAULT 0.0,
  consecutive_losses    INTEGER DEFAULT 0,
  circuit_breaker_active INTEGER DEFAULT 0,
  last_reset_date       TEXT
);

CREATE TABLE agent_config (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
-- key='trading_enabled', value='true'|'false'
```

### Key queries

```
get_unresolved_orders()    WHERE reflected=0 AND status NOT IN ('CANCELLED')
get_open_orders()          WHERE status IN ('PENDING', 'OPEN')
mark_reflected(order_id)   UPDATE orders SET reflected=1 WHERE id=?
close_order(id, pnl, at)   UPDATE orders SET status='CLOSED', pnl_usd=?, closed_at=?
get_unreflected_closed()   WHERE status='CLOSED' AND reflected=0
```

---

## AgentLoop State Machine (`loop.py`)

```
startup():
  db.crash_inflight_cycles()   ← UPDATE analysis_cycles SET status='CRASHED' WHERE status='IN_FLIGHT'

run():
  loop forever:
    evt = await trigger_map.get_next()           ← blocks until TriggerEvent available

    cycle_id = db.create_cycle(evt.symbol, evt.timeframe, status=IN_FLIGHT)

    try:
      decision = await analyzer.analyze(evt)     ← LLM call

      verdict = risk_engine.validate(decision, risk_state, trading_enabled)

      if verdict.approved:
        watchlist_entry = find(symbol)
        order = await execution_manager.place_order(
          evt.symbol, decision, watchlist_entry.quantity, decision.leverage
        )
        risk_state.daily_orders += 1
        db.complete_cycle(cycle_id, order_id=order.id, reasoning=decision.reasoning)
      else:
        db.reject_cycle(cycle_id, reason=verdict.reason)
        alerter.send(f"Trade rejected: {verdict.reason}")

    except Exception as exc:
      db.crash_cycle(cycle_id, error=str(exc))
      log.error("agent_loop_error", error=str(exc))
```

---

## Health & Control Plane

### Health Server (`server.py`)

```
FastAPI app on port 8080

GET /health
  returns:
    status: "ok" | "degraded"
    trading_enabled: bool
    circuit_breaker: bool
    open_positions: int
    daily_orders: int
    daily_loss_usd: float

POST /health/reset-circuit-breaker
  risk_state.circuit_breaker_active = False
  db.update_risk_state(circuit_breaker=False)
```

### Telegram Bot (`telegram_bot.py`)

```
TelegramCommandHandler.run():
  loop every 3s:
    GET /getUpdates?offset={offset}&timeout=2
    for each update:
      if update.message.chat.id != TELEGRAM_CHAT_ID: ignore   ← chat_id gate
      dispatch command:
        /pause  → db.set_config("trading_enabled", "false")
        /resume → db.set_config("trading_enabled", "true")
        /status → build status string from risk_state + db counters
        /reset  → risk_state.circuit_breaker_active = False
```

### Alerter (`alerter.py`)

```
Alerter.send(message: str):
  asyncio.create_task(_post(message))   ← fire-and-forget, never blocks agent loop

_post(message):
  POST https://api.telegram.org/bot{token}/sendMessage
    chat_id={TELEGRAM_CHAT_ID}
    text={message}
  on error: log warning only, never raise
```

---

## LLM Layer

```
LLMRuntime (langchain_bridge.py):
  client:   LiteLLMClient
  memory:   ChromaVectorMemoryStore

  fetch_learnings(query) → list[dict]:
    memory.search(query, top_k=rag_top_k)   ← cosine similarity on all-MiniLM-L6-v2 embeddings

  format_learnings_for_prompt(records) → str:
    "\n".join([f"- {r['text']}" for r in records])
    ← injected at top of system prompt

LiteLLMClient.complete_json(messages) → dict:
  litellm.completion(
    model=settings.llm.model,
    messages=messages,
    temperature=0.2,
    max_tokens=2048,
    response_format={"type": "json_object"},
  )
  → parse JSON from response.choices[0].message.content

ChromaVectorMemoryStore (chroma_store.py):
  client = chromadb.PersistentClient(path=chroma_persist_dir)
  embedder = SentenceTransformer("all-MiniLM-L6-v2")   ← local, no API cost

  add_learning(text, metadata):
    embedding = embedder.encode(text)
    collection.add(documents=[text], embeddings=[embedding], metadatas=[metadata])

  search(query, top_k) → list[dict]:
    q_embedding = embedder.encode(query)
    collection.query(query_embeddings=[q_embedding], n_results=top_k)
```

---

## Configuration Reference

### `settings.yaml` keys

| Section | Key | Type | Default | Description |
|---|---|---|---|---|
| `screener` | `bar_history_size` | int | 200 | Rolling bar window per (symbol, timeframe) |
| `screener` | `trigger_cooldown_minutes` | int | 5 | Min gap between triggers per symbol |
| `screener.default_rules` | `rsi_oversold` | float | 30 | Fallback RSI low threshold |
| `screener.default_rules` | `rsi_overbought` | float | 70 | Fallback RSI high threshold |
| `screener.default_rules` | `require_ema_cross` | bool | true | AND EMA cross into fallback rules |
| `risk` | `max_daily_loss_usd` | float | 100 | Daily drawdown limit |
| `risk` | `max_orders_per_day` | int | 20 | Daily order count limit |
| `risk` | `min_confidence` | float | 0.65 | LLM confidence floor |
| `risk` | `max_leverage` | int | 20 | Hard leverage cap |
| `risk` | `max_positions` | int | 3 | Max concurrent open positions |
| `risk` | `max_consecutive_losses` | int | 3 | Circuit breaker trip threshold |
| `llm` | `model` | str | `gemini/gemini-2.0-flash` | LiteLLM model string |
| `llm` | `temperature` | float | 0.2 | LLM temperature |
| `memory` | `rag_top_k` | int | 5 | Lessons retrieved per analysis |
| `memory` | `max_lesson_chars` | int | 400 | Lesson size cap before ChromaDB write |
| `execution` | `unfilled_limit_timeout_seconds` | int | 120 | Auto-cancel timeout |
| `execution` | `fills_lookback_hours` | int | 24 | Exchange fill fetch window |
| `news` | `poll_interval_seconds` | int | 60 | News fetch frequency |
| `news` | `cache_ttl_seconds` | int | 120 | News cache expiry |
| `news` | `max_news_chars` | int | 1000 | Hard cap on news in LLM prompt |

### `watchlist.yaml` per-symbol keys

| Key | Type | Description |
|---|---|---|
| `symbol` | str | Delta Exchange symbol (e.g. `BTCUSD`) |
| `quantity` | float | Fixed order size in contracts |
| `leverage` | int | Fixed leverage (validated against `max_leverage`) |
| `indicators` | list | `[{name: ema, length: 9}, {name: rsi, length: 14}, ...]` |
| `rules` | list | `[{name: rsi_oversold, thresholds: {threshold: 30}}, ...]` |
