"""Agent entrypoint: boots all subsystems and runs the async event loop."""

from __future__ import annotations

import asyncio

from dotenv import load_dotenv

from delta_agent.agent.loop import AgentLoop
from delta_agent.analyzer.context import Analyzer
from delta_agent.config import load_settings
from delta_agent.execution.client import DeltaExchangeClient
from delta_agent.execution.manager import ExecutionManager
from delta_agent.health.alerter import Alerter
from delta_agent.health.server import start_health_server
from delta_agent.health.telegram_bot import TelegramCommandHandler
from delta_agent.llm import create_llm_runtime
from delta_agent.logging_setup import configure_logging, get_logger
from delta_agent.news.poller import NewsCache, NewsPoller
from delta_agent.persistence.db import Database
from delta_agent.reflection.detector import ClosedTradeDetector
from delta_agent.reflection.pipeline import ReflectionPipeline
from delta_agent.risk.engine import RiskEngine
from delta_agent.risk.state import RiskState
from delta_agent.screener.bar_store import BarStore
from delta_agent.screener.feed import DeltaFeed
from delta_agent.screener.indicators import IndicatorRunner, register_builtins
from delta_agent.screener.trigger import RuleConfig, TriggerGate, TriggerMap


async def run() -> None:
    load_dotenv()
    settings = load_settings()
    configure_logging(settings.log_level)
    log = get_logger("delta_agent.main")

    symbols = [w.symbol for w in settings.watchlist.watchlist]
    timeframes = settings.screener.timeframes

    # Pre-build RuleConfig lists per symbol from watchlist; fall back to default RSI+EMA rules
    _default_rules = [
        RuleConfig("rsi_oversold", {"threshold": settings.screener.default_rules.rsi_oversold}),
        RuleConfig("rsi_overbought", {"threshold": settings.screener.default_rules.rsi_overbought}),
    ]
    if settings.screener.default_rules.require_ema_cross:
        _default_rules += [
            RuleConfig("ema_cross_up", {}),
            RuleConfig("ema_cross_down", {}),
        ]
    _symbol_rules: dict[str, list[RuleConfig]] = {
        w.symbol: [RuleConfig(r["name"], r.get("thresholds") or {}) for r in w.rules] or _default_rules
        for w in settings.watchlist.watchlist
    }

    log.info("booting", profile=settings.active_profile, symbols=symbols, timeframes=timeframes)

    # ── Persistence ────────────────────────────────────────────────────────
    db = Database(settings.persistence.sqlite_path)

    # ── LLM + Memory ───────────────────────────────────────────────────────
    llm_runtime = create_llm_runtime(settings)

    # ── Risk state (load + recompute from DB) ──────────────────────────────
    risk_state = RiskState.load(db)

    # ── Screener ───────────────────────────────────────────────────────────
    register_builtins()
    bar_store = BarStore(history_size=settings.screener.bar_history_size)
    trigger_map = TriggerMap()
    trigger_gate = TriggerGate(trigger_map, cooldown_minutes=settings.screener.trigger_cooldown_minutes)
    indicator_runner = IndicatorRunner(bar_store)

    async def on_bar(symbol: str, timeframe: str, bar: dict) -> None:
        await bar_store.push(symbol, timeframe, bar)
        df = await bar_store.get_df(symbol, timeframe)
        signals = await indicator_runner.compute(symbol, timeframe)
        if not signals or df is None or df.empty:
            return
        rules = _symbol_rules.get(symbol, _default_rules)
        await trigger_gate.evaluate(symbol, timeframe, df, signals, rules)

    feed = DeltaFeed(
        ws_url=settings.profile.delta.ws_url,
        symbols=symbols,
        timeframes=timeframes,
        on_bar=on_bar,
    )

    # ── Exchange client ─────────────────────────────────────────────────────
    exchange_client = DeltaExchangeClient(settings)
    await exchange_client.init_ccxt()

    # ── Alerter ────────────────────────────────────────────────────────────
    alerter = Alerter()

    # ── News cache + poller ────────────────────────────────────────────────
    news_cache = NewsCache(ttl_seconds=settings.news.cache_ttl_seconds)
    news_poller = NewsPoller(settings.news, symbols, news_cache)

    # ── Reflection ─────────────────────────────────────────────────────────
    detector = ClosedTradeDetector(
        exchange_client, db,
        fills_lookback_hours=settings.execution.fills_lookback_hours,
    )
    reflection = ReflectionPipeline(
        detector=detector,
        llm_runtime=llm_runtime,
        memory=llm_runtime.memory,
        db=db,
        risk_state=risk_state,
        max_lesson_chars=settings.memory.max_lesson_chars,
        alerter=alerter,
    )

    # ── Execution ──────────────────────────────────────────────────────────
    execution_manager = ExecutionManager(exchange_client, db, settings, reflection=reflection)

    # Startup reconciliation
    open_positions = await execution_manager.reconcile_on_startup()
    risk_state.open_positions = open_positions

    # Replay any closed orders that never produced a ChromaDB lesson (crash recovery)
    await reflection.replay_unreflected()

    # ── Analyzer ──────────────────────────────────────────────────────────
    analyzer = Analyzer(
        llm_runtime=llm_runtime,
        indicator_runner=indicator_runner,
        risk_config=settings.risk,
        news_cache=news_cache,
        max_news_chars=settings.news.max_news_chars,
    )

    # ── Risk engine ────────────────────────────────────────────────────────
    risk_engine = RiskEngine(settings.risk)

    # ── Agent loop ─────────────────────────────────────────────────────────
    agent_loop = AgentLoop(
        trigger_map=trigger_map,
        analyzer=analyzer,
        risk_engine=risk_engine,
        risk_state=risk_state,
        db=db,
        execution_manager=execution_manager,
        alerter=alerter,
    )
    agent_loop.startup()  # crash stale IN_FLIGHT cycles

    # ── Telegram bot ───────────────────────────────────────────────────────
    tg_bot = TelegramCommandHandler(alerter, db, risk_state)

    log.info("all_subsystems_ready", memory_backend=type(llm_runtime.memory).__name__)

    # ── Run all tasks concurrently ─────────────────────────────────────────
    await asyncio.gather(
        feed.run(),
        agent_loop.run(),
        news_poller.run(),
        detector.run(),
        reflection.run(),
        tg_bot.run(),
        start_health_server(db, risk_state),
    )


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
