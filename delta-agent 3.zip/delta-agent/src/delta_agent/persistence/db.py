"""SQLite persistence: schema creation, DAOs for all tables."""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _today_utc() -> str:
    return datetime.now(timezone.utc).date().isoformat()


class Database:
    """Thin wrapper around sqlite3 with schema creation and DAOs."""

    def __init__(self, path: str) -> None:
        self._path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_schema()

    def _create_schema(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS analysis_cycles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                triggered_at TEXT NOT NULL,
                status TEXT NOT NULL,
                decision_json TEXT,
                rejection_reason TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                external_order_id TEXT UNIQUE,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                quantity REAL NOT NULL,
                leverage INTEGER NOT NULL,
                entry_price REAL,
                sl_price REAL,
                tp_prices TEXT,
                status TEXT NOT NULL,
                pnl_usd REAL,
                reflected INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                filled_at TEXT,
                closed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS risk_state (
                date TEXT PRIMARY KEY,
                daily_orders INTEGER NOT NULL DEFAULT 0,
                daily_loss_usd REAL NOT NULL DEFAULT 0.0,
                consecutive_losses INTEGER NOT NULL DEFAULT 0,
                circuit_breaker_active INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS agent_config (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
        """)
        # Seed trading_enabled flag
        self._conn.execute(
            "INSERT OR IGNORE INTO agent_config (key, value, updated_at) VALUES (?, ?, ?)",
            ("trading_enabled", "true", _utcnow()),
        )
        self._conn.commit()

    @contextmanager
    def _tx(self) -> Generator[sqlite3.Connection, None, None]:
        try:
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    # ── analysis_cycles ──────────────────────────────────────────────────────

    def create_cycle(self, symbol: str, timeframe: str, triggered_at: str) -> int:
        with self._tx() as c:
            cur = c.execute(
                "INSERT INTO analysis_cycles (symbol, timeframe, triggered_at, status, created_at) VALUES (?,?,?,?,?)",
                (symbol, timeframe, triggered_at, "IN_FLIGHT", _utcnow()),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def update_cycle(
        self,
        cycle_id: int,
        status: str,
        decision_json: Optional[str] = None,
        rejection_reason: Optional[str] = None,
    ) -> None:
        with self._tx() as c:
            c.execute(
                "UPDATE analysis_cycles SET status=?, decision_json=?, rejection_reason=? WHERE id=?",
                (status, decision_json, rejection_reason, cycle_id),
            )

    def crash_inflight_cycles(self) -> int:
        """Mark all IN_FLIGHT cycles as CRASHED on startup. Returns count."""
        with self._tx() as c:
            cur = c.execute(
                "UPDATE analysis_cycles SET status='CRASHED' WHERE status='IN_FLIGHT'"
            )
            return cur.rowcount

    # ── orders ───────────────────────────────────────────────────────────────

    def insert_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        leverage: int,
        entry_price: float,
        sl_price: float,
        tp_prices: List[float],
        external_order_id: Optional[str] = None,
    ) -> int:
        with self._tx() as c:
            cur = c.execute(
                """INSERT INTO orders
                   (external_order_id, symbol, side, quantity, leverage,
                    entry_price, sl_price, tp_prices, status, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    external_order_id, symbol, side, quantity, leverage,
                    entry_price, sl_price, json.dumps(tp_prices), "PENDING", _utcnow(),
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def update_order_status(
        self,
        order_id: int,
        status: str,
        *,
        external_order_id: Optional[str] = None,
        filled_at: Optional[str] = None,
        closed_at: Optional[str] = None,
        pnl_usd: Optional[float] = None,
    ) -> None:
        with self._tx() as c:
            c.execute(
                """UPDATE orders SET status=?,
                   external_order_id=COALESCE(?, external_order_id),
                   filled_at=COALESCE(?, filled_at),
                   closed_at=COALESCE(?, closed_at),
                   pnl_usd=COALESCE(?, pnl_usd)
                   WHERE id=?""",
                (status, external_order_id, filled_at, closed_at, pnl_usd, order_id),
            )

    def mark_reflected(self, order_id: int) -> None:
        """Call after ChromaDB lesson is successfully stored."""
        with self._tx() as c:
            c.execute("UPDATE orders SET reflected=1 WHERE id=?", (order_id,))

    def get_unreflected_closed_orders(self) -> List[Dict[str, Any]]:
        """Returns CLOSED orders that haven't produced a ChromaDB lesson yet."""
        rows = self._conn.execute(
            "SELECT * FROM orders WHERE status='CLOSED' AND reflected=0"
        ).fetchall()
        return [dict(r) for r in rows]

    def get_unresolved_orders(self) -> List[Dict[str, Any]]:
        """All orders not yet reflected — used to intersect with exchange fills."""
        rows = self._conn.execute(
            "SELECT * FROM orders WHERE reflected=0 AND external_order_id IS NOT NULL"
        ).fetchall()
        return [dict(r) for r in rows]

    def close_order(self, order_id: int, pnl_usd: Optional[float], closed_at: str) -> None:
        with self._tx() as c:
            c.execute(
                "UPDATE orders SET status='CLOSED', pnl_usd=?, closed_at=? WHERE id=?",
                (pnl_usd, closed_at, order_id),
            )

    def get_open_orders(self) -> List[Dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM orders WHERE status IN ('PENDING', 'OPEN')"
        ).fetchall()
        return [dict(r) for r in rows]

    def get_today_orders(self) -> List[Dict[str, Any]]:
        today = _today_utc()
        rows = self._conn.execute(
            "SELECT * FROM orders WHERE date(created_at)=?", (today,)
        ).fetchall()
        return [dict(r) for r in rows]

    def upsert_order_by_external_id(self, external_order_id: str, **kwargs: Any) -> None:
        existing = self._conn.execute(
            "SELECT id FROM orders WHERE external_order_id=?", (external_order_id,)
        ).fetchone()
        if existing:
            self.update_order_status(existing["id"], kwargs.get("status", "OPEN"), external_order_id=external_order_id)
        else:
            self.insert_order(
                symbol=kwargs["symbol"],
                side=kwargs["side"],
                quantity=kwargs["quantity"],
                leverage=kwargs.get("leverage", 1),
                entry_price=kwargs.get("entry_price", 0.0),
                sl_price=kwargs.get("sl_price", 0.0),
                tp_prices=kwargs.get("tp_prices", []),
                external_order_id=external_order_id,
            )

    # ── risk_state ───────────────────────────────────────────────────────────

    def load_risk_state(self) -> Dict[str, Any]:
        today = _today_utc()
        row = self._conn.execute("SELECT * FROM risk_state WHERE date=?", (today,)).fetchone()
        if row:
            return dict(row)
        return {
            "date": today,
            "daily_orders": 0,
            "daily_loss_usd": 0.0,
            "consecutive_losses": 0,
            "circuit_breaker_active": 0,
        }

    def save_risk_state(self, state: Dict[str, Any]) -> None:
        with self._tx() as c:
            c.execute(
                """INSERT OR REPLACE INTO risk_state
                   (date, daily_orders, daily_loss_usd, consecutive_losses, circuit_breaker_active)
                   VALUES (?,?,?,?,?)""",
                (
                    state["date"],
                    state["daily_orders"],
                    state["daily_loss_usd"],
                    state["consecutive_losses"],
                    int(state["circuit_breaker_active"]),
                ),
            )

    # ── agent_config ─────────────────────────────────────────────────────────

    def get_config(self, key: str) -> Optional[str]:
        row = self._conn.execute("SELECT value FROM agent_config WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_config(self, key: str, value: str) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT OR REPLACE INTO agent_config (key, value, updated_at) VALUES (?,?,?)",
                (key, value, _utcnow()),
            )

    def is_trading_enabled(self) -> bool:
        val = self.get_config("trading_enabled")
        return (val or "true").lower() == "true"

    def close(self) -> None:
        self._conn.close()
