"""CryptoPanic news poller with 5-minute cache."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import httpx

from delta_agent.config.settings import NewsConfig
from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

_CRYPTOPANIC_URL = "https://cryptopanic.com/api/v1/posts/"
_CACHE_TTL_S = 15 * 60  # 15 minutes stale threshold for "unavailable" notice
_POLL_INTERVAL_S = 5 * 60  # poll every 5 minutes


@dataclass
class SentimentSummary:
    bullish_count: int
    bearish_count: int
    top_headlines: List[str]
    fetched_at: float = field(default_factory=time.time)

    def is_stale(self) -> bool:
        return (time.time() - self.fetched_at) > _CACHE_TTL_S


class NewsCache:
    """Thread-safe in-memory cache of SentimentSummary keyed by symbol."""

    def __init__(self) -> None:
        self._cache: Dict[str, SentimentSummary] = {}

    def put(self, symbol: str, summary: SentimentSummary) -> None:
        self._cache[symbol] = summary

    def get(self, symbol: str) -> Optional[SentimentSummary]:
        s = self._cache.get(symbol)
        if s and s.is_stale():
            return None
        return s


class NewsPoller:
    """
    Background asyncio task. Polls CryptoPanic every 5 minutes.
    Silently disabled if API key is missing.
    """

    def __init__(self, config: NewsConfig, symbols: List[str], cache: NewsCache) -> None:
        self._config = config
        self._symbols = symbols
        self._cache = cache
        self._api_key = config.resolve_api_key()
        self._running = False

    async def run(self) -> None:
        if not self._api_key:
            log.info("news_poller_disabled_no_api_key")
            return
        self._running = True
        # Initial fetch immediately
        await self._fetch_all()
        while self._running:
            await asyncio.sleep(_POLL_INTERVAL_S)
            await self._fetch_all()

    async def stop(self) -> None:
        self._running = False

    async def _fetch_all(self) -> None:
        for symbol in self._symbols:
            try:
                await self._fetch(symbol)
            except Exception as exc:
                log.warning("news_fetch_error", symbol=symbol, error=str(exc))

    async def _fetch(self, symbol: str) -> None:
        # CryptoPanic uses currency codes like BTC, ETH
        currency = symbol.replace("USD", "").replace("PERP", "")
        params = {
            "auth_token": self._api_key,
            "currencies": currency,
            "filter": self._config.filter,
            "public": "true",
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(_CRYPTOPANIC_URL, params=params)
            resp.raise_for_status()
            data = resp.json()

        results = data.get("results", [])
        bullish = sum(1 for r in results if r.get("votes", {}).get("positive", 0) > r.get("votes", {}).get("negative", 0))
        bearish = len(results) - bullish
        headlines = [r.get("title", "") for r in results[:5] if r.get("title")]

        summary = SentimentSummary(
            bullish_count=bullish,
            bearish_count=bearish,
            top_headlines=headlines,
        )
        self._cache.put(symbol, summary)
        log.debug("news_fetched", symbol=symbol, bullish=bullish, bearish=bearish)
