"""Closed trade detector: polls exchange for filled/closed orders."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from delta_agent.execution.orders import OrderStatus
from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database

if TYPE_CHECKING:
    from delta_agent.execution.client import DeltaExchangeClient

log = get_logger(__name__)


@dataclass
class ClosedTradeEvent:
    order_id: int
    external_order_id: str
    symbol: str
    pnl_usd: Optional[float]
    hold_seconds: float
    closed_at: str


class ClosedTradeDetector:
    """Background task polling every 30s for closed positions."""

    def __init__(
        self,
        client: "DeltaExchangeClient",
        db: Database,
        poll_interval: int = 30,
    ) -> None:
        self._client = client
        self._db = db
        self._interval = poll_interval
        self._queue: asyncio.Queue[ClosedTradeEvent] = asyncio.Queue()
        self._running = False

    @property
    def queue(self) -> asyncio.Queue[ClosedTradeEvent]:
        return self._queue

    async def run(self) -> None:
        self._running = True
        while self._running:
            await asyncio.sleep(self._interval)
            try:
                await self._poll()
            except Exception as exc:
                log.error("detector_poll_error", error=str(exc))

    async def stop(self) -> None:
        self._running = False

    async def _poll(self) -> None:
        open_orders = self._db.get_open_orders()
        if not open_orders:
            return

        for db_order in open_orders:
            ext_id = db_order.get("external_order_id")
            if not ext_id:
                continue
            try:
                ex_order = await self._client.fetch_order(ext_id, db_order["symbol"])
            except Exception as exc:
                log.warning("fetch_order_failed", ext_id=ext_id, error=str(exc))
                continue

            ex_status = ex_order.get("state", ex_order.get("status", ""))
            if ex_status in ("closed", "filled", "cancelled"):
                pnl = ex_order.get("pnl") or ex_order.get("realized_pnl")
                closed_at = datetime.now(timezone.utc).isoformat()

                # Compute hold time
                created_at = db_order.get("created_at", "")
                try:
                    created_dt = datetime.fromisoformat(created_at)
                    closed_dt = datetime.now(timezone.utc)
                    hold_s = (closed_dt - created_dt).total_seconds()
                except Exception:
                    hold_s = 0.0

                self._db.update_order_status(
                    db_order["id"], OrderStatus.CLOSED,
                    closed_at=closed_at,
                    pnl_usd=float(pnl) if pnl is not None else None,
                )
                evt = ClosedTradeEvent(
                    order_id=db_order["id"],
                    external_order_id=ext_id,
                    symbol=db_order["symbol"],
                    pnl_usd=float(pnl) if pnl is not None else None,
                    hold_seconds=hold_s,
                    closed_at=closed_at,
                )
                await self._queue.put(evt)
                log.info("trade_closed_detected", order_id=db_order["id"], symbol=db_order["symbol"], pnl=pnl)
