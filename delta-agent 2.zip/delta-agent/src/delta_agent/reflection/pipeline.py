"""Post-mortem pipeline: closed trade → LLM lesson → ChromaDB."""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from delta_agent.llm.factory import LLMBackedLearningRefiner
from delta_agent.llm.protocols import ChatMessage, LLMRuntime
from delta_agent.logging_setup import get_logger
from delta_agent.memory.protocols import LearningRecord, VectorMemoryStore
from delta_agent.persistence.db import Database
from delta_agent.reflection.detector import ClosedTradeDetector, ClosedTradeEvent
from delta_agent.risk.state import RiskState

if TYPE_CHECKING:
    from delta_agent.health.alerter import Alerter

log = get_logger(__name__)

_REFLECTION_SYSTEM = (
    "You are a trading post-mortem analyst. Given the original trade hypothesis and the actual outcome, "
    "extract one precise lesson (max {max_chars} chars) that would help avoid repeating mistakes or "
    "reinforce what worked. Output plain text only — no markdown, no filler."
)

_REFLECTION_USER = """\
Original hypothesis:
{reasoning}

Trade details:
- Symbol: {symbol}
- Action: {action}
- Confidence: {confidence}
- Leverage: {leverage}x
- SL%: {sl_pct}

Actual outcome:
- PnL: {pnl} USD
- Hold time: {hold_mins:.1f} minutes
- Outcome: {outcome}

Write a single actionable lesson.
"""


class ReflectionPipeline:
    """
    Consumes ClosedTradeEvents from the detector queue.
    Runs LLM post-mortem → refines lesson → stores in ChromaDB.
    Updates risk state (consecutive losses).
    """

    def __init__(
        self,
        detector: ClosedTradeDetector,
        llm_runtime: LLMRuntime,
        memory: VectorMemoryStore,
        db: Database,
        risk_state: RiskState,
        max_lesson_chars: int = 400,
        alerter: Optional["Alerter"] = None,
    ) -> None:
        self._detector = detector
        self._llm = llm_runtime
        self._memory = memory
        self._db = db
        self._risk_state = risk_state
        self._max_chars = max_lesson_chars
        self._alerter = alerter
        self._running = False

    async def run(self) -> None:
        self._running = True
        while self._running:
            try:
                evt = await asyncio.wait_for(self._detector.queue.get(), timeout=5.0)
                await self._process(evt)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.error("reflection_pipeline_error", error=str(exc), exc_info=True)

    async def stop(self) -> None:
        self._running = False

    async def trigger(self, order_id: int, pnl_usd: Optional[float]) -> None:
        """Manually trigger reflection for an order (used in reconciliation)."""
        open_orders = self._db.get_open_orders()
        match = next((o for o in open_orders if o["id"] == order_id), None)
        if not match:
            return
        evt = ClosedTradeEvent(
            order_id=order_id,
            external_order_id=match.get("external_order_id", ""),
            symbol=match["symbol"],
            pnl_usd=pnl_usd,
            hold_seconds=0.0,
            closed_at=datetime.now(timezone.utc).isoformat(),
        )
        await self._process(evt)

    async def _process(self, evt: ClosedTradeEvent) -> None:
        # Load original decision from analysis_cycles
        row = self._db._conn.execute(
            "SELECT decision_json FROM analysis_cycles WHERE status='COMPLETED' "
            "ORDER BY id DESC LIMIT 1"
        ).fetchone()

        decision_data = {}
        if row and row["decision_json"]:
            try:
                decision_data = json.loads(row["decision_json"])
            except Exception:
                pass

        pnl = evt.pnl_usd or 0.0
        outcome = "win" if pnl >= 0 else "loss"
        hold_mins = evt.hold_seconds / 60.0

        # Build reflection prompt
        messages = [
            ChatMessage(
                role="system",
                content=_REFLECTION_SYSTEM.format(max_chars=self._max_chars),
            ),
            ChatMessage(
                role="user",
                content=_REFLECTION_USER.format(
                    reasoning=decision_data.get("reasoning", "N/A"),
                    symbol=evt.symbol,
                    action=decision_data.get("action", "N/A"),
                    confidence=decision_data.get("confidence", 0),
                    leverage=decision_data.get("leverage", 1),
                    sl_pct=decision_data.get("sl_pct", 0),
                    pnl=f"{pnl:+.2f}",
                    hold_mins=hold_mins,
                    outcome=outcome,
                ),
            ),
        ]

        try:
            raw_lesson = self._llm.client.complete(messages, temperature=0.1, max_tokens=256)
            lesson = raw_lesson.strip()[: self._max_chars]
        except Exception as exc:
            log.error("reflection_llm_error", error=str(exc))
            lesson = f"Trade {outcome}: PnL={pnl:+.2f} USD, hold={hold_mins:.1f}min"

        # Store in ChromaDB
        record = LearningRecord(
            lesson_id=str(uuid.uuid4()),
            text=lesson,
            symbol=evt.symbol,
            tags=[outcome, decision_data.get("action", "").lower()],
            metadata={
                "pnl_usd": str(pnl),
                "hold_mins": str(round(hold_mins, 1)),
                "confidence": str(decision_data.get("confidence", 0)),
            },
            created_at=datetime.now(timezone.utc),
        )
        self._memory.add_learning(record)
        log.info("lesson_stored", symbol=evt.symbol, outcome=outcome, chars=len(lesson))

        # Update risk state
        self._risk_state.record_trade_closed(pnl, self._db)
        self._risk_state.open_positions = max(0, self._risk_state.open_positions - 1)

        # Alert
        if self._alerter:
            await self._alerter.send_trade_close(evt.symbol, pnl, hold_mins, outcome)
