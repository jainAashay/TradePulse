"""Deterministic risk validation — stateless validator over RiskState + TradeDecision."""

from __future__ import annotations

from dataclasses import dataclass

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.config.settings import RiskConfig
from delta_agent.risk.state import RiskState


@dataclass
class RiskVerdict:
    approved: bool
    reason: str


class RiskEngine:
    """
    Stateless hard-rule validator.
    All rules must pass for APPROVED. First failure returns REJECTED with reason.
    """

    def __init__(self, config: RiskConfig) -> None:
        self._cfg = config

    def validate(self, decision: TradeDecision, state: RiskState, trading_enabled: bool) -> RiskVerdict:
        cfg = self._cfg

        if not trading_enabled:
            return RiskVerdict(False, "trading_disabled_via_telegram")

        if state.circuit_breaker_active:
            return RiskVerdict(False, "circuit_breaker_active")

        if decision.action == "HOLD":
            return RiskVerdict(False, "action_is_hold")

        if decision.confidence < cfg.min_confidence:
            return RiskVerdict(
                False,
                f"confidence {decision.confidence:.2f} < min {cfg.min_confidence}",
            )

        if decision.leverage > cfg.max_leverage:
            return RiskVerdict(
                False,
                f"leverage {decision.leverage}x > max {cfg.max_leverage}x",
            )

        if state.open_positions >= cfg.max_positions:
            return RiskVerdict(
                False,
                f"open_positions {state.open_positions} >= max {cfg.max_positions}",
            )

        if state.daily_orders >= cfg.max_orders_per_day:
            return RiskVerdict(
                False,
                f"daily_orders {state.daily_orders} >= max {cfg.max_orders_per_day}",
            )

        if state.daily_loss_usd >= cfg.max_daily_loss_usd:
            return RiskVerdict(
                False,
                f"daily_loss_usd {state.daily_loss_usd:.2f} >= max {cfg.max_daily_loss_usd}",
            )

        if state.consecutive_losses >= cfg.max_consecutive_losses:
            return RiskVerdict(
                False,
                f"consecutive_losses {state.consecutive_losses} >= max {cfg.max_consecutive_losses}",
            )

        return RiskVerdict(True, "all_rules_passed")
