"""TradeDecision: structured LLM output model."""

from __future__ import annotations

from typing import List, Literal

from pydantic import BaseModel, Field, field_validator


class TradeDecision(BaseModel):
    action: Literal["LONG", "SHORT", "HOLD"]
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    leverage: int = Field(ge=1, le=100)
    sl_pct: float = Field(gt=0.0, description="Stop-loss as % of entry price")
    tp_pcts: List[float] = Field(min_length=1, description="Take-profit levels as % of entry price")

    @field_validator("tp_pcts")
    @classmethod
    def tp_must_be_positive(cls, v: List[float]) -> List[float]:
        if any(x <= 0 for x in v):
            raise ValueError("all tp_pcts must be > 0")
        return v
