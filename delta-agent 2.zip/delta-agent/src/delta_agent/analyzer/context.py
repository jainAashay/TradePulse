"""Analyzer: assemble context and invoke LLM for a TradeDecision."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.analyzer.prompts import build_messages
from delta_agent.config.settings import RiskConfig
from delta_agent.llm.protocols import LLMRuntime
from delta_agent.logging_setup import get_logger
from delta_agent.screener.indicators import IndicatorRunner
from delta_agent.screener.trigger import TriggerEvent

log = get_logger(__name__)


class Analyzer:
    """
    Stage 2: assemble prompt context (indicators + news + RAG lessons)
    and return a parsed TradeDecision.

    Raises ValueError with reason on parse/validation failure.
    """

    def __init__(
        self,
        llm_runtime: LLMRuntime,
        indicator_runner: IndicatorRunner,
        risk_config: RiskConfig,
        news_cache=None,  # Optional[NewsCache] — injected in M6
    ) -> None:
        self._llm = llm_runtime
        self._indicators = indicator_runner
        self._risk = risk_config
        self._news_cache = news_cache

    async def analyze(self, event: TriggerEvent) -> TradeDecision:
        symbol = event.symbol
        timeframe = event.timeframe

        # 1. Re-fetch latest computed indicator values
        signals = await self._indicators.compute(symbol, timeframe)
        # Merge with event.signals (event carries the snapshot at trigger time)
        merged_signals = {**event.signals, **signals}

        # 2. News sentiment (non-blocking)
        news_text: Optional[str] = None
        if self._news_cache is not None:
            summary = self._news_cache.get(symbol)
            if summary:
                news_text = (
                    f"Bullish signals: {summary.bullish_count}, "
                    f"Bearish signals: {summary.bearish_count}. "
                    f"Headlines: {'; '.join(summary.top_headlines[:3])}"
                )

        # 3. RAG: query vector memory
        rsi_val = merged_signals.get("rsi_14", float("nan"))
        cross_up = bool(merged_signals.get("ema_fast_cross_up", 0))
        trend = "bullish" if cross_up else "bearish"
        rsi_str = f"{rsi_val:.1f}" if rsi_val == rsi_val else "n/a"
        rag_query = f"{symbol} perpetual {timeframe} RSI={rsi_str} trend={trend}"
        records = self._llm.fetch_learnings(rag_query)
        lessons = self._llm.format_learnings_for_prompt(records)

        # 4. Build prompt and call LLM
        ts = datetime.now(timezone.utc).isoformat()
        messages = build_messages(
            symbol=symbol,
            timeframe=timeframe,
            timestamp=ts,
            indicators=merged_signals,
            lessons=lessons,
            news=news_text,
            max_leverage=self._risk.max_leverage,
            min_confidence=self._risk.min_confidence,
        )

        log.info("analyzer_calling_llm", symbol=symbol, timeframe=timeframe, rag_lessons=len(records))
        raw = self._llm.client.complete_json(messages)

        # 5. Validate
        try:
            decision = TradeDecision.model_validate(raw)
        except Exception as exc:
            raise ValueError(f"LLM output failed validation: {exc}. Raw: {json.dumps(raw)[:200]}")

        log.info(
            "analyzer_decision",
            symbol=symbol,
            action=decision.action,
            confidence=decision.confidence,
            leverage=decision.leverage,
        )
        return decision
