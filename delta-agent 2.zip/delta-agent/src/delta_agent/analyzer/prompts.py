"""Prompt templates for the analyzer."""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

from delta_agent.llm.protocols import ChatMessage


SYSTEM_TEMPLATE = """\
You are a disciplined quantitative trading analyst for Delta Exchange perpetual futures.
Your decisions are directly executed on a live account. Be conservative and precise.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{lessons}

## Current Market State
Symbol: {symbol} | Timeframe: {timeframe} | Timestamp: {timestamp}
Indicators:
{indicators}

## News Sentiment
{news}

## Risk Parameters
Max leverage: {max_leverage}x | Min confidence to trade: {min_confidence}
"""

USER_PROMPT = """\
Analyse the above context and produce a trade decision as a single JSON object only. \
No markdown, no prose outside the JSON.

Schema:
{
  "action": "LONG" | "SHORT" | "HOLD",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<chain-of-thought, 2-3 sentences>",
  "leverage": <int>,
  "sl_pct": <float, stop-loss distance as % of entry price>,
  "tp_pcts": [<float>, ...]
}
"""


def build_messages(
    symbol: str,
    timeframe: str,
    timestamp: str,
    indicators: Dict[str, float],
    lessons: str,
    news: Optional[str],
    max_leverage: int,
    min_confidence: float,
) -> list[ChatMessage]:
    indicator_lines = "\n".join(
        f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}"
        for k, v in sorted(indicators.items())
        if not (isinstance(v, float) and v != v)  # skip NaN
    )
    news_text = news or "Unavailable (poller not yet run or API key missing)"

    system = SYSTEM_TEMPLATE.format(
        lessons=lessons or "No prior lessons yet.",
        symbol=symbol,
        timeframe=timeframe,
        timestamp=timestamp,
        indicators=indicator_lines or "  (no indicators computed yet)",
        news=news_text,
        max_leverage=max_leverage,
        min_confidence=min_confidence,
    )
    return [
        ChatMessage(role="system", content=system),
        ChatMessage(role="user", content=USER_PROMPT),
    ]
