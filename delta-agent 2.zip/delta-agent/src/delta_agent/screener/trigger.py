"""Trigger gate: rule evaluator + latest-wins dedup map + cooldown."""

from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)


@dataclass
class TriggerEvent:
    symbol: str
    timeframe: str
    timestamp: float
    signals: Dict[str, float]
    rule_matched: str


class RuleEvaluator:
    """
    Evaluate a declarative rule string against named indicator values.

    Supported syntax:
      - Comparisons: rsi_14 < 30, ema_9 > ema_21
      - Boolean cross events: ema_fast_cross_up, ema_fast_cross_down
      - Logical: AND, OR, NOT (uppercase)
      - Parentheses for grouping
    """

    _TOKEN = re.compile(
        r"(\bAND\b|\bOR\b|\bNOT\b|[()]|[a-z_][a-z_0-9]*(?:\s*(?:<=|>=|==|<|>)\s*[\d.]+)?)",
        re.IGNORECASE,
    )

    def evaluate(self, rule: str, values: Dict[str, float]) -> bool:
        expr = self._translate(rule, values)
        try:
            return bool(eval(expr))  # noqa: S307 — controlled input, no user data
        except Exception as exc:
            log.warning("rule_eval_error", rule=rule, error=str(exc))
            return False

    def _translate(self, rule: str, values: Dict[str, float]) -> str:
        # Replace boolean event identifiers with their float value truth test
        result = rule
        for key, val in values.items():
            # Replace standalone identifiers (word boundary) used as boolean
            result = re.sub(
                rf"\b{re.escape(key)}\b(?!\s*(?:<=|>=|==|<|>))",
                str(bool(val)),
                result,
            )
        # Replace indicator comparisons: rsi_14 < 30
        def _replace_comparison(m: re.Match) -> str:
            token = m.group(0).strip()
            for key, val in values.items():
                cmp_re = re.compile(
                    rf"^{re.escape(key)}\s*(<=|>=|==|<|>)\s*([\d.]+)$"
                )
                cm = cmp_re.match(token)
                if cm:
                    op, rhs = cm.group(1), cm.group(2)
                    return f"({val} {op} {rhs})"
            return token

        # Run a pass to replace comparisons
        result = re.sub(
            r"[a-z_][a-z_0-9]*\s*(?:<=|>=|==|<|>)\s*[\d.]+",
            _replace_comparison,
            result,
            flags=re.IGNORECASE,
        )
        # Map AND/OR/NOT to Python equivalents
        result = re.sub(r"\bAND\b", "and", result)
        result = re.sub(r"\bOR\b", "or", result)
        result = re.sub(r"\bNOT\b", "not", result)
        return result


class TriggerMap:
    """
    Latest-wins dedup map: at most one pending TriggerEvent per symbol.
    Replacing any existing pending event for the same symbol.
    """

    def __init__(self) -> None:
        self._map: Dict[str, TriggerEvent] = {}
        self._lock = asyncio.Lock()
        self._event = asyncio.Event()

    async def put(self, evt: TriggerEvent) -> None:
        async with self._lock:
            replaced = self._map.get(evt.symbol)
            self._map[evt.symbol] = evt
            if replaced:
                log.debug("trigger_replaced", symbol=evt.symbol, old_rule=replaced.rule_matched)
        self._event.set()

    async def get_next(self) -> TriggerEvent:
        """Block until at least one event is available, then return one."""
        while True:
            await self._event.wait()
            async with self._lock:
                if self._map:
                    symbol = next(iter(self._map))
                    evt = self._map.pop(symbol)
                    if not self._map:
                        self._event.clear()
                    return evt
            self._event.clear()

    async def size(self) -> int:
        async with self._lock:
            return len(self._map)


class TriggerGate:
    """
    Evaluates screener rules per symbol, enforces per-(symbol, timeframe) cooldown,
    and writes TriggerEvents into TriggerMap.
    """

    def __init__(
        self,
        trigger_map: TriggerMap,
        cooldown_minutes: int = 5,
    ) -> None:
        self._map = trigger_map
        self._cooldown_s = cooldown_minutes * 60
        self._evaluator = RuleEvaluator()
        self._last_trigger: Dict[Tuple[str, str], float] = {}

    async def evaluate(
        self,
        symbol: str,
        timeframe: str,
        signals: Dict[str, float],
        rule: str,
    ) -> bool:
        """Return True and enqueue if rule fires and cooldown has elapsed."""
        key = (symbol, timeframe)
        now = time.monotonic()
        last = self._last_trigger.get(key, 0.0)
        if now - last < self._cooldown_s:
            return False

        if not self._evaluator.evaluate(rule, signals):
            return False

        self._last_trigger[key] = now
        evt = TriggerEvent(
            symbol=symbol,
            timeframe=timeframe,
            timestamp=time.time(),
            signals=signals,
            rule_matched=rule,
        )
        await self._map.put(evt)
        log.info("trigger_fired", symbol=symbol, timeframe=timeframe, rule=rule)
        return True
