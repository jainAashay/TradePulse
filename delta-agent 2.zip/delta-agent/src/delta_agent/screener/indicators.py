"""Indicator registry and runner using pandas-ta."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, FrozenSet, List, Optional, Tuple

import pandas as pd

try:
    import pandas_ta as ta  # type: ignore
except ImportError:
    ta = None  # noqa: N816 — optional at import time; fails loudly in compute

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class IndicatorKey:
    name: str
    params: FrozenSet[Tuple[str, Any]]

    @classmethod
    def make(cls, name: str, params: Dict[str, Any]) -> "IndicatorKey":
        return cls(name=name, params=frozenset(params.items()))


# Registry: IndicatorKey -> compute(df) -> float
_REGISTRY: Dict[IndicatorKey, Callable[[pd.DataFrame], float]] = {}


def register_indicator(name: str, params: Dict[str, Any], fn: Callable[[pd.DataFrame], float]) -> None:
    key = IndicatorKey.make(name, params)
    _REGISTRY[key] = fn


def _ema_fn(length: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        if ta is None:
            raise RuntimeError("pandas-ta not installed")
        result = ta.ema(df["close"], length=length)
        return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
    return compute


def _rsi_fn(length: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        if ta is None:
            raise RuntimeError("pandas-ta not installed")
        result = ta.rsi(df["close"], length=length)
        return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
    return compute


def _macd_fn(fast: int, slow: int, signal: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        if ta is None:
            raise RuntimeError("pandas-ta not installed")
        result = ta.macd(df["close"], fast=fast, slow=slow, signal=signal)
        if result is None or result.empty:
            return float("nan")
        col = f"MACD_{fast}_{slow}_{signal}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_upper_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        if ta is None:
            raise RuntimeError("pandas-ta not installed")
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBU_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_lower_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        if ta is None:
            raise RuntimeError("pandas-ta not installed")
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBL_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def register_builtins() -> None:
    """Register the default built-in indicators."""
    for length in [9, 21, 50, 200]:
        register_indicator("ema", {"length": length}, _ema_fn(length))
    for length in [14]:
        register_indicator("rsi", {"length": length}, _rsi_fn(length))
    register_indicator("macd", {"fast": 12, "slow": 26, "signal": 9}, _macd_fn(12, 26, 9))
    register_indicator("bollinger_upper", {"length": 20, "std": 2.0}, _bollinger_upper_fn(20, 2.0))
    register_indicator("bollinger_lower", {"length": 20, "std": 2.0}, _bollinger_lower_fn(20, 2.0))


class IndicatorRunner:
    """
    Compute all registered indicators for a given (symbol, timeframe) bar DataFrame.
    Returns a flat dict of named scalar values plus cross event booleans.
    """

    def __init__(self, bar_store) -> None:
        self._bar_store = bar_store

    async def compute(self, symbol: str, timeframe: str) -> Dict[str, float]:
        df = await self._bar_store.get_df(symbol, timeframe)
        if df is None or len(df) < 2:
            return {}

        results: Dict[str, float] = {}
        for key, fn in _REGISTRY.items():
            label = f"{key.name}_{'_'.join(str(v) for _, v in sorted(key.params))}"
            try:
                results[label] = fn(df)
            except Exception as exc:
                log.warning("indicator_compute_error", indicator=label, error=str(exc))
                results[label] = float("nan")

        # Cross events: ema_9 crosses ema_21
        _add_cross_events(results, df)
        return results


def _add_cross_events(results: Dict[str, float], df: pd.DataFrame) -> None:
    """Compute EMA cross events from the last two closes."""
    if len(df) < 2:
        return

    ema9_key = "ema_9"
    ema21_key = "ema_21"
    if ema9_key not in results or ema21_key not in results:
        return

    # Recompute penultimate values to check for crossover
    try:
        ema9_prev = float(ta.ema(df["close"].iloc[:-1], length=9).iloc[-1])
        ema21_prev = float(ta.ema(df["close"].iloc[:-1], length=21).iloc[-1])
        ema9_now = results[ema9_key]
        ema21_now = results[ema21_key]

        results["ema_fast_cross_up"] = float(ema9_prev <= ema21_prev and ema9_now > ema21_now)
        results["ema_fast_cross_down"] = float(ema9_prev >= ema21_prev and ema9_now < ema21_now)
    except Exception:
        results["ema_fast_cross_up"] = 0.0
        results["ema_fast_cross_down"] = 0.0
