"""Main agent loop: state machine orchestrator."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from delta_agent.analyzer.context import Analyzer
from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database
from delta_agent.risk.engine import RiskEngine
from delta_agent.risk.state import RiskState
from delta_agent.screener.trigger import TriggerMap

if TYPE_CHECKING:
    from delta_agent.execution.manager import ExecutionManager
    from delta_agent.health.alerter import Alerter

log = get_logger(__name__)


class AgentLoop:
    """
    Async state machine: IDLE → ANALYZING → RISK_CHECK → [EXECUTING | REJECTED] → IDLE.

    On startup, crashes any IN_FLIGHT analysis cycles to prevent double-entry.
    Never exits on error — catches all exceptions and resets to IDLE.
    """

    def __init__(
        self,
        trigger_map: TriggerMap,
        analyzer: Analyzer,
        risk_engine: RiskEngine,
        risk_state: RiskState,
        db: Database,
        execution_manager: Optional["ExecutionManager"] = None,
        alerter: Optional["Alerter"] = None,
    ) -> None:
        self._triggers = trigger_map
        self._analyzer = analyzer
        self._risk_engine = risk_engine
        self._risk_state = risk_state
        self._db = db
        self._execution = execution_manager
        self._alerter = alerter
        self._running = False

    def startup(self) -> None:
        """Call once before run(). Crashes stale IN_FLIGHT cycles."""
        crashed = self._db.crash_inflight_cycles()
        if crashed:
            log.warning("startup_crashed_inflight_cycles", count=crashed)

    async def run(self) -> None:
        self._running = True
        log.info("agent_loop_started")
        while self._running:
            try:
                await self._process_next()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.error("agent_loop_unhandled_error", error=str(exc), exc_info=True)
                await asyncio.sleep(1)  # brief pause before retrying

    async def stop(self) -> None:
        self._running = False

    async def _process_next(self) -> None:
        # Daily reset check
        self._risk_state.maybe_reset_for_new_day(self._db)

        # Drain next trigger (blocks until available)
        event = await self._triggers.get_next()
        log.info("trigger_received", symbol=event.symbol, timeframe=event.timeframe, rule=event.rule_matched)

        # Check kill switch before doing any work
        if not self._db.is_trading_enabled():
            log.info("trading_disabled_skipping_trigger", symbol=event.symbol)
            return

        # Check circuit breaker
        if self._risk_state.circuit_breaker_active:
            log.info("circuit_breaker_active_skipping", symbol=event.symbol)
            return

        # Persist cycle as IN_FLIGHT
        cycle_id = self._db.create_cycle(
            event.symbol, event.timeframe,
            datetime.fromtimestamp(event.timestamp, tz=timezone.utc).isoformat(),
        )

        try:
            # ANALYZING
            decision = await self._analyzer.analyze(event)

            # RISK_CHECK
            trading_enabled = self._db.is_trading_enabled()
            verdict = self._risk_engine.validate(decision, self._risk_state, trading_enabled)

            if not verdict.approved:
                log.info("risk_rejected", symbol=event.symbol, reason=verdict.reason)
                self._db.update_cycle(cycle_id, "REJECTED", rejection_reason=verdict.reason)
                if self._alerter:
                    await self._alerter.send_rejection(event.symbol, verdict.reason)

                # Trip circuit breaker if consecutive loss limit hit
                if "consecutive_losses" in verdict.reason:
                    self._risk_state.trip_circuit_breaker(self._db)
                    log.warning("circuit_breaker_tripped", symbol=event.symbol)
                    if self._alerter:
                        await self._alerter.send_circuit_breaker_tripped()
                return

            # EXECUTING
            self._db.update_cycle(cycle_id, "IN_FLIGHT", decision_json=json.dumps(decision.model_dump()))

            if self._execution:
                order_id = await self._execution.enter(event.symbol, decision)
                self._risk_state.record_order_placed(self._db)
                self._risk_state.open_positions += 1
                log.info("order_placed", symbol=event.symbol, order_id=order_id, action=decision.action)
                if self._alerter:
                    await self._alerter.send_trade_entry(event.symbol, decision, order_id)
            else:
                log.info("execution_dry_run", symbol=event.symbol, action=decision.action,
                         confidence=decision.confidence, leverage=decision.leverage)

            self._db.update_cycle(cycle_id, "COMPLETED", decision_json=json.dumps(decision.model_dump()))

        except Exception as exc:
            log.error("cycle_error", cycle_id=cycle_id, symbol=event.symbol, error=str(exc), exc_info=True)
            self._db.update_cycle(cycle_id, "CRASHED", rejection_reason=str(exc))
