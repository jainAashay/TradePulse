"""Typed configuration loaded from YAML + environment."""

from __future__ import annotations

import os
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _expand_env(value: Any) -> Any:
    if isinstance(value, str):
        def repl(match: re.Match[str]) -> str:
            key = match.group(1)
            return os.environ.get(key, "")

        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    return value


def _read_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    return _expand_env(raw)


class DeltaProfileConfig(BaseModel):
    rest_url: str
    ws_url: str
    ccxt_id: str = "delta"
    ccxt_options: Dict[str, Any] = Field(default_factory=dict)


class TradingProfileConfig(BaseModel):
    real_orders: bool = True


class ProfileBundle(BaseModel):
    delta: DeltaProfileConfig
    trading: TradingProfileConfig = Field(default_factory=TradingProfileConfig)


class LLMConfig(BaseModel):
    provider: str = "litellm"
    model: str = "gemini/gemini-2.0-flash"
    api_key_env: str = "GEMINI_API_KEY"
    temperature: float = 0.2
    max_output_tokens: int = 2048

    def resolve_api_key(self) -> str:
        key = os.environ.get(self.api_key_env, "").strip()
        if not key:
            raise ValueError(f"LLM API key missing: set {self.api_key_env}")
        return key


class MemoryConfig(BaseModel):
    chroma_persist_dir: str = "data/chroma"
    collection_name: str = "trade_learnings"
    rag_top_k: int = 5
    max_lesson_chars: int = 400


class RiskConfig(BaseModel):
    max_daily_loss_usd: float = Field(gt=0)
    max_orders_per_day: int = Field(gt=0)
    min_confidence: float = 0.65
    max_leverage: int = 20
    max_positions: int = 3
    max_consecutive_losses: int = 3


class ScreenerDefaults(BaseModel):
    rsi_oversold: float = 30
    rsi_overbought: float = 70
    require_ema_cross: bool = True
    ema_fast: int = 9
    ema_slow: int = 21


class ScreenerConfig(BaseModel):
    timeframes: List[str] = Field(default_factory=lambda: ["1m", "5m"])
    bar_history_size: int = 200
    trigger_cooldown_minutes: int = 5
    default_rules: ScreenerDefaults = Field(default_factory=ScreenerDefaults)


class NewsConfig(BaseModel):
    provider: str = "cryptopanic"
    api_key_env: str = "CRYPTOPANIC_API_KEY"
    filter: str = "rising"
    currencies: List[str] = Field(default_factory=list)

    def resolve_api_key(self) -> Optional[str]:
        key = os.environ.get(self.api_key_env, "").strip()
        return key or None


class PersistenceConfig(BaseModel):
    sqlite_path: str = "data/agent_state.db"


class ExecutionConfig(BaseModel):
    entry_order_type: str = "post_only_limit"
    unfilled_limit_timeout_seconds: int = 120


class WatchlistInstrument(BaseModel):
    symbol: str
    quantity: float = 1
    leverage: int = 10
    indicators: List[Dict[str, Any]] = Field(default_factory=list)
    screener: Dict[str, Any] = Field(default_factory=dict)


class WatchlistConfig(BaseModel):
    watchlist: List[WatchlistInstrument] = Field(default_factory=list)

    @field_validator("watchlist")
    @classmethod
    def non_empty(cls, v: List[WatchlistInstrument]) -> List[WatchlistInstrument]:
        if not v:
            raise ValueError("watchlist must contain at least one symbol")
        return v


class AppSettings(BaseSettings):
    """Runtime settings after merging YAML profile + env overrides."""

    model_config = SettingsConfigDict(env_prefix="DELTA_AGENT_", extra="ignore")

    app_name: str = "delta-agent"
    log_level: str = "INFO"
    active_profile: str = "india_testnet"
    profile: ProfileBundle
    llm: LLMConfig
    memory: MemoryConfig
    risk: RiskConfig
    screener: ScreenerConfig
    news: NewsConfig
    persistence: PersistenceConfig
    execution: ExecutionConfig
    watchlist: WatchlistConfig

    config_path: Path
    watchlist_path: Path


def _default_config_path() -> Path:
    env = os.environ.get("DELTA_AGENT_CONFIG")
    if env:
        return Path(env)
    return Path(__file__).resolve().parents[3] / "config" / "settings.yaml"


def _default_watchlist_path() -> Path:
    env = os.environ.get("DELTA_AGENT_WATCHLIST")
    if env:
        return Path(env)
    return Path(__file__).resolve().parents[3] / "config" / "watchlist.yaml"


def load_settings(
    config_path: Optional[Path] = None,
    watchlist_path: Optional[Path] = None,
) -> AppSettings:
    cfg_path = config_path or _default_config_path()
    wl_path = watchlist_path or _default_watchlist_path()

    if not cfg_path.is_file():
        raise FileNotFoundError(f"Settings file not found: {cfg_path}")
    if not wl_path.is_file():
        raise FileNotFoundError(f"Watchlist file not found: {wl_path}")

    doc = _read_yaml(cfg_path)
    active = os.environ.get("DELTA_AGENT_ENV", doc.get("active_profile", "india_testnet"))
    profiles_raw = doc.get("profiles") or {}
    if active not in profiles_raw:
        raise ValueError(f"Unknown profile {active!r}; available: {list(profiles_raw)}")

    profile = ProfileBundle.model_validate(profiles_raw[active])
    watchlist = WatchlistConfig.model_validate(_read_yaml(wl_path))

    app_block = doc.get("app") or {}
    return AppSettings(
        app_name=app_block.get("name", "delta-agent"),
        log_level=app_block.get("log_level", "INFO"),
        active_profile=active,
        profile=profile,
        llm=LLMConfig.model_validate(doc.get("llm") or {}),
        memory=MemoryConfig.model_validate(doc.get("memory") or {}),
        risk=RiskConfig.model_validate(doc.get("risk") or {}),
        screener=ScreenerConfig.model_validate(doc.get("screener") or {}),
        news=NewsConfig.model_validate(doc.get("news") or {}),
        persistence=PersistenceConfig.model_validate(doc.get("persistence") or {}),
        execution=ExecutionConfig.model_validate(doc.get("execution") or {}),
        watchlist=watchlist,
        config_path=cfg_path,
        watchlist_path=wl_path,
    )


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    return load_settings()
