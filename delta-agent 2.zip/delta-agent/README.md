# delta-agent — Agentic Trading Bot for Delta Exchange

A 24/7 autonomous trading agent for Delta Exchange perpetual futures. Uses local technical analysis to filter signals, invokes an LLM (Gemini via LiteLLM) for CoT-based decisions, enforces hard risk rules, executes bracket orders, and continuously learns from closed trades via ChromaDB vector memory.

---

## Architecture (6 milestones, all complete)

```
WebSocket Feed (1m/5m bars)
  → BarStore (rolling OHLCV deque)
  → IndicatorRunner (EMA, RSI, MACD, Bollinger via pandas-ta)
  → TriggerGate (rule eval + latest-wins dedup + 5-min cooldown)
  → AgentLoop (state machine: IDLE → ANALYZING → RISK_CHECK → EXECUTING)
      ├── Analyzer: pulls indicators + news (CryptoPanic) + RAG lessons from ChromaDB
      │             builds prompt (lessons at top, before market state)
      │             → LLM (Gemini) → TradeDecision (action/confidence/leverage/SL/TP)
      ├── RiskEngine: hard-rule validator (confidence, leverage, positions, daily limits, circuit breaker)
      └── ExecutionManager: CCXT for standard ops + Delta REST for bracket orders
                            timeout watcher per order, startup reconciliation
  → ReflectionPipeline: closed trade → LLM post-mortem → compact lesson → ChromaDB
  → Health: FastAPI /health on :8080 + Telegram alerts + /pause /resume /status /reset
```

---

## Key Design Decisions

| Topic | Decision |
|---|---|
| Exchange API | CCXT async for balance/positions/orders/cancel; Delta REST (`/v2/orders`) for bracket orders (SL+TP) — CCXT doesn't expose bracket params |
| WebSocket | Native `websockets` lib (not CCXT streaming); auto-reconnect with exponential backoff (1s→60s cap) |
| Trigger dedup | Latest-wins map per symbol — replaces stale pending triggers, no queue backlog |
| LLM provider | Gemini via LiteLLM; swap model/provider in `settings.yaml` with no code changes |
| Vector memory | ChromaDB + `all-MiniLM-L6-v2` local embeddings (no API cost); lessons pre-compressed to ≤400 chars by LLM before storage; injected at top of system prompt before market state on every analysis cycle |
| Position sizing | Fixed `quantity` + `leverage` from `watchlist.yaml`; LLM leverage suggestion validated against `max_leverage` cap only |
| Risk engine | Stateless validator; daily counters recomputed from SQLite on startup (not in-memory) |
| Restart resilience | `IN_FLIGHT` cycles marked `CRASHED` on boot; order reconciliation diffs exchange vs SQLite; timeout watchers re-attached; trading_enabled flag persisted in SQLite |
| Kill switch | Telegram `/pause` `/resume` `/status` `/reset` — no redeploy needed |
| News | CryptoPanic polled every 5 min, cached 15 min; never blocks analysis if unavailable |
| Cloud | Docker + supervisord; `data/` volume for SQLite + ChromaDB persistence |

---

## Package Structure

```
src/delta_agent/
  config/           YAML + env config, watchlist, RiskConfig, ScreenerConfig
  screener/         bar_store.py, feed.py, indicators.py, trigger.py
  analyzer/         context.py (prompt assembly), prompts.py, decision.py (TradeDecision)
  risk/             engine.py (stateless validator), state.py (SQLite-persisted counters)
  agent/            loop.py (state machine orchestrator)
  execution/        client.py (CCXT + Delta REST), orders.py, manager.py
  reflection/       detector.py (poll closed trades), pipeline.py (post-mortem → ChromaDB)
  memory/           protocols.py, chroma_store.py (ChromaDB), stub.py
  llm/              protocols.py, litellm_client.py, factory.py, langchain_bridge.py
  news/             poller.py (CryptoPanic + NewsCache)
  health/           server.py (FastAPI /health), alerter.py (Telegram), telegram_bot.py
  persistence/      db.py (SQLite: analysis_cycles, orders, risk_state, agent_config)
  logging_setup.py  structlog JSON logs
  __main__.py       boots all subsystems, runs asyncio.gather
```

---

## SQLite Tables

| Table | Purpose |
|---|---|
| `analysis_cycles` | Per-trigger cycle state (`IN_FLIGHT`→`COMPLETED`/`REJECTED`/`CRASHED`) for crash recovery |
| `orders` | Full order lifecycle (PENDING→OPEN→CLOSED), PnL, timestamps |
| `risk_state` | Daily counters: orders placed, loss USD, consecutive losses, circuit breaker flag |
| `agent_config` | Runtime flags: `trading_enabled` (toggled via Telegram) |

---

## Risk Rules (all must pass)

| Rule | Config key | Default |
|---|---|---|
| Confidence ≥ threshold | `risk.min_confidence` | 0.65 |
| Leverage ≤ cap | `risk.max_leverage` | 20x |
| Open positions < max | `risk.max_positions` | 3 |
| Daily orders < max | `risk.max_orders_per_day` | 20 |
| Daily loss < max | `risk.max_daily_loss_usd` | $100 |
| Consecutive losses < max | `risk.max_consecutive_losses` | 3 |
| Circuit breaker OFF | auto-trips on consecutive loss limit | resets at UTC midnight |
| `trading_enabled` | Telegram `/pause` | true |

---

## Setup

### Requirements
- Python 3.11+
- Delta Exchange API key + secret (testnet or mainnet)
- Gemini API key (or any LiteLLM-supported model — change `llm.model` in `settings.yaml`)
- Telegram bot token + chat ID (optional — for alerts and kill switch)
- CryptoPanic API key (optional — news disabled silently if missing)

### Local run

```bash
cd delta-agent
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -e .

cp .env.example .env
# Fill in: DELTA_API_KEY, DELTA_API_SECRET, GEMINI_API_KEY
# Optional: TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, CRYPTOPANIC_API_KEY

python -m delta_agent
```

### Docker

```bash
cp .env.example .env  # fill in secrets
docker-compose up --build
```

Data persists in `./data/` (SQLite + ChromaDB). Health endpoint: `http://localhost:8080/health`.

---

## Configuration

**`config/settings.yaml`** — all tunable parameters:
- `active_profile` — switch between `india_testnet` and `india_mainnet`
- `screener.bar_history_size` — rolling OHLCV window (default 200)
- `screener.trigger_cooldown_minutes` — min gap between triggers per symbol (default 5)
- `screener.default_rules` — RSI thresholds, EMA cross requirement
- `risk.*` — all risk limits
- `llm.model` — change LLM without touching code (e.g. `openai/gpt-4o`, `anthropic/claude-3-5-sonnet`)
- `memory.rag_top_k` — lessons injected per analysis cycle
- `execution.unfilled_limit_timeout_seconds` — auto-cancel timeout

**`config/watchlist.yaml`** — per-symbol `quantity`, `leverage`, indicator config.

---

## Telegram Commands

Once `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` are set:

| Command | Effect |
|---|---|
| `/pause` | Stops new trades (triggers drained but not processed) |
| `/resume` | Re-enables trading |
| `/status` | Shows enabled flag, open positions, daily PnL, circuit breaker |
| `/reset` | Manually resets circuit breaker |

---

## Milestone Status

| Milestone | What | Status |
|---|---|---|
| M1 | Config, logging, LLM factory, memory interfaces | ✅ Done |
| M2 | WebSocket feed, BarStore, indicators, trigger gate | ✅ Done |
| M3 | Agent loop, analyzer, risk engine, SQLite persistence | ✅ Done |
| M4 | Exchange client (CCXT + Delta REST bracket orders), order lifecycle, startup reconciliation | ✅ Done |
| M5 | ChromaDB vector store, reflection pipeline, RAG injection | ✅ Done |
| M6 | News poller, Telegram alerts + bot, health endpoint, Docker + supervisord | ✅ Done |

---

## Environment Variables

```
DELTA_AGENT_ENV=india_testnet      # or india_mainnet
DELTA_API_KEY=
DELTA_API_SECRET=
GEMINI_API_KEY=
TELEGRAM_BOT_TOKEN=               # optional
TELEGRAM_CHAT_ID=                 # optional
CRYPTOPANIC_API_KEY=              # optional
```
