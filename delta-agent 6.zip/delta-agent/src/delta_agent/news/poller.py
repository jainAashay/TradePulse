"""cryptocurrency.cv news poller — free, no API key required."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple  # Dict kept for NewsCache._cache

import httpx

from delta_agent.config.settings import NewsConfig
from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

_BASE_URL = "https://cryptocurrency.cv/api"
_ITEMS_PER_REQUEST = 15  # last 2h only — low volume, fetch more


@dataclass
class SentimentSummary:
    bullish_count: int
    bearish_count: int
    neutral_count: int
    # (title, timeAgo) per article
    top_headlines: List[Tuple[str, str]]
    fetched_at: float = field(default_factory=time.time)

    def is_stale(self, ttl_seconds: int) -> bool:
        return (time.time() - self.fetched_at) > ttl_seconds

    def as_text(self, max_chars: int = 1000) -> str:
        """Render headlines as plain text for LLM prompt injection."""
        lines = ["Headlines (LLM judges sentiment):"]
        budget = max_chars - len(lines[0]) - 1
        for title, time_ago in self.top_headlines:
            entry = f"  [{time_ago}] {title[:150]}"
            if budget - len(entry) - 1 < 0:
                break
            lines.append(entry)
            budget -= len(entry) + 1
        return "\n".join(lines)[:max_chars]


class NewsCache:
    """In-memory cache of SentimentSummary keyed by symbol."""

    def __init__(self, ttl_seconds: int = 120) -> None:
        self._cache: Dict[str, SentimentSummary] = {}
        self._ttl = ttl_seconds

    def put(self, symbol: str, summary: SentimentSummary) -> None:
        self._cache[symbol] = summary

    def get(self, symbol: str) -> Optional[SentimentSummary]:
        s = self._cache.get(symbol)
        if s and s.is_stale(self._ttl):
            return None
        return s


class NewsPoller:
    """
    Background asyncio task. Polls cryptocurrency.cv/api/breaking every poll_interval_seconds.
    No API key needed — always active. One shared fetch for all symbols (breaking news is global).
    LLM judges relevance and sentiment from the raw headlines.
    """

    def __init__(self, config: NewsConfig, symbols: List[str], cache: NewsCache) -> None:
        self._config = config
        self._symbols = symbols
        self._cache = cache
        self._poll_interval = config.poll_interval_seconds
        self._running = False

    async def run(self) -> None:
        self._running = True
        await self._poll()
        while self._running:
            await asyncio.sleep(self._poll_interval)
            await self._poll()

    async def stop(self) -> None:
        self._running = False

    async def _poll(self) -> None:
        try:
            headlines = await self._fetch_breaking()
        except Exception as exc:
            log.warning("news_fetch_error", error=str(exc))
            return

        # Same breaking feed shared across all symbols — LLM filters by relevance
        summary = SentimentSummary(
            bullish_count=0,
            bearish_count=0,
            neutral_count=0,
            top_headlines=headlines,
        )
        for symbol in self._symbols:
            self._cache.put(symbol, summary)
        log.debug("news_fetched", articles=len(headlines))

    async def _fetch_breaking(self) -> List[Tuple[str, str]]:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{_BASE_URL}/breaking",
                params={"limit": _ITEMS_PER_REQUEST},
            )
            resp.raise_for_status()
            data = resp.json()

        articles = data.get("articles", [])
        return [
            (a["title"], a.get("timeAgo") or a.get("pubDate", "")[:16])
            for a in articles
            if a.get("title")
        ]
