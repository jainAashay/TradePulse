"""Optional LangChain adapter — keeps workflow on LLMRuntime while allowing LC tools later."""

from __future__ import annotations

from typing import Any, List

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage

from delta_agent.llm.protocols import ChatMessage, LLMClient


class LangChainChatModelAdapter(BaseChatModel):
    """Wrap our LLMClient as a LangChain chat model for future tool agents."""

    client: LLMClient

    @property
    def _llm_type(self) -> str:
        return "delta_agent_litellm"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: List[str] | None = None,
        run_manager: Any = None,
        **kwargs: Any,
    ) -> Any:
        from langchain_core.outputs import ChatGeneration, ChatResult

        _ = stop, run_manager, kwargs
        converted: list[ChatMessage] = []
        for msg in messages:
            if isinstance(msg, SystemMessage):
                converted.append(ChatMessage(role="system", content=str(msg.content)))
            elif isinstance(msg, HumanMessage):
                converted.append(ChatMessage(role="user", content=str(msg.content)))
            elif isinstance(msg, AIMessage):
                converted.append(ChatMessage(role="assistant", content=str(msg.content)))
            else:
                converted.append(ChatMessage(role="user", content=str(msg.content)))
        text = self.client.complete(converted)
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=text))])
