"""LiteLLM-backed LLM client (default: Gemini)."""

from __future__ import annotations

import json
import re
from typing import Any, List, Optional

import litellm

from delta_agent.config.settings import LLMConfig
from delta_agent.llm.protocols import ChatMessage

_JSON_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


class LiteLLMClient:
    def __init__(self, config: LLMConfig) -> None:
        self._config = config
        self._api_key = config.resolve_api_key()

    def complete(
        self,
        messages: List[ChatMessage],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        payload = [{"role": m.role, "content": m.content} for m in messages]
        response = litellm.completion(
            model=self._config.model,
            messages=payload,
            api_key=self._api_key,
            temperature=temperature if temperature is not None else self._config.temperature,
            max_tokens=max_tokens or self._config.max_output_tokens,
        )
        choice = response.choices[0]
        content = choice.message.content
        if content is None:
            return ""
        return content if isinstance(content, str) else str(content)

    def complete_json(
        self,
        messages: List[ChatMessage],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        system_hint = ChatMessage(
            role="system",
            content="Respond with a single JSON object only. No markdown fences or prose.",
        )
        augmented = [system_hint, *messages]
        raw = self.complete(augmented, temperature=temperature, max_tokens=max_tokens)
        return _parse_json_object(raw)


def _parse_json_object(text: str) -> dict[str, Any]:
    stripped = text.strip()
    fence = _JSON_FENCE.search(stripped)
    if fence:
        stripped = fence.group(1).strip()
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise ValueError(f"LLM did not return valid JSON: {text[:200]}") from exc
    if not isinstance(parsed, dict):
        raise ValueError("LLM JSON root must be an object")
    return parsed
