"""LLM abstractions — swap providers without changing the agent workflow."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional, Protocol, runtime_checkable

from delta_agent.memory.protocols import LearningRecord, VectorMemoryStore


@dataclass(frozen=True)
class ChatMessage:
    role: str
    content: str


@runtime_checkable
class LLMClient(Protocol):
    """Minimal chat completion interface (implemented via LiteLLM)."""

    def complete(
        self,
        messages: List[ChatMessage],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Return assistant text."""

    def complete_json(
        self,
        messages: List[ChatMessage],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        """Return parsed JSON object from the model."""


@dataclass
class LLMRuntime:
    """Bundle passed into the Analyzer (Stage 2): LLM + vector memory for RAG."""

    client: LLMClient
    memory: VectorMemoryStore
    rag_top_k: int = 5
    max_lesson_chars: int = 400

    def fetch_learnings(self, query: str) -> List[LearningRecord]:
        return self.memory.search(query, top_k=self.rag_top_k)

    def format_learnings_for_prompt(self, records: List[LearningRecord]) -> str:
        if not records:
            return "No prior lessons retrieved."
        lines: list[str] = []
        for rec in records:
            text = rec.text.strip()
            if len(text) > self.max_lesson_chars:
                text = text[: self.max_lesson_chars] + "…"
            prefix = f"[{rec.symbol}] " if rec.symbol else ""
            lines.append(f"- {prefix}{text}")
        return "\n".join(lines)
