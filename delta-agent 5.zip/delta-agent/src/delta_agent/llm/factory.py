"""Factory for LLM clients and Analyzer runtime (LLM + vector memory)."""

from __future__ import annotations

from typing import Optional

from delta_agent.config.settings import AppSettings, LLMConfig
from delta_agent.llm.litellm_client import LiteLLMClient
from delta_agent.llm.protocols import LLMClient, LLMRuntime
from delta_agent.memory.protocols import LearningRefiner, VectorMemoryStore
from delta_agent.memory.stub import StubLearningRefiner, StubVectorMemoryStore


class LLMFactory:
    """Create provider-specific clients from configuration."""

    @staticmethod
    def create_client(config: LLMConfig) -> LLMClient:
        provider = (config.provider or "litellm").lower()
        if provider == "litellm":
            return LiteLLMClient(config)
        raise ValueError(f"Unsupported LLM provider: {config.provider}")

    @staticmethod
    def create_memory_store(settings: AppSettings) -> VectorMemoryStore:
        try:
            from delta_agent.memory.chroma_store import ChromaVectorMemoryStore
            return ChromaVectorMemoryStore(
                persist_dir=settings.memory.chroma_persist_dir,
                collection_name=settings.memory.collection_name,
            )
        except ImportError:
            from delta_agent.memory.stub import StubVectorMemoryStore
            return StubVectorMemoryStore()

    @staticmethod
    def create_learning_refiner(client: LLMClient, *, max_chars: int) -> LearningRefiner:
        return LLMBackedLearningRefiner(client, max_chars=max_chars)

    @staticmethod
    def create_runtime(
        settings: AppSettings,
        *,
        memory: Optional[VectorMemoryStore] = None,
    ) -> LLMRuntime:
        client = LLMFactory.create_client(settings.llm)
        store = memory or LLMFactory.create_memory_store(settings)
        return LLMRuntime(
            client=client,
            memory=store,
            rag_top_k=settings.memory.rag_top_k,
            max_lesson_chars=settings.memory.max_lesson_chars,
        )


class LLMBackedLearningRefiner:
    """Compress raw reflection text before vector storage (token-efficient RAG)."""

    _PROMPT = (
        "You compress trading post-mortems into one precise lesson (max {max_chars} chars). "
        "No filler. Focus on what to do differently next time. Output plain text only."
    )

    def __init__(self, client: LLMClient, *, max_chars: int) -> None:
        self._client = client
        self._max_chars = max_chars

    def refine(self, raw_reflection: str, *, context: Optional[dict] = None) -> str:
        from delta_agent.llm.protocols import ChatMessage

        ctx_line = ""
        if context:
            ctx_line = f"\nContext: {context}"
        messages = [
            ChatMessage(
                role="system",
                content=self._PROMPT.format(max_chars=self._max_chars),
            ),
            ChatMessage(
                role="user",
                content=f"Raw reflection:{ctx_line}\n\n{raw_reflection}",
            ),
        ]
        out = self._client.complete(messages, temperature=0.1, max_tokens=256)
        text = out.strip()
        if len(text) > self._max_chars:
            return text[: self._max_chars] + "…"
        return text


def create_llm_runtime(settings: AppSettings) -> LLMRuntime:
    return LLMFactory.create_runtime(settings)
