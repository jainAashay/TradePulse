"""
PriceActionNarrator — deterministic, rule-based narrative computed from a MarketDataStore DataFrame.

Produces a short human-readable paragraph describing price action, momentum,
trend structure, and volatility. This is factual observation, not opinion —
the LLM receives this alongside the raw CSV so it can validate rather than invent.
"""

from __future__ import annotations

import math
from typing import Optional

import pandas as pd


def _nan(v) -> bool:
    try:
        return math.isnan(float(v))
    except (TypeError, ValueError):
        return True


def _pct(a: float, b: float) -> float:
    """Percentage change from b to a."""
    return (a - b) / b * 100 if b != 0 else 0.0


def build_narrative(df: pd.DataFrame, n_candles: int = 15) -> str:
    """
    Return a concise, factual narrative string from the last n_candles rows.
    Each sentence states a measurable observation.
    """
    if df is None or len(df) < 2:
        return "Insufficient data for narrative."

    tail = df.tail(n_candles)
    last = tail.iloc[-1]
    prev = tail.iloc[-2]

    lines: list[str] = []

    # ── Price trend ──────────────────────────────────────────────────────────
    close_first = float(tail["close"].iloc[0])
    close_last  = float(last["close"])
    trend_pct   = _pct(close_last, close_first)
    direction   = "up" if trend_pct > 0 else "down"
    lines.append(
        f"Over the last {len(tail)} candles price moved {direction} "
        f"{abs(trend_pct):.2f}% (from {close_first:.4f} to {close_last:.4f})."
    )

    # ── Last candle body ─────────────────────────────────────────────────────
    o, c = float(last.get("open", close_last)), close_last
    body_pct = _pct(c, o)
    if abs(body_pct) >= 0.1:
        candle_dir = "bullish" if body_pct > 0 else "bearish"
        lines.append(f"Last candle is {candle_dir} ({body_pct:+.2f}% body).")

    # ── EMA stack ────────────────────────────────────────────────────────────
    ema9  = last.get("ema_9")
    ema21 = last.get("ema_21")
    ema50 = last.get("ema_50")
    if not _nan(ema9) and not _nan(ema21):
        stack = "above" if float(ema9) > float(ema21) else "below"
        lines.append(f"EMA9 is {stack} EMA21 — short-term trend is {'bullish' if stack == 'above' else 'bearish'}.")
    if not _nan(ema50) and not _nan(ema9):
        longbias = "above" if float(ema9) > float(ema50) else "below"
        lines.append(f"Price is {longbias} EMA50.")

    # ── EMA cross events ─────────────────────────────────────────────────────
    if float(last.get("ema_cross_up", 0)) == 1.0:
        lines.append("EMA9 just crossed above EMA21 (golden cross on this candle).")
    elif float(last.get("ema_cross_down", 0)) == 1.0:
        lines.append("EMA9 just crossed below EMA21 (death cross on this candle).")

    # ── RSI ──────────────────────────────────────────────────────────────────
    rsi = last.get("rsi_14")
    if not _nan(rsi):
        rsi = float(rsi)
        if rsi >= 70:
            lines.append(f"RSI14 is {rsi:.1f} — overbought territory.")
        elif rsi <= 30:
            lines.append(f"RSI14 is {rsi:.1f} — oversold territory.")
        else:
            lines.append(f"RSI14 is {rsi:.1f} — neutral zone.")

    # RSI direction (rising or falling)
    rsi_prev = prev.get("rsi_14")
    if not _nan(rsi) and not _nan(rsi_prev):
        rsi_delta = float(rsi) - float(rsi_prev)  # type: ignore[arg-type]
        if abs(rsi_delta) >= 1.0:
            rsi_dir = "rising" if rsi_delta > 0 else "falling"
            lines.append(f"RSI is {rsi_dir} ({rsi_delta:+.1f} vs previous candle).")

    # ── MACD ─────────────────────────────────────────────────────────────────
    macd_hist = last.get("macd_hist")
    if not _nan(macd_hist):
        macd_hist = float(macd_hist)
        prev_hist = prev.get("macd_hist")
        if not _nan(prev_hist):
            prev_hist = float(prev_hist)
            if macd_hist > 0 and prev_hist <= 0:
                lines.append("MACD histogram just turned positive — bullish momentum shift.")
            elif macd_hist < 0 and prev_hist >= 0:
                lines.append("MACD histogram just turned negative — bearish momentum shift.")
            elif macd_hist > 0:
                hist_trend = "growing" if macd_hist > prev_hist else "shrinking"
                lines.append(f"MACD histogram is positive and {hist_trend} ({macd_hist:.5f}).")
            else:
                hist_trend = "deepening" if macd_hist < prev_hist else "recovering"
                lines.append(f"MACD histogram is negative and {hist_trend} ({macd_hist:.5f}).")

    if float(last.get("macd_cross_up", 0)) == 1.0:
        lines.append("MACD line just crossed above signal line — bullish crossover.")
    elif float(last.get("macd_cross_down", 0)) == 1.0:
        lines.append("MACD line just crossed below signal line — bearish crossover.")

    # ── Bollinger Bands ──────────────────────────────────────────────────────
    bb_pct_b = last.get("bb_pct_b")
    bb_bw    = last.get("bb_bandwidth")
    if not _nan(bb_pct_b):
        bb_pct_b = float(bb_pct_b)
        if bb_pct_b > 1.0:
            lines.append(f"Price is above the upper Bollinger Band (%B={bb_pct_b:.2f}) — extended move.")
        elif bb_pct_b < 0.0:
            lines.append(f"Price is below the lower Bollinger Band (%B={bb_pct_b:.2f}) — extended sell-off.")
        else:
            lines.append(f"Price is within Bollinger Bands (%B={bb_pct_b:.2f}).")

    if not _nan(bb_bw):
        bb_bw = float(bb_bw)
        # Compare to 20-bar average bandwidth for squeeze detection
        bw_series = tail["bb_bandwidth"].dropna()
        if len(bw_series) >= 5:
            avg_bw = float(bw_series.mean())
            if bb_bw < avg_bw * 0.75:
                lines.append(f"Bollinger bandwidth is contracting ({bb_bw:.2f}% vs avg {avg_bw:.2f}%) — possible squeeze setup.")
            elif bb_bw > avg_bw * 1.25:
                lines.append(f"Bollinger bandwidth is expanding ({bb_bw:.2f}%) — volatility increasing.")

    # ── ATR ──────────────────────────────────────────────────────────────────
    atr = last.get("atr_14")
    if not _nan(atr):
        atr_pct = float(atr) / close_last * 100 if close_last != 0 else 0
        lines.append(f"ATR14 is {float(atr):.4f} ({atr_pct:.2f}% of price).")

    # ── Stochastic ───────────────────────────────────────────────────────────
    stoch_k = last.get("stoch_k")
    stoch_d = last.get("stoch_d")
    if not _nan(stoch_k) and not _nan(stoch_d):
        stoch_k, stoch_d = float(stoch_k), float(stoch_d)
        zone = "overbought (>80)" if stoch_k > 80 else ("oversold (<20)" if stoch_k < 20 else "neutral")
        lines.append(f"Stochastic %K={stoch_k:.1f}, %D={stoch_d:.1f} — {zone}.")
    if float(last.get("stoch_cross_up", 0)) == 1.0:
        lines.append("Stochastic %K just crossed above %D — bullish signal.")
    elif float(last.get("stoch_cross_down", 0)) == 1.0:
        lines.append("Stochastic %K just crossed below %D — bearish signal.")

    # ── Volume ───────────────────────────────────────────────────────────────
    vol_series = tail["volume"].replace(0, float("nan")).dropna()
    if len(vol_series) >= 3:
        avg_vol = float(vol_series.iloc[:-1].mean())
        last_vol = float(vol_series.iloc[-1])
        if avg_vol > 0:
            vol_ratio = last_vol / avg_vol
            if vol_ratio >= 1.5:
                lines.append(f"Last candle volume is {vol_ratio:.1f}x the recent average — above-average participation.")
            elif vol_ratio <= 0.5:
                lines.append(f"Last candle volume is {vol_ratio:.1f}x the recent average — low conviction move.")

    return " ".join(lines)
