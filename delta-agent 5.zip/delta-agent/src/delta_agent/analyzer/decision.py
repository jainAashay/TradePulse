"""TradeDecision: structured LLM output model."""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class TradeDecision(BaseModel):
    action: Literal["LONG", "SHORT", "HOLD", "EXIT"]
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    # Not required for HOLD or EXIT
    leverage: Optional[int] = Field(default=None, ge=1, le=100)
    sl_pct: Optional[float] = Field(default=None, gt=0.0, description="Stop-loss as % of entry price")
    tp_pcts: Optional[List[float]] = Field(default=None, description="Take-profit levels as % of entry price")

    @field_validator("tp_pcts")
    @classmethod
    def tp_must_be_positive(cls, v: Optional[List[float]]) -> Optional[List[float]]:
        if v is not None and any(x <= 0 for x in v):
            raise ValueError("all tp_pcts must be > 0")
        return v

    @model_validator(mode="after")
    def entry_fields_required_for_entry(self) -> "TradeDecision":
        if self.action in ("LONG", "SHORT"):
            if self.leverage is None:
                raise ValueError("leverage required for LONG/SHORT")
            if self.sl_pct is None:
                raise ValueError("sl_pct required for LONG/SHORT")
            if not self.tp_pcts:
                raise ValueError("tp_pcts required for LONG/SHORT")
        return self
