"""Analyzer: assembles context and invokes LLM for a TradeDecision."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import pandas as pd

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.analyzer.narrator import build_narrative
from delta_agent.analyzer.prompts import build_scan_messages, build_watch_messages
from delta_agent.config.settings import RiskConfig
from delta_agent.llm.protocols import LLMRuntime
from delta_agent.logging_setup import get_logger
from delta_agent.screener.trigger import TriggerEvent

log = get_logger(__name__)


@dataclass
class OpenPosition:
    """Snapshot of an active order passed to watch-mode analysis."""
    order_id: int
    symbol: str
    side: str           # "buy" | "sell"
    entry_price: float
    sl_price: float
    tp_price: float     # first TP level
    created_at: str     # ISO timestamp


class Analyzer:
    """
    Dual-mode analyzer:
      - Scan mode  (open_position=None): trigger-gated entry analysis
      - Watch mode (open_position set):  per-candle monitoring of active position

    Receives the enriched DataFrame from MarketDataStore so it can build
    the CSV table and narrative directly from historical indicator data.
    """

    def __init__(
        self,
        llm_runtime: LLMRuntime,
        market_data_store,           # MarketDataStore — avoids circular import
        risk_config: RiskConfig,
        news_cache=None,
        max_news_chars: int = 1000,
        price_action_candles: int = 15,
    ) -> None:
        self._llm = llm_runtime
        self._mds = market_data_store
        self._risk = risk_config
        self._news_cache = news_cache
        self._max_news_chars = max_news_chars
        self._n_candles = price_action_candles

    async def analyze(
        self,
        event: TriggerEvent,
        open_position: Optional[OpenPosition] = None,
    ) -> TradeDecision:
        """
        Scan mode:  open_position=None  → LONG / SHORT / HOLD decision
        Watch mode: open_position set   → HOLD / EXIT decision
        """
        symbol    = event.symbol
        timeframe = event.timeframe

        df: Optional[pd.DataFrame] = await self._mds.get_df(symbol, timeframe)
        df_len = len(df) if df is not None else 0
        log.debug("analyzer_df_loaded", symbol=symbol, timeframe=timeframe, rows=df_len)

        narrative = build_narrative(df, n_candles=self._n_candles) if df is not None else ""
        log.debug("analyzer_narrative_built", symbol=symbol, chars=len(narrative))

        news_text = self._get_news_text(symbol)
        log.debug("analyzer_news", symbol=symbol, has_news=news_text is not None,
                  chars=len(news_text) if news_text else 0)

        records   = self._fetch_rag(symbol, timeframe, event.signals, df)
        lessons   = self._llm.format_learnings_for_prompt(records)
        log.debug("analyzer_rag", symbol=symbol, lessons_retrieved=len(records))

        ts = datetime.now(timezone.utc).isoformat()

        if open_position is not None:
            messages = self._build_watch_messages(
                open_position, event, df, narrative, lessons, news_text, ts
            )
            mode = "watch"
        else:
            messages = build_scan_messages(
                symbol=symbol,
                timeframe=timeframe,
                timestamp=ts,
                df=df,
                narrative=narrative,
                lessons=lessons,
                news=news_text,
                max_leverage=self._risk.max_leverage,
                min_confidence=self._risk.min_confidence,
                n_candles=self._n_candles,
            )
            mode = "scan"

        log.info("analyzer_calling_llm", symbol=symbol, timeframe=timeframe,
                 mode=mode, rag_lessons=len(records), df_rows=df_len)
        raw = self._llm.client.complete_json(messages)
        log.debug("analyzer_llm_raw_response", symbol=symbol, raw=str(raw)[:200])

        try:
            decision = TradeDecision.model_validate(raw)
        except Exception as exc:
            raise ValueError(f"LLM output failed validation: {exc}. Raw: {json.dumps(raw)[:200]}")

        log.info("analyzer_decision", symbol=symbol, action=decision.action,
                 confidence=decision.confidence, mode=mode,
                 reasoning=decision.reasoning[:100])
        return decision

    # ── helpers ──────────────────────────────────────────────────────────────

    def _get_news_text(self, symbol: str) -> Optional[str]:
        if self._news_cache is None:
            return None
        summary = self._news_cache.get(symbol)
        return summary.as_text(max_chars=self._max_news_chars) if summary else None

    def _fetch_rag(
        self,
        symbol: str,
        timeframe: str,
        signals: Dict[str, Any],
        df: Optional[pd.DataFrame],
    ):
        rsi_val  = signals.get("rsi_14", float("nan"))
        cross_up = bool(signals.get("ema_fast_cross_up", 0) or signals.get("ema_cross_up", 0))
        trend    = "bullish" if cross_up else "bearish"
        rsi_str  = f"{rsi_val:.1f}" if rsi_val == rsi_val else "n/a"
        query    = f"{symbol} perpetual {timeframe} RSI={rsi_str} trend={trend}"
        return self._llm.fetch_learnings(query)

    def _build_watch_messages(
        self,
        pos: OpenPosition,
        event: TriggerEvent,
        df: Optional[pd.DataFrame],
        narrative: str,
        lessons: str,
        news_text: Optional[str],
        ts: str,
    ):
        try:
            created_dt  = datetime.fromisoformat(pos.created_at)
            hold_minutes = int((datetime.now(timezone.utc) - created_dt).total_seconds() / 60)
        except Exception:
            hold_minutes = 0

        # Current price from latest DataFrame row or fall back to event signals
        current_price = pos.entry_price
        if df is not None and not df.empty:
            current_price = float(df.iloc[-1].get("close", pos.entry_price))
        elif event.signals:
            current_price = float(event.signals.get("close", pos.entry_price))

        return build_watch_messages(
            symbol=pos.symbol,
            side=pos.side,
            timeframe=event.timeframe,
            timestamp=ts,
            entry_price=pos.entry_price,
            current_price=current_price,
            sl_price=pos.sl_price,
            tp_price=pos.tp_price,
            hold_minutes=hold_minutes,
            df=df,
            narrative=narrative,
            lessons=lessons,
            news=news_text,
            n_candles=self._n_candles,
        )
