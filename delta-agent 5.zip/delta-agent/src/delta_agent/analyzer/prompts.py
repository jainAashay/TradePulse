"""Prompt templates for scan mode (entry) and watch mode (position monitoring)."""

from __future__ import annotations

import io
from typing import Any, Dict, List, Optional

import pandas as pd

from delta_agent.llm.protocols import ChatMessage
from delta_agent.screener.market_data_store import STRUCTURE_COLUMNS, TABLE_COLUMNS


# ── Scan mode ────────────────────────────────────────────────────────────────

SCAN_SYSTEM_TEMPLATE = """\
You are a disciplined quantitative trading analyst for Delta Exchange perpetual futures.
Your decisions are directly executed on a live account. Be conservative and precise.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{lessons}

## Current Market State
Symbol: {symbol} | Timeframe: {timeframe} | Timestamp: {timestamp}

## Market Narrative
{narrative}

## Supporting Data (CSV — source of truth)
The CSV below is computed directly from market data. If the narrative above conflicts
with what you observe in the data, trust the CSV data, not the narrative.
{csv_table}

## Current Market Structure
{structure_block}

## Recent News Headlines
{news}

## Risk Parameters
Max leverage: {max_leverage}x | Min confidence to trade: {min_confidence}
"""

SCAN_USER_PROMPT = """\
Analyse the above context and produce a trade decision as a single JSON object only. \
No markdown, no prose outside the JSON.

Schema:
{
  "action": "LONG" | "SHORT" | "HOLD",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<chain-of-thought, 2-3 sentences referencing specific indicator values>",
  "leverage": <int>,
  "sl_pct": <float, stop-loss distance as % of entry price>,
  "tp_pcts": [<float>, ...]
}

For HOLD: leverage, sl_pct, tp_pcts may be omitted or set to null.
"""


# ── Watch mode ───────────────────────────────────────────────────────────────

WATCH_SYSTEM_TEMPLATE = """\
You are a disciplined quantitative trading analyst monitoring an active position on Delta Exchange.
Your job is to decide whether to hold or exit early. Be objective — do not let loss aversion or \
greed override the technicals.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{lessons}

## Active Position
Symbol: {symbol} | Side: {side} | Timeframe: {timeframe}
Entry price:    {entry_price}
Current price:  {current_price}
Unrealised PnL: {unrealised_pnl_pct:.2f}%
Time held:      {hold_minutes} minutes
Stop-loss at:   {sl_price}
Take-profit at: {tp_price}

## Market Narrative
{narrative}

## Supporting Data (CSV — source of truth)
The CSV below is computed directly from market data. If the narrative above conflicts
with what you observe in the data, trust the CSV data, not the narrative.
{csv_table}

## Current Market Structure
{structure_block}

## Recent News Headlines
Timestamp: {timestamp}
{news}
"""

WATCH_USER_PROMPT = """\
Based on the active position and current market context, decide whether to HOLD or EXIT early. \
Produce a single JSON object only. No markdown, no prose outside the JSON.

Schema:
{
  "action": "HOLD" | "EXIT",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<chain-of-thought, 2-3 sentences referencing specific data values>"
}

EXIT means: cancel the bracket order and flatten the position immediately at market.
Only EXIT if you see clear evidence the trade thesis has broken down.
"""


# ── Public builders ───────────────────────────────────────────────────────────

def build_scan_messages(
    symbol: str,
    timeframe: str,
    timestamp: str,
    df: Optional[pd.DataFrame],
    narrative: str,
    lessons: str,
    news: Optional[str],
    max_leverage: int,
    min_confidence: float,
    n_candles: int = 15,
) -> List[ChatMessage]:
    csv_table = format_candles_csv(df, n_candles) if df is not None else "(no data)"
    structure = format_structure_block(df) if df is not None else "(no data)"
    news_text = news or "No recent headlines available."
    system = SCAN_SYSTEM_TEMPLATE.format(
        lessons=lessons or "No prior lessons yet.",
        symbol=symbol,
        timeframe=timeframe,
        timestamp=timestamp,
        narrative=narrative or "Insufficient data for narrative.",
        csv_table=csv_table,
        structure_block=structure,
        news=news_text,
        max_leverage=max_leverage,
        min_confidence=min_confidence,
    )
    return [
        ChatMessage(role="system", content=system),
        ChatMessage(role="user", content=SCAN_USER_PROMPT),
    ]


def build_watch_messages(
    symbol: str,
    side: str,
    timeframe: str,
    timestamp: str,
    entry_price: float,
    current_price: float,
    sl_price: float,
    tp_price: float,
    hold_minutes: int,
    df: Optional[pd.DataFrame],
    narrative: str,
    lessons: str,
    news: Optional[str],
    n_candles: int = 15,
) -> List[ChatMessage]:
    if entry_price > 0:
        pnl_pct = (current_price - entry_price) / entry_price * 100
        if side == "sell":
            pnl_pct = -pnl_pct
    else:
        pnl_pct = 0.0

    csv_table = format_candles_csv(df, n_candles) if df is not None else "(no data)"
    structure = format_structure_block(df) if df is not None else "(no data)"
    news_text = news or "No recent headlines available."

    system = WATCH_SYSTEM_TEMPLATE.format(
        lessons=lessons or "No prior lessons yet.",
        symbol=symbol,
        side=side,
        timeframe=timeframe,
        timestamp=timestamp,
        entry_price=entry_price,
        current_price=current_price,
        unrealised_pnl_pct=pnl_pct,
        hold_minutes=hold_minutes,
        sl_price=sl_price,
        tp_price=tp_price,
        narrative=narrative or "Insufficient data for narrative.",
        csv_table=csv_table,
        structure_block=structure,
        news=news_text,
    )
    return [
        ChatMessage(role="system", content=system),
        ChatMessage(role="user", content=WATCH_USER_PROMPT),
    ]


# kept for backward compat
def build_messages(
    symbol: str,
    timeframe: str,
    timestamp: str,
    indicators: Dict[str, float],
    lessons: str,
    news: Optional[str],
    max_leverage: int,
    min_confidence: float,
) -> List[ChatMessage]:
    return build_scan_messages(
        symbol=symbol,
        timeframe=timeframe,
        timestamp=timestamp,
        df=None,
        narrative=_format_indicators_as_narrative(indicators),
        lessons=lessons,
        news=news,
        max_leverage=max_leverage,
        min_confidence=min_confidence,
    )


# ── Formatting helpers ────────────────────────────────────────────────────────

def format_candles_csv(df: pd.DataFrame, n: int = 15) -> str:
    """Return last n rows of TABLE_COLUMNS as a compact CSV string."""
    if df is None or df.empty:
        return "(no data)"
    cols = [c for c in TABLE_COLUMNS if c in df.columns]
    if not cols:
        return "(indicator columns not yet computed)"
    tail = df.tail(n)[cols].copy()
    buf = io.StringIO()
    tail.to_csv(buf, index=False, float_format="%.5f")
    return buf.getvalue().strip()


def format_structure_block(df: pd.DataFrame) -> str:
    """Return latest values of STRUCTURE_COLUMNS as key=value lines."""
    if df is None or df.empty:
        return "(no data)"
    last = df.iloc[-1]
    lines = []
    for col in STRUCTURE_COLUMNS:
        if col in last.index:
            v = last[col]
            try:
                fv = float(v)
                if fv == fv:  # not NaN
                    lines.append(f"  {col}: {fv:.5f}")
            except (TypeError, ValueError):
                pass
    # Also add cross events
    cross_cols = [
        "ema_cross_up", "ema_cross_down", "ema_trend_bullish", "ema_longterm_bullish",
        "macd_cross_up", "macd_cross_down", "macd_above_zero",
        "stoch_cross_up", "stoch_cross_down",
    ]
    for col in cross_cols:
        if col in last.index:
            v = last[col]
            try:
                fv = float(v)
                if fv == fv:
                    lines.append(f"  {col}: {int(fv)}")
            except (TypeError, ValueError):
                pass
    return "\n".join(lines) or "  (not yet computed)"


def _format_indicators_as_narrative(indicators: Dict[str, Any]) -> str:
    """Fallback: flat key=value list when no DataFrame is available."""
    lines = "\n".join(
        f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}"
        for k, v in sorted(indicators.items())
        if not (isinstance(v, float) and v != v)
    )
    return lines or "  (no indicators computed yet)"
