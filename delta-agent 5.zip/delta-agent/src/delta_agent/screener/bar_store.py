"""Rolling OHLCV bar store per (symbol, timeframe)."""

from __future__ import annotations

import asyncio
from collections import deque
from typing import Dict, List, Optional, Tuple

import pandas as pd


class BarStore:
    """Thread-safe rolling OHLCV buffer keyed by (symbol, timeframe)."""

    def __init__(self, history_size: int = 200) -> None:
        self._history_size = history_size
        self._store: Dict[Tuple[str, str], deque] = {}
        self._lock = asyncio.Lock()

    async def push(self, symbol: str, timeframe: str, bar: dict) -> None:
        """Append a closed OHLCV bar. Bar must have keys: open, high, low, close, volume, timestamp."""
        key = (symbol, timeframe)
        async with self._lock:
            if key not in self._store:
                self._store[key] = deque(maxlen=self._history_size)
            self._store[key].append(bar)

    async def get_df(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Return a DataFrame copy of stored bars, or None if no bars yet."""
        key = (symbol, timeframe)
        async with self._lock:
            bars = list(self._store.get(key, []))
        if not bars:
            return None
        df = pd.DataFrame(bars)
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
        df = df.sort_values("timestamp").reset_index(drop=True)
        return df

    async def length(self, symbol: str, timeframe: str) -> int:
        key = (symbol, timeframe)
        async with self._lock:
            return len(self._store.get(key, []))

    def symbols_timeframes(self) -> List[Tuple[str, str]]:
        return list(self._store.keys())
