"""
MarketDataStore — unified OHLCV + indicator DataFrame per (symbol, timeframe).

Replaces the separate BarStore + IndicatorRunner pattern.
On every bar push, indicators are computed and appended as columns to the same row.
This gives free indicator history — just slice df.tail(n).
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Dict, FrozenSet, List, Optional, Tuple

import pandas as pd

try:
    import pandas_ta as ta  # type: ignore
except ImportError:
    ta = None

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

# ── Indicator column definitions ─────────────────────────────────────────────
# Each entry: (column_name, compute_fn(df) -> float)
# compute_fn receives the full df up to and including the new bar.

IndicatorDef = Tuple[str, Callable[[pd.DataFrame], float]]

_INDICATOR_DEFS: List[IndicatorDef] = []


def _register(name: str, fn: Callable[[pd.DataFrame], float]) -> None:
    _INDICATOR_DEFS.append((name, fn))


def _safe(fn: Callable[[pd.DataFrame], float]) -> Callable[[pd.DataFrame], float]:
    def wrapper(df: pd.DataFrame) -> float:
        try:
            v = fn(df)
            return float(v) if v == v else float("nan")  # propagate NaN
        except Exception:
            return float("nan")
    return wrapper


def _build_indicator_defs() -> None:
    if ta is None:
        raise RuntimeError("pandas-ta not installed — run: pip install pandas-ta")

    # EMA
    for length in [9, 21, 50, 200]:
        l = length
        _register(f"ema_{l}", _safe(lambda df, l=l: float(
            ta.ema(df["close"], length=l).iloc[-1]
        )))

    # RSI
    _register("rsi_14", _safe(lambda df: float(
        ta.rsi(df["close"], length=14).iloc[-1]
    )))

    # MACD line / signal / histogram
    def _macd_col(df: pd.DataFrame, col: str) -> float:
        r = ta.macd(df["close"], fast=12, slow=26, signal=9)
        return float(r[col].iloc[-1]) if r is not None and col in r.columns else float("nan")

    _register("macd_line",   _safe(lambda df: _macd_col(df, "MACD_12_26_9")))
    _register("macd_signal", _safe(lambda df: _macd_col(df, "MACDs_12_26_9")))
    _register("macd_hist",   _safe(lambda df: _macd_col(df, "MACDh_12_26_9")))

    # Bollinger
    def _bb_col(df: pd.DataFrame, col: str) -> float:
        r = ta.bbands(df["close"], length=20, std=2.0)
        return float(r[col].iloc[-1]) if r is not None and col in r.columns else float("nan")

    _register("bb_upper",     _safe(lambda df: _bb_col(df, "BBU_20_2.0")))
    _register("bb_lower",     _safe(lambda df: _bb_col(df, "BBL_20_2.0")))
    _register("bb_mid",       _safe(lambda df: _bb_col(df, "BBM_20_2.0")))
    _register("bb_pct_b",     _safe(lambda df: _bb_col(df, "BBP_20_2.0")))
    _register("bb_bandwidth", _safe(lambda df: (
        (_bb_col(df, "BBU_20_2.0") - _bb_col(df, "BBL_20_2.0")) /
        _bb_col(df, "BBM_20_2.0") * 100
        if _bb_col(df, "BBM_20_2.0") != 0 else float("nan")
    )))

    # ATR
    _register("atr_14", _safe(lambda df: float(
        ta.atr(df["high"], df["low"], df["close"], length=14).iloc[-1]
    )))

    # VWAP
    def _vwap(df: pd.DataFrame) -> float:
        try:
            r = ta.vwap(df["high"], df["low"], df["close"], df["volume"])
            return float(r.iloc[-1]) if r is not None and not r.empty else float("nan")
        except Exception:
            typical = (df["high"] + df["low"] + df["close"]) / 3
            vol = df["volume"].replace(0, float("nan"))
            return float((typical * vol).sum() / vol.sum()) if vol.sum() > 0 else float("nan")

    _register("vwap", _safe(_vwap))

    # Stochastic
    def _stoch_col(df: pd.DataFrame, col: str) -> float:
        r = ta.stoch(df["high"], df["low"], df["close"], k=14, d=3, smooth_k=3)
        return float(r[col].iloc[-1]) if r is not None and col in r.columns else float("nan")

    _register("stoch_k", _safe(lambda df: _stoch_col(df, "STOCHk_14_3_3")))
    _register("stoch_d", _safe(lambda df: _stoch_col(df, "STOCHd_14_3_3")))


try:
    _build_indicator_defs()
except RuntimeError as _mds_init_err:
    log.warning("market_data_store_indicators_skipped", reason=str(_mds_init_err))

# Columns included in the per-candle CSV table passed to LLM
# (fast-moving, tell a story row-by-row)
TABLE_COLUMNS = [
    "close", "volume", "ema_9", "rsi_14", "macd_hist", "bb_pct_b", "atr_14",
]

# Columns kept as current-bar snapshot in "Market Structure" block
# (slow-moving, event signals, or single-value anchors)
STRUCTURE_COLUMNS = [
    "ema_21", "ema_50", "ema_200",
    "macd_line", "macd_signal",
    "bb_upper", "bb_lower", "bb_mid", "bb_bandwidth",
    "vwap", "stoch_k", "stoch_d",
]


class MarketDataStore:
    """
    Unified rolling DataFrame per (symbol, timeframe).

    On every push():
      - Appends new OHLCV bar as a row
      - Computes all indicator values for that row
      - Appends cross/event signals as additional columns
      - Trims to history_size rows

    get_df() returns the full enriched DataFrame.
    get_latest_signals() returns the last row as a flat dict (replaces IndicatorRunner.compute()).
    """

    def __init__(self, history_size: int = 250) -> None:
        self._history_size = history_size
        self._frames: Dict[Tuple[str, str], pd.DataFrame] = {}
        self._lock = asyncio.Lock()

    async def push(self, symbol: str, timeframe: str, bar: dict) -> None:
        key = (symbol, timeframe)
        async with self._lock:
            # Build new row from OHLCV
            row: Dict[str, Any] = {
                "timestamp": bar.get("timestamp", 0),
                "open":      float(bar.get("open",   0)),
                "high":      float(bar.get("high",   0)),
                "low":       float(bar.get("low",    0)),
                "close":     float(bar.get("close",  0)),
                "volume":    float(bar.get("volume", 0)),
            }

            # Append to existing frame or create new one
            is_new = key not in self._frames
            if is_new:
                self._frames[key] = pd.DataFrame([row])
            else:
                self._frames[key] = pd.concat(
                    [self._frames[key], pd.DataFrame([row])],
                    ignore_index=True,
                )

            df = self._frames[key]

            # Compute all indicators on the growing df
            for col_name, fn in _INDICATOR_DEFS:
                if len(df) >= 2:
                    val = fn(df)
                else:
                    val = float("nan")
                df.at[df.index[-1], col_name] = val

            # Compute cross / event signals on last row
            _compute_cross_events(df)

            # Trim to history_size
            if len(df) > self._history_size:
                self._frames[key] = df.iloc[-self._history_size:].reset_index(drop=True)
            else:
                self._frames[key] = df

            log.debug(
                "mds_bar_pushed",
                symbol=symbol, timeframe=timeframe,
                bars=len(self._frames[key]),
                close=row["close"], volume=row["volume"],
                rsi=round(float(df.at[df.index[-1], "rsi_14"]), 2) if "rsi_14" in df.columns and len(df) >= 2 else None,
                ema9=round(float(df.at[df.index[-1], "ema_9"]), 4) if "ema_9" in df.columns and len(df) >= 2 else None,
            )

    async def get_df(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        key = (symbol, timeframe)
        async with self._lock:
            df = self._frames.get(key)
            return df.copy() if df is not None else None

    async def get_latest_signals(self, symbol: str, timeframe: str) -> Dict[str, float]:
        """Returns last row as flat dict — replaces IndicatorRunner.compute()."""
        df = await self.get_df(symbol, timeframe)
        if df is None or df.empty:
            return {}
        last = df.iloc[-1].to_dict()
        # Return only numeric signal columns (exclude raw OHLCV timestamp)
        return {
            k: v for k, v in last.items()
            if k not in ("timestamp",) and isinstance(v, (int, float))
        }

    async def length(self, symbol: str, timeframe: str) -> int:
        key = (symbol, timeframe)
        async with self._lock:
            df = self._frames.get(key)
            return len(df) if df is not None else 0

    def symbols_timeframes(self) -> List[Tuple[str, str]]:
        return list(self._frames.keys())


def _compute_cross_events(df: pd.DataFrame) -> None:
    """Appends cross event columns to the last row of df in-place."""
    if len(df) < 2:
        return

    idx = df.index[-1]
    prev_idx = df.index[-2]

    def _val(col: str, row_idx) -> float:
        v = df.at[row_idx, col] if col in df.columns else float("nan")
        return float(v) if v == v else float("nan")

    # EMA 9/21 cross
    e9_now,  e9_prev  = _val("ema_9",  idx), _val("ema_9",  prev_idx)
    e21_now, e21_prev = _val("ema_21", idx), _val("ema_21", prev_idx)
    if all(v == v for v in [e9_now, e9_prev, e21_now, e21_prev]):
        df.at[idx, "ema_cross_up"]      = float(e9_prev <= e21_prev and e9_now > e21_now)
        df.at[idx, "ema_cross_down"]    = float(e9_prev >= e21_prev and e9_now < e21_now)
        df.at[idx, "ema_trend_bullish"] = float(e9_now > e21_now)
    else:
        df.at[idx, "ema_cross_up"]      = 0.0
        df.at[idx, "ema_cross_down"]    = 0.0
        df.at[idx, "ema_trend_bullish"] = 0.0

    # EMA 50/200 long-term bias
    e50_now  = _val("ema_50",  idx)
    e200_now = _val("ema_200", idx)
    df.at[idx, "ema_longterm_bullish"] = (
        float(e50_now > e200_now) if e50_now == e50_now and e200_now == e200_now
        else float("nan")
    )

    # MACD line vs signal cross
    ml_now, ms_now   = _val("macd_line", idx),   _val("macd_signal", idx)
    ml_prev, ms_prev = _val("macd_line", prev_idx), _val("macd_signal", prev_idx)
    if all(v == v for v in [ml_now, ms_now, ml_prev, ms_prev]):
        df.at[idx, "macd_cross_up"]   = float(ml_prev <= ms_prev and ml_now > ms_now)
        df.at[idx, "macd_cross_down"] = float(ml_prev >= ms_prev and ml_now < ms_now)
        df.at[idx, "macd_above_zero"] = float(ml_now > 0)
    else:
        df.at[idx, "macd_cross_up"]   = 0.0
        df.at[idx, "macd_cross_down"] = 0.0
        df.at[idx, "macd_above_zero"] = 0.0

    # Stoch cross
    sk_now, sd_now   = _val("stoch_k", idx),   _val("stoch_d", idx)
    sk_prev, sd_prev = _val("stoch_k", prev_idx), _val("stoch_d", prev_idx)
    if all(v == v for v in [sk_now, sd_now, sk_prev, sd_prev]):
        df.at[idx, "stoch_cross_up"]   = float(sk_prev <= sd_prev and sk_now > sd_now)
        df.at[idx, "stoch_cross_down"] = float(sk_prev >= sd_prev and sk_now < sd_now)
    else:
        df.at[idx, "stoch_cross_up"]   = 0.0
        df.at[idx, "stoch_cross_down"] = 0.0
