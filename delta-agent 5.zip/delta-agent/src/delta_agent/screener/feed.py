"""Delta Exchange WebSocket feed — streams closed OHLCV bars per symbol/timeframe."""

from __future__ import annotations

import asyncio
import json
import time
from typing import Callable, Coroutine, Dict, List, Optional, Tuple

import websockets
from websockets.exceptions import ConnectionClosed

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

# Delta subscription channel format
_CHANNEL_MAP = {
    "1m":  "candlestick_1m",
    "3m":  "candlestick_3m",
    "5m":  "candlestick_5m",
    "15m": "candlestick_15m",
    "30m": "candlestick_30m",
    "1h":  "candlestick_1h",
    "2h":  "candlestick_2h",
    "4h":  "candlestick_4h",
    "1d":  "candlestick_1d",
}

# type alias: callback called with (symbol, timeframe, bar_dict)
BarCallback = Callable[[str, str, dict], Coroutine]


class DeltaFeed:
    """
    Persistent WebSocket connection to Delta Exchange.
    Emits closed bars only via an async callback.
    Reconnects automatically with exponential backoff.
    """

    def __init__(
        self,
        ws_url: str,
        symbols: List[str],
        timeframes: List[str],
        on_bar: BarCallback,
    ) -> None:
        self._ws_url = ws_url
        self._symbols = symbols
        self._timeframes = timeframes
        self._on_bar = on_bar
        # Track last bar timestamp per (symbol, tf) to detect bar close
        self._last_ts: Dict[Tuple[str, str], int] = {}
        self._running = False

    async def run(self) -> None:
        """Run forever, reconnecting on any error."""
        self._running = True
        backoff = 1.0
        while self._running:
            try:
                await self._connect_and_stream()
                backoff = 1.0  # reset on clean exit
            except Exception as exc:
                log.warning("ws_feed_disconnected", error=str(exc), reconnect_in=backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60.0)

    async def stop(self) -> None:
        self._running = False

    async def _connect_and_stream(self) -> None:
        async with websockets.connect(self._ws_url, ping_interval=20, ping_timeout=30) as ws:
            log.info("ws_feed_connected", url=self._ws_url)
            await self._subscribe(ws)
            async for raw in ws:
                if not self._running:
                    break
                try:
                    await self._handle_message(raw)
                except Exception as exc:
                    log.error("ws_message_error", error=str(exc))

    async def _subscribe(self, ws) -> None:
        channels = []
        for tf in self._timeframes:
            ch = _CHANNEL_MAP.get(tf)
            if not ch:
                log.warning("unsupported_timeframe", timeframe=tf)
                continue
            for sym in self._symbols:
                channels.append(f"{ch}.{sym}")

        payload = json.dumps({"type": "subscribe", "payload": {"channels": [{"name": c} for c in channels]}})
        await ws.send(payload)
        log.info("ws_subscribed", channels=channels)

    async def _handle_message(self, raw: str) -> None:
        msg = json.loads(raw)
        msg_type = msg.get("type", "")

        # Delta sends candlestick updates as type "candlestick_1m" etc.
        if not msg_type.startswith("candlestick_"):
            log.debug("ws_non_candle_message", type=msg_type)
            return

        tf = msg_type.replace("candlestick_", "")
        if tf not in self._timeframes:
            return

        data = msg.get("candle", msg)  # Delta payload key varies by version
        symbol = data.get("symbol") or msg.get("symbol")
        if not symbol or symbol not in self._symbols:
            return

        bar_ts = int(data.get("time", data.get("timestamp", 0)))
        key = (symbol, tf)

        # A bar is "closed" when we receive a new bar with a later timestamp
        prev_ts = self._last_ts.get(key)
        if prev_ts is not None and bar_ts > prev_ts:
            # The previously tracked bar is now closed — emit it
            # (Delta sends the completed bar when the next bar opens)
            closed_bar = {
                "timestamp": bar_ts,
                "open": float(data.get("open", 0)),
                "high": float(data.get("high", 0)),
                "low": float(data.get("low", 0)),
                "close": float(data.get("close", 0)),
                "volume": float(data.get("volume", 0)),
            }
            log.debug("bar_closed", symbol=symbol, timeframe=tf, close=closed_bar["close"],
                      volume=closed_bar["volume"], ts=bar_ts)
            await self._on_bar(symbol, tf, closed_bar)
        elif prev_ts is None:
            log.debug("bar_first_seen", symbol=symbol, timeframe=tf, ts=bar_ts)

        self._last_ts[key] = bar_ts
