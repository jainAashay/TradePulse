"""Trigger gate: function-based rule registry + latest-wins dedup map + cooldown."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from delta_agent.logging_setup import get_logger
from delta_agent.screener.rules import get_rule

log = get_logger(__name__)


@dataclass
class RuleConfig:
    """One rule to evaluate for a symbol: name + thresholds from watchlist.yaml."""
    name: str
    thresholds: Dict[str, Any]


@dataclass
class TriggerEvent:
    symbol: str
    timeframe: str
    timestamp: float
    signals: Dict[str, float]
    rule_matched: str


class TriggerMap:
    """
    Latest-wins dedup map: at most one pending TriggerEvent per symbol.
    New event for the same symbol replaces any existing pending one.
    """

    def __init__(self) -> None:
        self._map: Dict[str, TriggerEvent] = {}
        self._lock = asyncio.Lock()
        self._event = asyncio.Event()

    async def put(self, evt: TriggerEvent) -> None:
        async with self._lock:
            replaced = self._map.get(evt.symbol)
            self._map[evt.symbol] = evt
            if replaced:
                log.debug("trigger_replaced", symbol=evt.symbol, old_rule=replaced.rule_matched)
        self._event.set()

    async def get_next(self) -> TriggerEvent:
        """Block until at least one event is available, then return one."""
        while True:
            await self._event.wait()
            async with self._lock:
                if self._map:
                    symbol = next(iter(self._map))
                    evt = self._map.pop(symbol)
                    if not self._map:
                        self._event.clear()
                    return evt
            self._event.clear()

    async def size(self) -> int:
        async with self._lock:
            return len(self._map)


class TriggerGate:
    """
    Evaluates a list of named rule functions per symbol.
    Fires if ANY rule passes (OR semantics across rules, configurable to ALL/AND).
    Enforces per-(symbol, timeframe) cooldown.

    Rules are plain Python functions registered in screener/rules.py.
    Thresholds come from watchlist.yaml — no DSL, no string parsing.
    """

    def __init__(
        self,
        trigger_map: TriggerMap,
        cooldown_minutes: int = 5,
    ) -> None:
        self._map = trigger_map
        self._cooldown_s = cooldown_minutes * 60
        self._last_trigger: Dict[Tuple[str, str], float] = {}

    async def evaluate(
        self,
        symbol: str,
        timeframe: str,
        df: pd.DataFrame,
        signals: Dict[str, float],
        rules: List[RuleConfig],
        match_all: bool = False,
    ) -> bool:
        """
        Evaluate rules against df + signals.

        match_all=False (default): fire if ANY rule passes (OR).
        match_all=True: fire only if ALL rules pass (AND).

        Returns True and enqueues TriggerEvent if triggered and cooldown elapsed.
        """
        key = (symbol, timeframe)
        now = time.monotonic()
        elapsed = now - self._last_trigger.get(key, 0.0)
        if elapsed < self._cooldown_s:
            log.debug("trigger_cooldown_active", symbol=symbol, timeframe=timeframe,
                      remaining_s=round(self._cooldown_s - elapsed, 1))
            return False

        fired_rule: Optional[str] = None
        results: List[Tuple[str, bool]] = []

        for rc in rules:
            fn = get_rule(rc.name)
            if fn is None:
                log.warning("unknown_rule", rule=rc.name, symbol=symbol)
                results.append((rc.name, False))
                continue
            try:
                passed = fn(df, signals, rc.thresholds)
            except Exception as exc:
                log.warning("rule_error", rule=rc.name, symbol=symbol, error=str(exc))
                passed = False
            results.append((rc.name, passed))
            log.debug("rule_evaluated", symbol=symbol, rule=rc.name, passed=passed)

        if match_all:
            triggered = all(passed for _, passed in results)
            fired_rule = " AND ".join(name for name, _ in results) if triggered else None
        else:
            for name, passed in results:
                if passed:
                    fired_rule = name
                    break
            triggered = fired_rule is not None

        if not triggered:
            log.debug("trigger_no_rules_fired", symbol=symbol, timeframe=timeframe,
                      evaluated=[n for n, _ in results])
            return False

        self._last_trigger[key] = now
        evt = TriggerEvent(
            symbol=symbol,
            timeframe=timeframe,
            timestamp=time.time(),
            signals=signals,
            rule_matched=fired_rule or "",
        )
        await self._map.put(evt)
        log.info("trigger_fired", symbol=symbol, timeframe=timeframe, rule=fired_rule)
        return True

    async def _bypass(self, evt: TriggerEvent) -> bool:
        """Cooldown-only path used when trigger_gate_enabled=false. Skips all rule evaluation."""
        key = (evt.symbol, evt.timeframe)
        now = time.monotonic()
        elapsed = now - self._last_trigger.get(key, 0.0)
        if elapsed < self._cooldown_s:
            log.debug("trigger_cooldown_active", symbol=evt.symbol, timeframe=evt.timeframe,
                      remaining_s=round(self._cooldown_s - elapsed, 1))
            return False
        self._last_trigger[key] = now
        await self._map.put(evt)
        log.info("trigger_fired", symbol=evt.symbol, timeframe=evt.timeframe, rule="gate_disabled")
        return True
