"""Indicator registry and runner using pandas-ta."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, FrozenSet, List, Optional, Tuple

import pandas as pd

try:
    import pandas_ta as ta  # type: ignore
except ImportError:
    ta = None  # noqa: N816 — optional at import time; fails loudly in compute

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class IndicatorKey:
    name: str
    params: FrozenSet[Tuple[str, Any]]

    @classmethod
    def make(cls, name: str, params: Dict[str, Any]) -> "IndicatorKey":
        return cls(name=name, params=frozenset(params.items()))


# Registry: IndicatorKey -> compute(df) -> float
_REGISTRY: Dict[IndicatorKey, Callable[[pd.DataFrame], float]] = {}


def register_indicator(name: str, params: Dict[str, Any], fn: Callable[[pd.DataFrame], float]) -> None:
    key = IndicatorKey.make(name, params)
    _REGISTRY[key] = fn


# ── Individual indicator functions ────────────────────────────────────────────

def _ema_fn(length: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.ema(df["close"], length=length)
        return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
    return compute


def _rsi_fn(length: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.rsi(df["close"], length=length)
        return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
    return compute


def _macd_line_fn(fast: int, slow: int, signal: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.macd(df["close"], fast=fast, slow=slow, signal=signal)
        if result is None or result.empty:
            return float("nan")
        col = f"MACD_{fast}_{slow}_{signal}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _macd_signal_fn(fast: int, slow: int, signal: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.macd(df["close"], fast=fast, slow=slow, signal=signal)
        if result is None or result.empty:
            return float("nan")
        col = f"MACDs_{fast}_{slow}_{signal}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _macd_hist_fn(fast: int, slow: int, signal: int) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.macd(df["close"], fast=fast, slow=slow, signal=signal)
        if result is None or result.empty:
            return float("nan")
        col = f"MACDh_{fast}_{slow}_{signal}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_upper_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBU_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_lower_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBL_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_mid_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    def compute(df: pd.DataFrame) -> float:
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBM_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_pct_b_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    """%B: position of price within the Bollinger Band (0=lower, 1=upper, >1 overbought, <0 oversold)."""
    def compute(df: pd.DataFrame) -> float:
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        col = f"BBP_{length}_{std}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _bollinger_bandwidth_fn(length: int, std: float) -> Callable[[pd.DataFrame], float]:
    """Bandwidth = (upper - lower) / mid — measures volatility squeeze."""
    def compute(df: pd.DataFrame) -> float:
        result = ta.bbands(df["close"], length=length, std=std)
        if result is None or result.empty:
            return float("nan")
        upper_col = f"BBU_{length}_{std}"
        lower_col = f"BBL_{length}_{std}"
        mid_col   = f"BBM_{length}_{std}"
        if not all(c in result.columns for c in [upper_col, lower_col, mid_col]):
            return float("nan")
        upper = float(result[upper_col].iloc[-1])
        lower = float(result[lower_col].iloc[-1])
        mid   = float(result[mid_col].iloc[-1])
        return (upper - lower) / mid * 100 if mid != 0 else float("nan")
    return compute


def _atr_fn(length: int) -> Callable[[pd.DataFrame], float]:
    """Average True Range — absolute volatility measure."""
    def compute(df: pd.DataFrame) -> float:
        result = ta.atr(df["high"], df["low"], df["close"], length=length)
        return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
    return compute


def _vwap_fn() -> Callable[[pd.DataFrame], float]:
    """VWAP — volume-weighted average price (intraday anchor)."""
    def compute(df: pd.DataFrame) -> float:
        if "volume" not in df.columns:
            return float("nan")
        # pandas-ta vwap needs a DatetimeIndex; fall back to manual calc
        try:
            result = ta.vwap(df["high"], df["low"], df["close"], df["volume"])
            return float(result.iloc[-1]) if result is not None and not result.empty else float("nan")
        except Exception:
            # Manual VWAP over available bars
            typical = (df["high"] + df["low"] + df["close"]) / 3
            vol = df["volume"].replace(0, float("nan"))
            return float((typical * vol).sum() / vol.sum()) if vol.sum() > 0 else float("nan")
    return compute


def _stoch_k_fn(k: int, d: int, smooth: int) -> Callable[[pd.DataFrame], float]:
    """Stochastic %K — momentum oscillator."""
    def compute(df: pd.DataFrame) -> float:
        result = ta.stoch(df["high"], df["low"], df["close"], k=k, d=d, smooth_k=smooth)
        if result is None or result.empty:
            return float("nan")
        col = f"STOCHk_{k}_{d}_{smooth}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def _stoch_d_fn(k: int, d: int, smooth: int) -> Callable[[pd.DataFrame], float]:
    """Stochastic %D — signal line."""
    def compute(df: pd.DataFrame) -> float:
        result = ta.stoch(df["high"], df["low"], df["close"], k=k, d=d, smooth_k=smooth)
        if result is None or result.empty:
            return float("nan")
        col = f"STOCHd_{k}_{d}_{smooth}"
        return float(result[col].iloc[-1]) if col in result.columns else float("nan")
    return compute


def register_builtins() -> None:
    """Register all built-in indicators."""
    if ta is None:
        raise RuntimeError("pandas-ta not installed — run: pip install pandas-ta")

    # EMAs
    for length in [9, 21, 50, 200]:
        register_indicator("ema", {"length": length}, _ema_fn(length))

    # RSI
    register_indicator("rsi", {"length": 14}, _rsi_fn(14))

    # MACD — line, signal, histogram
    register_indicator("macd_line",   {"fast": 12, "slow": 26, "signal": 9}, _macd_line_fn(12, 26, 9))
    register_indicator("macd_signal", {"fast": 12, "slow": 26, "signal": 9}, _macd_signal_fn(12, 26, 9))
    register_indicator("macd_hist",   {"fast": 12, "slow": 26, "signal": 9}, _macd_hist_fn(12, 26, 9))

    # Bollinger Bands — upper, lower, mid, %B, bandwidth
    register_indicator("bollinger_upper",     {"length": 20, "std": 2.0}, _bollinger_upper_fn(20, 2.0))
    register_indicator("bollinger_lower",     {"length": 20, "std": 2.0}, _bollinger_lower_fn(20, 2.0))
    register_indicator("bollinger_mid",       {"length": 20, "std": 2.0}, _bollinger_mid_fn(20, 2.0))
    register_indicator("bollinger_pct_b",     {"length": 20, "std": 2.0}, _bollinger_pct_b_fn(20, 2.0))
    register_indicator("bollinger_bandwidth", {"length": 20, "std": 2.0}, _bollinger_bandwidth_fn(20, 2.0))

    # ATR (volatility)
    register_indicator("atr", {"length": 14}, _atr_fn(14))

    # VWAP
    register_indicator("vwap", {}, _vwap_fn())

    # Stochastic
    register_indicator("stoch_k", {"k": 14, "d": 3, "smooth": 3}, _stoch_k_fn(14, 3, 3))
    register_indicator("stoch_d", {"k": 14, "d": 3, "smooth": 3}, _stoch_d_fn(14, 3, 3))


class IndicatorRunner:
    """
    Compute all registered indicators for a given (symbol, timeframe) bar DataFrame.
    Returns a flat dict of named scalar values plus cross event booleans.
    """

    def __init__(self, bar_store) -> None:
        self._bar_store = bar_store

    async def compute(self, symbol: str, timeframe: str) -> Dict[str, float]:
        df = await self._bar_store.get_df(symbol, timeframe)
        if df is None or len(df) < 2:
            return {}

        results: Dict[str, float] = {}
        for key, fn in _REGISTRY.items():
            label = _make_label(key)
            try:
                results[label] = fn(df)
            except Exception as exc:
                log.warning("indicator_compute_error", indicator=label, error=str(exc))
                results[label] = float("nan")

        _add_cross_events(results, df)
        return results


def _make_label(key: IndicatorKey) -> str:
    if not key.params:
        return key.name
    suffix = "_".join(str(v) for _, v in sorted(key.params))
    return f"{key.name}_{suffix}"


def _add_cross_events(results: Dict[str, float], df: pd.DataFrame) -> None:
    """
    EMA cross events (9 vs 21) and MACD line vs signal cross events.
    All cross signals are float 1.0 (true) or 0.0 (false).
    """
    if len(df) < 2:
        return

    # ── EMA 9/21 crossover ──────────────────────────────────────────────────
    ema9_now  = results.get("ema_9",  float("nan"))
    ema21_now = results.get("ema_21", float("nan"))
    if ema9_now == ema9_now and ema21_now == ema21_now:
        try:
            ema9_prev  = float(ta.ema(df["close"].iloc[:-1], length=9).iloc[-1])
            ema21_prev = float(ta.ema(df["close"].iloc[:-1], length=21).iloc[-1])
            results["ema_fast_cross_up"]   = float(ema9_prev <= ema21_prev and ema9_now > ema21_now)
            results["ema_fast_cross_down"] = float(ema9_prev >= ema21_prev and ema9_now < ema21_now)
            # EMA trend bias: is fast above slow?
            results["ema_trend_bullish"] = float(ema9_now > ema21_now)
        except Exception:
            results["ema_fast_cross_up"]   = 0.0
            results["ema_fast_cross_down"] = 0.0
            results["ema_trend_bullish"]   = 0.0
    else:
        results["ema_fast_cross_up"]   = 0.0
        results["ema_fast_cross_down"] = 0.0
        results["ema_trend_bullish"]   = 0.0

    # ── EMA 50/200 long-term trend bias ─────────────────────────────────────
    ema50_now  = results.get("ema_50",  float("nan"))
    ema200_now = results.get("ema_200", float("nan"))
    if ema50_now == ema50_now and ema200_now == ema200_now:
        results["ema_longterm_bullish"] = float(ema50_now > ema200_now)
    else:
        results["ema_longterm_bullish"] = float("nan")

    # ── MACD line vs signal crossover ───────────────────────────────────────
    macd_line_now   = results.get("macd_line_12_26_9",   float("nan"))
    macd_signal_now = results.get("macd_signal_12_26_9", float("nan"))
    if macd_line_now == macd_line_now and macd_signal_now == macd_signal_now:
        try:
            prev_df = df.iloc[:-1]
            macd_prev = ta.macd(prev_df["close"], fast=12, slow=26, signal=9)
            if macd_prev is not None and not macd_prev.empty:
                ml_prev = float(macd_prev["MACD_12_26_9"].iloc[-1])
                ms_prev = float(macd_prev["MACDs_12_26_9"].iloc[-1])
                results["macd_cross_up"]   = float(ml_prev <= ms_prev and macd_line_now > macd_signal_now)
                results["macd_cross_down"] = float(ml_prev >= ms_prev and macd_line_now < macd_signal_now)
                # MACD above zero line = bullish momentum
                results["macd_above_zero"] = float(macd_line_now > 0)
            else:
                results["macd_cross_up"]   = 0.0
                results["macd_cross_down"] = 0.0
                results["macd_above_zero"] = float(macd_line_now > 0)
        except Exception:
            results["macd_cross_up"]   = 0.0
            results["macd_cross_down"] = 0.0
            results["macd_above_zero"] = 0.0
    else:
        results["macd_cross_up"]   = 0.0
        results["macd_cross_down"] = 0.0
        results["macd_above_zero"] = 0.0

    # ── Stochastic crossover ─────────────────────────────────────────────────
    stoch_k_now = results.get("stoch_k_14_3_3", float("nan"))
    stoch_d_now = results.get("stoch_d_14_3_3", float("nan"))
    if stoch_k_now == stoch_k_now and stoch_d_now == stoch_d_now:
        try:
            prev_df   = df.iloc[:-1]
            stoch_prev = ta.stoch(prev_df["high"], prev_df["low"], prev_df["close"], k=14, d=3, smooth_k=3)
            if stoch_prev is not None and not stoch_prev.empty:
                sk_prev = float(stoch_prev["STOCHk_14_3_3"].iloc[-1])
                sd_prev = float(stoch_prev["STOCHd_14_3_3"].iloc[-1])
                results["stoch_cross_up"]   = float(sk_prev <= sd_prev and stoch_k_now > stoch_d_now)
                results["stoch_cross_down"] = float(sk_prev >= sd_prev and stoch_k_now < stoch_d_now)
            else:
                results["stoch_cross_up"]   = 0.0
                results["stoch_cross_down"] = 0.0
        except Exception:
            results["stoch_cross_up"]   = 0.0
            results["stoch_cross_down"] = 0.0
    else:
        results["stoch_cross_up"]   = 0.0
        results["stoch_cross_down"] = 0.0
