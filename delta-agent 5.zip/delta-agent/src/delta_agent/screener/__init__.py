"""Screener package: WebSocket feed, bar store, indicators, trigger gate."""
