"""
Screener rule registry.

A rule is a plain Python function:
    (df: pd.DataFrame, signals: dict[str, float], thresholds: dict[str, Any]) -> bool

Register with @rule("name"). Add new rules here — no DSL, no parser.
Thresholds come directly from watchlist.yaml per symbol, so each symbol
can have different sensitivity without touching code.
"""

from __future__ import annotations

from typing import Any, Callable, Dict

import pandas as pd

from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

# Registry: name -> rule function
_RULES: Dict[str, Callable[[pd.DataFrame, Dict[str, float], Dict[str, Any]], bool]] = {}

RuleFn = Callable[[pd.DataFrame, Dict[str, float], Dict[str, Any]], bool]


def rule(name: str) -> Callable[[RuleFn], RuleFn]:
    """Decorator to register a rule function by name."""
    def decorator(fn: RuleFn) -> RuleFn:
        _RULES[name] = fn
        return fn
    return decorator


def get_rule(name: str) -> RuleFn | None:
    return _RULES.get(name)


def list_rules() -> list[str]:
    return list(_RULES.keys())


# ── Built-in rules ────────────────────────────────────────────────────────────

@rule("rsi_oversold")
def rsi_oversold(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """RSI below threshold — potential long entry."""
    threshold = float(thresholds.get("threshold", 30))
    rsi = signals.get("rsi_14", float("nan"))
    return rsi == rsi and rsi < threshold


@rule("rsi_overbought")
def rsi_overbought(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """RSI above threshold — potential short entry."""
    threshold = float(thresholds.get("threshold", 70))
    rsi = signals.get("rsi_14", float("nan"))
    return rsi == rsi and rsi > threshold


@rule("ema_cross_up")
def ema_cross_up(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """Fast EMA crossed above slow EMA on the last closed bar."""
    # MarketDataStore emits "ema_cross_up"; IndicatorRunner used "ema_fast_cross_up"
    return bool(signals.get("ema_cross_up", 0) or signals.get("ema_fast_cross_up", 0))


@rule("ema_cross_down")
def ema_cross_down(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """Fast EMA crossed below slow EMA on the last closed bar."""
    return bool(signals.get("ema_cross_down", 0) or signals.get("ema_fast_cross_down", 0))


@rule("candle_momentum")
def candle_momentum(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """
    Close price change over last N candles exceeds min_pct_change.

    Thresholds:
      candles: int   — lookback window (default 4)
      min_pct: float — minimum % move, e.g. 0.1 means 0.1% (default 0.1)
      direction: "up" | "down" | "any" (default "any")
    """
    n = int(thresholds.get("candles", 4))
    min_pct = float(thresholds.get("min_pct", 0.1))
    direction = str(thresholds.get("direction", "any"))

    if len(df) < n + 1:
        return False

    close_now = float(df["close"].iloc[-1])
    close_prev = float(df["close"].iloc[-(n + 1)])
    if close_prev == 0:
        return False

    pct_change = (close_now - close_prev) / close_prev * 100

    if direction == "up":
        return pct_change > min_pct
    if direction == "down":
        return pct_change < -min_pct
    return abs(pct_change) > min_pct


@rule("volume_spike")
def volume_spike(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """
    Current bar volume exceeds N-bar average by a multiplier.

    Thresholds:
      lookback: int      — bars to average (default 20)
      multiplier: float  — e.g. 2.0 means 2x average volume (default 2.0)
    """
    lookback = int(thresholds.get("lookback", 20))
    multiplier = float(thresholds.get("multiplier", 2.0))

    if len(df) < lookback + 1:
        return False

    avg_vol = df["volume"].iloc[-(lookback + 1):-1].mean()
    cur_vol = float(df["volume"].iloc[-1])
    if avg_vol == 0:
        return False

    return cur_vol > avg_vol * multiplier


@rule("price_near_ema")
def price_near_ema(df: pd.DataFrame, signals: Dict[str, float], thresholds: Dict[str, Any]) -> bool:
    """
    Close price is within `within_pct`% of a given EMA.
    Useful for mean-reversion setups.

    Thresholds:
      ema_length: int    — which EMA to reference (default 21)
      within_pct: float  — proximity threshold % (default 0.2)
    """
    length = int(thresholds.get("ema_length", 21))
    within_pct = float(thresholds.get("within_pct", 0.2))

    ema_val = signals.get(f"ema_{length}", float("nan"))
    if ema_val != ema_val or ema_val == 0:
        return False

    close = float(df["close"].iloc[-1])
    pct_diff = abs(close - ema_val) / ema_val * 100
    return pct_diff <= within_pct
