"""CryptoNews API poller with 15-minute cache."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import httpx

from delta_agent.config.settings import NewsConfig
from delta_agent.logging_setup import get_logger

log = get_logger(__name__)

_BASE_URL = "https://cryptonews-api.com/api/v1"
_ITEMS_PER_REQUEST = 10


def _age_label(date_str: str) -> str:
    """Convert article date string to a human-readable age like '2h ago'."""
    try:
        # API returns ET strings like "Mon, 02 Jun 2025 14:30:00 -0400"
        dt = datetime.strptime(date_str, "%a, %d %b %Y %H:%M:%S %z")
        minutes = int((datetime.now(timezone.utc) - dt).total_seconds() / 60)
        if minutes < 60:
            return f"{minutes}m ago"
        if minutes < 1440:
            return f"{minutes // 60}h ago"
        return f"{minutes // 1440}d ago"
    except Exception:
        return date_str[:16] if date_str else "?"


@dataclass
class SentimentSummary:
    bullish_count: int
    bearish_count: int
    neutral_count: int
    # (title, date_str, sentiment) per article
    top_headlines: List[Tuple[str, str, str]]
    fetched_at: float = field(default_factory=time.time)

    def is_stale(self, ttl_seconds: int) -> bool:
        return (time.time() - self.fetched_at) > ttl_seconds

    def as_text(self, max_chars: int = 1000) -> str:
        total = self.bullish_count + self.bearish_count + self.neutral_count or 1
        summary_line = (
            f"Bullish: {self.bullish_count}/{total}  "
            f"Bearish: {self.bearish_count}/{total}  "
            f"Neutral: {self.neutral_count}/{total}"
        )
        lines = [summary_line, "Headlines:"]
        budget = max_chars - len(summary_line) - len("Headlines:\n")
        for title, date_str, _sentiment in self.top_headlines:
            age = _age_label(date_str)
            entry = f"  [{age}] {title[:150]}"
            if budget - len(entry) - 1 < 0:
                break
            lines.append(entry)
            budget -= len(entry) + 1
        return "\n".join(lines)[:max_chars]


class NewsCache:
    """In-memory cache of SentimentSummary keyed by symbol."""

    def __init__(self, ttl_seconds: int = 120) -> None:
        self._cache: Dict[str, SentimentSummary] = {}
        self._ttl = ttl_seconds

    def put(self, symbol: str, summary: SentimentSummary) -> None:
        self._cache[symbol] = summary

    def get(self, symbol: str) -> Optional[SentimentSummary]:
        s = self._cache.get(symbol)
        if s and s.is_stale(self._ttl):
            return None
        return s


class NewsPoller:
    """
    Background asyncio task. Polls CryptoNews API every 5 minutes.
    Silently disabled if API key is missing.

    Uses /crypto-ticker-news endpoint — returns headline + pre-computed sentiment
    (Positive / Negative / Neutral) per article, so no vote aggregation needed.
    """

    def __init__(self, config: NewsConfig, symbols: List[str], cache: NewsCache) -> None:
        self._config = config
        self._symbols = symbols
        self._cache = cache
        self._api_key = config.resolve_api_key()
        self._poll_interval = config.poll_interval_seconds
        self._running = False

    async def run(self) -> None:
        if not self._api_key:
            log.info("news_poller_disabled_no_api_key")
            return
        self._running = True
        await self._fetch_all()
        while self._running:
            await asyncio.sleep(self._poll_interval)
            await self._fetch_all()

    async def stop(self) -> None:
        self._running = False

    async def _fetch_all(self) -> None:
        for symbol in self._symbols:
            try:
                await self._fetch(symbol)
            except Exception as exc:
                log.warning("news_fetch_error", symbol=symbol, error=str(exc))

    async def _fetch(self, symbol: str) -> None:
        ticker = symbol.replace("USD", "").replace("PERP", "")
        params = {
            "tickers": ticker,
            "items": _ITEMS_PER_REQUEST,
            "token": self._api_key,
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{_BASE_URL}/crypto-ticker-news", params=params)
            resp.raise_for_status()
            data = resp.json()

        articles = data.get("data", [])
        bullish = sum(1 for a in articles if str(a.get("sentiment", "")).lower() == "positive")
        bearish = sum(1 for a in articles if str(a.get("sentiment", "")).lower() == "negative")
        neutral = len(articles) - bullish - bearish
        headlines = [
            (a["title"], a.get("date", ""), a.get("sentiment", "neutral"))
            for a in articles[:5]
            if a.get("title")
        ]

        summary = SentimentSummary(
            bullish_count=bullish,
            bearish_count=bearish,
            neutral_count=neutral,
            top_headlines=headlines,
        )
        self._cache.put(symbol, summary)
        log.debug("news_fetched", symbol=symbol, bullish=bullish, bearish=bearish, neutral=neutral)
