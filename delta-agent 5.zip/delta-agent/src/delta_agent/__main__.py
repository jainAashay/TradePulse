"""Agent entrypoint: boots all subsystems and runs the async event loop."""

from __future__ import annotations

import asyncio
import time

from dotenv import load_dotenv

from delta_agent.agent.loop import AgentLoop
from delta_agent.analyzer.context import Analyzer
from delta_agent.config import load_settings
from delta_agent.execution.client import DeltaExchangeClient
from delta_agent.execution.manager import ExecutionManager
from delta_agent.health.alerter import Alerter
from delta_agent.health.server import start_health_server
from delta_agent.health.telegram_bot import TelegramCommandHandler
from delta_agent.llm import create_llm_runtime
from delta_agent.logging_setup import configure_logging, get_logger
from delta_agent.news.poller import NewsCache, NewsPoller
from delta_agent.persistence.db import Database
from delta_agent.reflection.detector import ClosedTradeDetector
from delta_agent.reflection.pipeline import ReflectionPipeline
from delta_agent.risk.engine import RiskEngine
from delta_agent.risk.state import RiskState
from delta_agent.screener.feed import DeltaFeed
from delta_agent.screener.market_data_store import MarketDataStore
from delta_agent.screener.trigger import RuleConfig, TriggerEvent, TriggerGate, TriggerMap


async def run() -> None:
    load_dotenv()
    settings = load_settings()
    configure_logging(settings.log_level)
    log = get_logger("delta_agent.main")

    symbols    = [w.symbol for w in settings.watchlist.watchlist]
    timeframes = settings.screener.timeframes

    # Build per-symbol rule lists from watchlist; fall back to default RSI+EMA rules
    _default_rules = [
        RuleConfig("rsi_oversold",  {"threshold": settings.screener.default_rules.rsi_oversold}),
        RuleConfig("rsi_overbought", {"threshold": settings.screener.default_rules.rsi_overbought}),
    ]
    if settings.screener.default_rules.require_ema_cross:
        _default_rules += [
            RuleConfig("ema_cross_up",   {}),
            RuleConfig("ema_cross_down", {}),
        ]
    _symbol_rules: dict[str, list[RuleConfig]] = {
        w.symbol: [RuleConfig(r["name"], r.get("thresholds") or {}) for r in w.rules] or _default_rules
        for w in settings.watchlist.watchlist
    }

    log.info("booting", profile=settings.active_profile, symbols=symbols, timeframes=timeframes)

    # ── Persistence ────────────────────────────────────────────────────────
    db = Database(settings.persistence.sqlite_path)

    # ── LLM + Memory ───────────────────────────────────────────────────────
    llm_runtime = create_llm_runtime(settings)

    # ── Risk state (load + recompute from DB) ──────────────────────────────
    risk_state = RiskState.load(db)

    # ── Market data store (unified OHLCV + indicators DataFrame) ──────────
    market_data_store = MarketDataStore(history_size=settings.screener.bar_history_size)

    # ── Screener ───────────────────────────────────────────────────────────
    trigger_map  = TriggerMap()
    trigger_gate = TriggerGate(trigger_map, cooldown_minutes=settings.screener.trigger_cooldown_minutes)

    async def on_bar(symbol: str, timeframe: str, bar: dict) -> None:
        await market_data_store.push(symbol, timeframe, bar)
        signals = await market_data_store.get_latest_signals(symbol, timeframe)
        if not signals:
            log.debug("on_bar_no_signals_yet", symbol=symbol, timeframe=timeframe)
            return

        bar_count = await market_data_store.length(symbol, timeframe)
        log.debug("on_bar_processed", symbol=symbol, timeframe=timeframe,
                  bars=bar_count, close=bar.get("close"), rsi=signals.get("rsi_14"))

        # Watch mode: open position → bypass gate, push directly to TriggerMap every candle
        open_order = db.get_open_position_for_symbol(symbol)
        if open_order:
            log.info("on_bar_watch_mode", symbol=symbol, timeframe=timeframe,
                     order_id=open_order["id"], entry_price=open_order.get("entry_price"))
            evt = TriggerEvent(
                symbol=symbol,
                timeframe=timeframe,
                timestamp=time.time(),
                signals=signals,
                rule_matched="watch_mode",
            )
            await trigger_map.put(evt)
            return

        # Scan mode: apply rules + cooldown (or bypass gate if disabled)
        df = await market_data_store.get_df(symbol, timeframe)
        if not settings.screener.trigger_gate_enabled:
            log.debug("on_bar_gate_bypassed", symbol=symbol, timeframe=timeframe)
            evt = TriggerEvent(
                symbol=symbol,
                timeframe=timeframe,
                timestamp=time.time(),
                signals=signals,
                rule_matched="gate_disabled",
            )
            await trigger_gate._bypass(evt)
        else:
            rules = _symbol_rules.get(symbol, _default_rules)
            log.debug("on_bar_scan_mode", symbol=symbol, timeframe=timeframe,
                      rules=[r.name for r in rules])
            await trigger_gate.evaluate(symbol, timeframe, df, signals, rules)

    feed = DeltaFeed(
        ws_url=settings.profile.delta.ws_url,
        symbols=symbols,
        timeframes=timeframes,
        on_bar=on_bar,
    )

    # ── Exchange client ─────────────────────────────────────────────────────
    exchange_client = DeltaExchangeClient(settings)
    await exchange_client.init_ccxt()

    # ── Alerter ────────────────────────────────────────────────────────────
    alerter = Alerter()

    # ── News cache + poller ────────────────────────────────────────────────
    news_cache  = NewsCache(ttl_seconds=settings.news.cache_ttl_seconds)
    news_poller = NewsPoller(settings.news, symbols, news_cache)

    # ── Reflection ─────────────────────────────────────────────────────────
    detector = ClosedTradeDetector(
        exchange_client, db,
        fills_lookback_hours=settings.execution.fills_lookback_hours,
    )
    reflection = ReflectionPipeline(
        detector=detector,
        llm_runtime=llm_runtime,
        memory=llm_runtime.memory,
        db=db,
        risk_state=risk_state,
        max_lesson_chars=settings.memory.max_lesson_chars,
        alerter=alerter,
    )

    # ── Execution ──────────────────────────────────────────────────────────
    execution_manager = ExecutionManager(exchange_client, db, settings, reflection=reflection)

    # Startup reconciliation
    open_positions = await execution_manager.reconcile_on_startup()
    risk_state.open_positions = open_positions

    # Replay any closed orders that never produced a ChromaDB lesson (crash recovery)
    await reflection.replay_unreflected()

    # ── Analyzer ──────────────────────────────────────────────────────────
    analyzer = Analyzer(
        llm_runtime=llm_runtime,
        market_data_store=market_data_store,
        risk_config=settings.risk,
        news_cache=news_cache,
        max_news_chars=settings.news.max_news_chars,
        price_action_candles=settings.screener.price_action_candles,
    )

    # ── Risk engine ────────────────────────────────────────────────────────
    risk_engine = RiskEngine(settings.risk)

    # ── Agent loop ─────────────────────────────────────────────────────────
    _symbol_quantities = {w.symbol: w.quantity for w in settings.watchlist.watchlist}
    agent_loop = AgentLoop(
        trigger_map=trigger_map,
        analyzer=analyzer,
        risk_engine=risk_engine,
        risk_state=risk_state,
        db=db,
        execution_manager=execution_manager,
        alerter=alerter,
        symbol_quantities=_symbol_quantities,
    )
    agent_loop.startup()  # crash stale IN_FLIGHT cycles

    # ── Telegram bot ───────────────────────────────────────────────────────
    tg_bot = TelegramCommandHandler(alerter, db, risk_state)

    log.info("all_subsystems_ready", memory_backend=type(llm_runtime.memory).__name__)

    # ── Run all tasks concurrently ─────────────────────────────────────────
    await asyncio.gather(
        feed.run(),
        agent_loop.run(),
        news_poller.run(),
        detector.run(),
        reflection.run(),
        tg_bot.run(),
        start_health_server(db, risk_state),
    )


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
