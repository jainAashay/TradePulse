"""Vector memory contracts used by the Analyzer and Reflection pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, List, Optional, Protocol, runtime_checkable


@dataclass(frozen=True)
class LearningRecord:
    """Compact lesson stored in ChromaDB (Milestone 5)."""

    lesson_id: str
    text: str
    symbol: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@runtime_checkable
class VectorMemoryStore(Protocol):
    """Wrapper around Chroma (or any vector DB) for similarity search."""

    def add_learning(self, record: LearningRecord) -> None:
        """Persist a refined lesson embedding."""

    def search(self, query: str, *, top_k: int = 5) -> List[LearningRecord]:
        """Retrieve lessons relevant to the current market / decision context."""


@runtime_checkable
class LearningRefiner(Protocol):
    """Use the LLM to compress raw post-trade notes into token-efficient lessons."""

    def refine(self, raw_reflection: str, *, context: Optional[dict[str, Any]] = None) -> str:
        """Return a short, precise lesson suitable for RAG injection."""
