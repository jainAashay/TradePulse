"""In-memory stubs until ChromaDB is wired in Milestone 5."""

from __future__ import annotations

from typing import Any, List, Optional

from delta_agent.memory.protocols import LearningRecord, LearningRefiner, VectorMemoryStore


class StubVectorMemoryStore:
    def __init__(self) -> None:
        self._records: list[LearningRecord] = []

    def add_learning(self, record: LearningRecord) -> None:
        self._records.append(record)

    def search(self, query: str, *, top_k: int = 5) -> List[LearningRecord]:
        _ = query
        return self._records[-top_k:]


class StubLearningRefiner:
    def refine(self, raw_reflection: str, *, context: Optional[dict[str, Any]] = None) -> str:
        _ = context
        return raw_reflection.strip()[:400]
