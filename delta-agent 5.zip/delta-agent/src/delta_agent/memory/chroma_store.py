"""ChromaDB-backed vector memory store with local sentence-transformers embeddings."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List, Optional

from delta_agent.memory.protocols import LearningRecord
from delta_agent.logging_setup import get_logger

log = get_logger(__name__)


class ChromaVectorMemoryStore:
    """
    Persistent ChromaDB store using all-MiniLM-L6-v2 local embeddings.
    Token efficiency: only record.text (≤400 chars) is injected into prompts.
    Metadata (pnl, duration, confidence) stays in ChromaDB for filtering.
    """

    def __init__(self, persist_dir: str, collection_name: str) -> None:
        import chromadb  # type: ignore
        from chromadb.utils import embedding_functions  # type: ignore

        self._ef = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        self._client = chromadb.PersistentClient(path=persist_dir)
        self._collection = self._client.get_or_create_collection(
            name=collection_name,
            embedding_function=self._ef,
            metadata={"hnsw:space": "cosine"},
        )
        log.info("chroma_store_ready", collection=collection_name, persist_dir=persist_dir)

    def add_learning(self, record: LearningRecord) -> None:
        lesson_id = record.lesson_id or str(uuid.uuid4())
        metadata = {
            "symbol": record.symbol or "",
            "tags": ",".join(record.tags),
            "created_at": record.created_at.isoformat(),
            **{k: str(v) for k, v in record.metadata.items()},
        }
        self._collection.upsert(
            ids=[lesson_id],
            documents=[record.text],
            metadatas=[metadata],
        )
        log.info("learning_stored", lesson_id=lesson_id, symbol=record.symbol, chars=len(record.text))

    def search(self, query: str, *, top_k: int = 5) -> List[LearningRecord]:
        if self._collection.count() == 0:
            return []
        results = self._collection.query(
            query_texts=[query],
            n_results=min(top_k, self._collection.count()),
            include=["documents", "metadatas"],
        )
        records: List[LearningRecord] = []
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        ids = results.get("ids", [[]])[0]

        for doc, meta, rid in zip(docs, metas, ids):
            tags = [t for t in (meta.get("tags", "")).split(",") if t]
            records.append(
                LearningRecord(
                    lesson_id=rid,
                    text=doc,
                    symbol=meta.get("symbol") or None,
                    tags=tags,
                    metadata={k: v for k, v in meta.items() if k not in ("symbol", "tags", "created_at")},
                )
            )
        return records
