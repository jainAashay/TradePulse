"""Telegram alerter: fire-and-forget notifications."""

from __future__ import annotations

import asyncio
import os
from typing import Optional, TYPE_CHECKING

import httpx

from delta_agent.logging_setup import get_logger

if TYPE_CHECKING:
    from delta_agent.analyzer.decision import TradeDecision

log = get_logger(__name__)

_TELEGRAM_API = "https://api.telegram.org/bot{token}/sendMessage"


class Alerter:
    """
    Non-blocking Telegram notifications.
    All sends are fire-and-forget asyncio tasks — failures are logged, never raised.
    Silently disabled if TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID are not set.
    """

    def __init__(self) -> None:
        self._token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self._chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
        self._enabled = bool(self._token and self._chat_id)
        if not self._enabled:
            log.info("telegram_alerter_disabled_no_credentials")

    def _fire(self, text: str) -> None:
        if not self._enabled:
            return
        asyncio.create_task(self._send(text))

    async def _send(self, text: str) -> None:
        url = _TELEGRAM_API.format(token=self._token)
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                await client.post(url, json={"chat_id": self._chat_id, "text": text, "parse_mode": "HTML"})
        except Exception as exc:
            log.warning("telegram_send_failed", error=str(exc))

    async def send(self, text: str) -> None:
        """Public awaitable send (used by bot replies)."""
        await self._send(text)

    async def send_trade_entry(self, symbol: str, decision: "TradeDecision", order_id: int) -> None:
        msg = (
            f"<b>🟢 TRADE ENTRY</b>\n"
            f"Symbol: {symbol} | Action: {decision.action}\n"
            f"Leverage: {decision.leverage}x | Confidence: {decision.confidence:.0%}\n"
            f"SL: {decision.sl_pct}% | TP: {decision.tp_pcts}\n"
            f"Order ID: {order_id}\n"
            f"Reason: {decision.reasoning[:120]}"
        )
        self._fire(msg)

    async def send_trade_close(self, symbol: str, pnl_usd: float, hold_mins: float, outcome: str) -> None:
        emoji = "✅" if outcome == "win" else "❌"
        msg = (
            f"<b>{emoji} TRADE CLOSED</b>\n"
            f"Symbol: {symbol} | Outcome: {outcome.upper()}\n"
            f"PnL: {pnl_usd:+.2f} USD | Hold: {hold_mins:.1f} min"
        )
        self._fire(msg)

    async def send_rejection(self, symbol: str, reason: str) -> None:
        msg = f"<b>⚠️ TRADE REJECTED</b>\nSymbol: {symbol}\nReason: {reason}"
        self._fire(msg)

    async def send_circuit_breaker_tripped(self) -> None:
        self._fire("<b>🚨 CIRCUIT BREAKER TRIPPED</b>\nTrading halted. Send /reset to resume or wait until UTC midnight.")

    async def send_circuit_breaker_reset(self) -> None:
        self._fire("<b>✅ CIRCUIT BREAKER RESET</b>\nTrading resumed.")

    async def send_trading_paused(self) -> None:
        self._fire("<b>⏸ TRADING PAUSED</b>\nSend /resume to re-enable.")

    async def send_trading_resumed(self) -> None:
        self._fire("<b>▶️ TRADING RESUMED</b>")

    async def send_daily_summary(self, daily_orders: int, daily_pnl: float, win_rate: float) -> None:
        msg = (
            f"<b>📊 DAILY SUMMARY</b>\n"
            f"Orders: {daily_orders} | PnL: {daily_pnl:+.2f} USD | Win rate: {win_rate:.0%}"
        )
        self._fire(msg)

    async def send_system_warning(self, message: str) -> None:
        self._fire(f"<b>⚠️ SYSTEM WARNING</b>\n{message}")
