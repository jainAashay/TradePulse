"""Telegram command handler: /pause /resume /status /reset."""

from __future__ import annotations

import asyncio
import os
from typing import Optional, TYPE_CHECKING

import httpx

from delta_agent.health.alerter import Alerter
from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database
from delta_agent.risk.state import RiskState

if TYPE_CHECKING:
    pass

log = get_logger(__name__)

_GETUP_URL = "https://api.telegram.org/bot{token}/getUpdates"
_POLL_INTERVAL_S = 3


class TelegramCommandHandler:
    """
    Polls Telegram getUpdates every 3s.
    Only accepts commands from TELEGRAM_CHAT_ID.
    Commands: /pause, /resume, /status, /reset
    """

    def __init__(self, alerter: Alerter, db: Database, risk_state: RiskState) -> None:
        self._alerter = alerter
        self._db = db
        self._risk_state = risk_state
        self._token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self._chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
        self._enabled = bool(self._token and self._chat_id)
        self._last_update_id = 0
        self._running = False

    async def run(self) -> None:
        if not self._enabled:
            log.info("telegram_bot_disabled_no_credentials")
            return
        self._running = True
        while self._running:
            try:
                await self._poll()
            except Exception as exc:
                log.warning("telegram_poll_error", error=str(exc))
            await asyncio.sleep(_POLL_INTERVAL_S)

    async def stop(self) -> None:
        self._running = False

    async def _poll(self) -> None:
        url = _GETUP_URL.format(token=self._token)
        params = {"offset": self._last_update_id + 1, "timeout": 2, "allowed_updates": ["message"]}
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=params)
        data = resp.json()
        updates = data.get("result", [])
        for update in updates:
            self._last_update_id = update["update_id"]
            await self._handle_update(update)

    async def _handle_update(self, update: dict) -> None:
        msg = update.get("message", {})
        chat_id = str(msg.get("chat", {}).get("id", ""))
        text = (msg.get("text") or "").strip().lower()

        if chat_id != self._chat_id:
            return  # ignore messages from other chats

        if text == "/pause":
            self._db.set_config("trading_enabled", "false")
            log.info("trading_paused_via_telegram")
            await self._alerter.send_trading_paused()
            await self._alerter.send("Trading paused. Send /resume to re-enable.")

        elif text == "/resume":
            self._db.set_config("trading_enabled", "true")
            log.info("trading_resumed_via_telegram")
            await self._alerter.send_trading_resumed()
            await self._alerter.send("Trading resumed.")

        elif text == "/reset":
            self._risk_state.reset_circuit_breaker(self._db)
            log.info("circuit_breaker_reset_via_telegram")
            await self._alerter.send_circuit_breaker_reset()
            await self._alerter.send("Circuit breaker reset. Trading resumed.")

        elif text == "/status":
            enabled = self._db.is_trading_enabled()
            cb = self._risk_state.circuit_breaker_active
            status = (
                f"<b>📡 STATUS</b>\n"
                f"Trading enabled: {'✅' if enabled else '❌'}\n"
                f"Circuit breaker: {'🚨 ACTIVE' if cb else '✅ OFF'}\n"
                f"Open positions: {self._risk_state.open_positions}\n"
                f"Daily orders: {self._risk_state.daily_orders}\n"
                f"Daily PnL: {-self._risk_state.daily_loss_usd:+.2f} USD\n"
                f"Consecutive losses: {self._risk_state.consecutive_losses}"
            )
            await self._alerter.send(status)

        else:
            await self._alerter.send("Unknown command. Available: /pause /resume /status /reset")
