"""FastAPI health endpoint on :8080."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, TYPE_CHECKING

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from delta_agent.logging_setup import get_logger
from delta_agent.persistence.db import Database
from delta_agent.risk.state import RiskState

if TYPE_CHECKING:
    pass

log = get_logger(__name__)

_start_time = time.time()


def create_app(db: Database, risk_state: RiskState) -> FastAPI:
    app = FastAPI(title="delta-agent health", docs_url=None, redoc_url=None)

    @app.get("/health")
    async def health() -> Dict[str, Any]:
        return {
            "status": "ok",
            "uptime_seconds": int(time.time() - _start_time),
            "open_positions": risk_state.open_positions,
            "daily_orders": risk_state.daily_orders,
            "daily_loss_usd": round(risk_state.daily_loss_usd, 2),
            "circuit_breaker": risk_state.circuit_breaker_active,
            "trading_enabled": db.is_trading_enabled(),
            "consecutive_losses": risk_state.consecutive_losses,
        }

    @app.post("/health/reset-circuit-breaker")
    async def reset_circuit_breaker() -> Dict[str, str]:
        risk_state.reset_circuit_breaker(db)
        log.info("circuit_breaker_reset_via_http")
        return {"status": "circuit_breaker_reset"}

    return app


async def start_health_server(db: Database, risk_state: RiskState, port: int = 8080) -> None:
    import uvicorn
    app = create_app(db, risk_state)
    config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="warning")
    server = uvicorn.Server(config)
    await server.serve()
