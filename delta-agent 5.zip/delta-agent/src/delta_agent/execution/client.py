"""Exchange client: CCXT for standard ops + Delta REST for bracket orders."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import httpx

from delta_agent.config.settings import AppSettings
from delta_agent.logging_setup import get_logger

log = get_logger(__name__)


class TokenBucket:
    """Simple async token bucket rate limiter."""

    def __init__(self, rate: float, capacity: float) -> None:
        self._rate = rate
        self._capacity = capacity
        self._tokens = capacity
        self._last = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self._last
            self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
            self._last = now
            if self._tokens < 1:
                wait = (1 - self._tokens) / self._rate
                await asyncio.sleep(wait)
                self._tokens = 0
            else:
                self._tokens -= 1


class DeltaExchangeClient:
    """
    Unified exchange client.
    - CCXT (async) for: balance, positions, open orders, cancel, fetch order.
    - Delta REST (httpx) for: bracket order submission (CCXT lacks bracket params).
    """

    def __init__(self, settings: AppSettings) -> None:
        import os
        self._api_key = os.environ.get("DELTA_API_KEY", "")
        self._api_secret = os.environ.get("DELTA_API_SECRET", "")
        self._rest_url = settings.profile.delta.rest_url.rstrip("/")
        self._rate_limiter = TokenBucket(rate=10, capacity=10)  # 10 req/s
        self._http = httpx.AsyncClient(timeout=10.0)
        self._ccxt: Optional[Any] = None

    async def init_ccxt(self) -> None:
        """Lazily init CCXT async client."""
        try:
            import ccxt.async_support as ccxt  # type: ignore
            self._ccxt = ccxt.delta({
                "apiKey": self._api_key,
                "secret": self._api_secret,
            })
        except ImportError:
            log.warning("ccxt_not_installed_using_rest_only")

    async def close(self) -> None:
        await self._http.aclose()
        if self._ccxt:
            await self._ccxt.close()

    # ── CCXT operations ──────────────────────────────────────────────────────

    async def get_balance(self) -> Dict[str, Any]:
        await self._rate_limiter.acquire()
        if self._ccxt:
            return await self._ccxt.fetch_balance()
        return await self._rest_get("/v2/wallet/balances")

    async def get_positions(self) -> List[Dict[str, Any]]:
        await self._rate_limiter.acquire()
        if self._ccxt:
            pos = await self._ccxt.fetch_positions()
            return pos or []
        data = await self._rest_get("/v2/positions/margined")
        return data.get("result", [])

    async def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        await self._rate_limiter.acquire()
        if self._ccxt:
            orders = await self._ccxt.fetch_open_orders(symbol)
            return orders or []
        params = f"?product_id={symbol}" if symbol else ""
        data = await self._rest_get(f"/v2/orders{params}")
        return data.get("result", [])

    async def get_fills(self, lookback_hours: int = 24) -> List[Dict[str, Any]]:
        """
        Batch fetch closed/filled orders since `lookback_hours` ago.
        Capped to avoid unbounded response growth over time.
        """
        import time as _time
        since_ms = int((_time.time() - lookback_hours * 3600) * 1000)
        await self._rate_limiter.acquire()
        if self._ccxt:
            fills = await self._ccxt.fetch_closed_orders(since=since_ms)
            return fills or []
        # Delta REST: pass start_time as unix seconds
        since_s = since_ms // 1000
        data = await self._rest_get(f"/v2/orders/history?start_time={since_s}")
        return data.get("result", [])

    async def close_position(self, symbol: str, side: str, quantity: float) -> Dict[str, Any]:
        """
        Flatten an open position with a market order.
        side is the POSITION side ("buy"/"sell") — close order uses the opposite.
        Cancels any open bracket orders for the symbol first, then submits market close.
        """
        await self._rate_limiter.acquire()
        # Cancel all open orders on this symbol first (removes bracket SL/TP)
        try:
            open_orders = await self.get_open_orders(symbol)
            for o in open_orders:
                ext_id = str(o.get("id", o.get("order_id", "")))
                if ext_id:
                    await self.cancel_order(ext_id, symbol)
        except Exception as exc:
            log.warning("close_position_cancel_brackets_failed", symbol=symbol, error=str(exc))

        close_side = "sell" if side == "buy" else "buy"
        payload = {
            "product_symbol": symbol,
            "side": close_side,
            "order_type": "market_order",
            "size": quantity,
            "reduce_only": True,
        }
        log.info("closing_position_market", symbol=symbol, side=close_side, qty=quantity)
        return await self._rest_post("/v2/orders", payload)

    async def cancel_order(self, external_order_id: str, symbol: str) -> None:
        await self._rate_limiter.acquire()
        if self._ccxt:
            await self._ccxt.cancel_order(external_order_id, symbol)
        else:
            await self._rest_delete(f"/v2/orders/{external_order_id}")

    async def fetch_order(self, external_order_id: str, symbol: str) -> Dict[str, Any]:
        await self._rate_limiter.acquire()
        if self._ccxt:
            return await self._ccxt.fetch_order(external_order_id, symbol)
        data = await self._rest_get(f"/v2/orders/{external_order_id}")
        return data.get("result", {})

    async def get_ticker(self, symbol: str) -> Dict[str, Any]:
        await self._rate_limiter.acquire()
        if self._ccxt:
            return await self._ccxt.fetch_ticker(symbol)
        data = await self._rest_get(f"/v2/tickers/{symbol}")
        return data.get("result", {})

    # ── Delta-native bracket order ────────────────────────────────────────────

    async def place_bracket_order(
        self,
        symbol: str,
        side: str,  # "buy" | "sell"
        quantity: float,
        limit_price: float,
        sl_price: float,
        tp_price: float,
        leverage: int,
        post_only: bool = True,
    ) -> Dict[str, Any]:
        """
        Place a post-only limit order with bracket SL + TP via Delta REST API.
        Uses /v2/orders with bracket fields — not available via CCXT.
        """
        await self._rate_limiter.acquire()
        payload = {
            "product_symbol": symbol,
            "side": side,
            "order_type": "limit_order",
            "size": quantity,
            "limit_price": str(limit_price),
            "post_only": post_only,
            "bracket_stop_loss_price": str(sl_price),
            "bracket_stop_loss_limit_price": str(sl_price),
            "bracket_take_profit_price": str(tp_price),
            "bracket_take_profit_limit_price": str(tp_price),
        }
        log.info("placing_bracket_order", symbol=symbol, side=side, qty=quantity,
                 limit=limit_price, sl=sl_price, tp=tp_price)
        return await self._rest_post("/v2/orders", payload)

    # ── Raw REST helpers ──────────────────────────────────────────────────────

    def _sign(self, method: str, path: str, body: str = "") -> Dict[str, str]:
        ts = str(int(time.time()))
        msg = method + ts + path + body
        sig = hmac.new(key=self._api_secret.encode(), msg=msg.encode(), digestmod=hashlib.sha256).hexdigest()
        return {
            "api-key": self._api_key,
            "timestamp": ts,
            "signature": sig,
            "Content-Type": "application/json",
        }

    async def _rest_get(self, path: str) -> Dict[str, Any]:
        headers = self._sign("GET", path)
        resp = await self._http.get(f"{self._rest_url}{path}", headers=headers)
        resp.raise_for_status()
        return resp.json()

    async def _rest_post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        body = json.dumps(payload)
        headers = self._sign("POST", path, body)
        resp = await self._http.post(f"{self._rest_url}{path}", content=body, headers=headers)
        resp.raise_for_status()
        return resp.json()

    async def _rest_delete(self, path: str) -> Dict[str, Any]:
        headers = self._sign("DELETE", path)
        resp = await self._http.delete(f"{self._rest_url}{path}", headers=headers)
        resp.raise_for_status()
        return resp.json()
