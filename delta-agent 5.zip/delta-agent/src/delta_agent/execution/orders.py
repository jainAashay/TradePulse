"""Order entity and status constants."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


class OrderStatus:
    PENDING = "PENDING"
    OPEN = "OPEN"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    CLOSED = "CLOSED"


@dataclass
class Order:
    id: int
    symbol: str
    side: str
    quantity: float
    leverage: int
    entry_price: float
    sl_price: float
    tp_prices: List[float]
    status: str = OrderStatus.PENDING
    external_order_id: Optional[str] = None
    pnl_usd: Optional[float] = None
    created_at: str = ""
    filled_at: Optional[str] = None
    closed_at: Optional[str] = None
