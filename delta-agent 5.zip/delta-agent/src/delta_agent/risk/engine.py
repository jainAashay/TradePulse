"""Deterministic risk validation — stateless validator over RiskState + TradeDecision."""

from __future__ import annotations

from dataclasses import dataclass

from delta_agent.analyzer.decision import TradeDecision
from delta_agent.config.settings import RiskConfig
from delta_agent.logging_setup import get_logger
from delta_agent.risk.state import RiskState

log = get_logger(__name__)


@dataclass
class RiskVerdict:
    approved: bool
    reason: str


class RiskEngine:
    """
    Stateless hard-rule validator.
    All rules must pass for APPROVED. First failure returns REJECTED with reason.
    """

    def __init__(self, config: RiskConfig) -> None:
        self._cfg = config

    def validate(self, decision: TradeDecision, state: RiskState, trading_enabled: bool) -> RiskVerdict:
        cfg = self._cfg

        log.debug("risk_validating", action=decision.action, confidence=decision.confidence,
                  leverage=decision.leverage, daily_orders=state.daily_orders,
                  daily_loss=state.daily_loss_usd, open_positions=state.open_positions,
                  consecutive_losses=state.consecutive_losses,
                  circuit_breaker=state.circuit_breaker_active)

        if not trading_enabled:
            log.info("risk_rejected", reason="trading_disabled_via_telegram")
            return RiskVerdict(False, "trading_disabled_via_telegram")

        if state.circuit_breaker_active:
            log.info("risk_rejected", reason="circuit_breaker_active")
            return RiskVerdict(False, "circuit_breaker_active")

        if decision.action == "HOLD":
            log.debug("risk_rejected", reason="action_is_hold")
            return RiskVerdict(False, "action_is_hold")

        if decision.confidence < cfg.min_confidence:
            reason = f"confidence {decision.confidence:.2f} < min {cfg.min_confidence}"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        if decision.leverage > cfg.max_leverage:
            reason = f"leverage {decision.leverage}x > max {cfg.max_leverage}x"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        if state.open_positions >= cfg.max_positions:
            reason = f"open_positions {state.open_positions} >= max {cfg.max_positions}"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        if state.daily_orders >= cfg.max_orders_per_day:
            reason = f"daily_orders {state.daily_orders} >= max {cfg.max_orders_per_day}"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        if state.daily_loss_usd >= cfg.max_daily_loss_usd:
            reason = f"daily_loss_usd {state.daily_loss_usd:.2f} >= max {cfg.max_daily_loss_usd}"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        if state.consecutive_losses >= cfg.max_consecutive_losses:
            reason = f"consecutive_losses {state.consecutive_losses} >= max {cfg.max_consecutive_losses}"
            log.info("risk_rejected", reason=reason)
            return RiskVerdict(False, reason)

        log.info("risk_approved", action=decision.action, confidence=decision.confidence,
                 leverage=decision.leverage, daily_orders=state.daily_orders,
                 open_positions=state.open_positions)
        return RiskVerdict(True, "all_rules_passed")
