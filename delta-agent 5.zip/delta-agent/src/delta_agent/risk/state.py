"""RiskState: daily counters persisted in SQLite, recomputed from orders on startup."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from delta_agent.persistence.db import Database


def _today_utc() -> str:
    return datetime.now(timezone.utc).date().isoformat()


@dataclass
class RiskState:
    date: str = field(default_factory=_today_utc)
    daily_orders: int = 0
    daily_loss_usd: float = 0.0
    consecutive_losses: int = 0
    circuit_breaker_active: bool = False
    open_positions: int = 0  # in-memory only, reconciled on startup

    @classmethod
    def load(cls, db: "Database") -> "RiskState":
        """Load today's row from SQLite, recompute counters from actual orders."""
        row = db.load_risk_state()
        today = _today_utc()

        if row["date"] != today:
            # New day — reset
            state = cls(date=today)
            db.save_risk_state(state.to_dict())
            return state

        # Recompute daily_orders and daily_loss_usd from actual order rows
        today_orders = db.get_today_orders()
        daily_orders = len([o for o in today_orders if o["status"] not in ("CANCELLED",)])
        daily_loss_usd = sum(
            abs(o["pnl_usd"]) for o in today_orders
            if o["pnl_usd"] is not None and o["pnl_usd"] < 0
        )

        return cls(
            date=today,
            daily_orders=daily_orders,
            daily_loss_usd=daily_loss_usd,
            consecutive_losses=row["consecutive_losses"],
            circuit_breaker_active=bool(row["circuit_breaker_active"]),
        )

    def to_dict(self) -> dict:
        return {
            "date": self.date,
            "daily_orders": self.daily_orders,
            "daily_loss_usd": self.daily_loss_usd,
            "consecutive_losses": self.consecutive_losses,
            "circuit_breaker_active": self.circuit_breaker_active,
        }

    def persist(self, db: "Database") -> None:
        db.save_risk_state(self.to_dict())

    def record_order_placed(self, db: "Database") -> None:
        self.daily_orders += 1
        self.persist(db)

    def record_trade_closed(self, pnl_usd: float, db: "Database") -> None:
        if pnl_usd < 0:
            self.daily_loss_usd += abs(pnl_usd)
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0
        self.persist(db)

    def trip_circuit_breaker(self, db: "Database") -> None:
        self.circuit_breaker_active = True
        self.persist(db)

    def reset_circuit_breaker(self, db: "Database") -> None:
        self.circuit_breaker_active = False
        self.consecutive_losses = 0
        self.persist(db)

    def maybe_reset_for_new_day(self, db: "Database") -> bool:
        """Call periodically; returns True if reset happened."""
        today = _today_utc()
        if self.date != today:
            self.date = today
            self.daily_orders = 0
            self.daily_loss_usd = 0.0
            self.consecutive_losses = 0
            self.circuit_breaker_active = False
            self.persist(db)
            return True
        return False
