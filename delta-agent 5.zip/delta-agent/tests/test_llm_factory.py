from delta_agent.config.settings import LLMConfig, MemoryConfig
from delta_agent.llm.factory import LLMFactory
from delta_agent.llm.protocols import ChatMessage, LLMRuntime
from delta_agent.memory.protocols import LearningRecord
from delta_agent.memory.stub import StubVectorMemoryStore


class FakeLLM:
    def complete(
        self,
        messages: list[ChatMessage],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> str:
        _ = temperature, max_tokens
        return "Avoid chasing RSI extremes without volume confirmation."

    def complete_json(
        self,
        messages: list[ChatMessage],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> dict:
        _ = messages, temperature, max_tokens
        return {"action": "HOLD"}


def test_runtime_rag_formatting() -> None:
    memory = StubVectorMemoryStore()
    memory.add_learning(
        LearningRecord(lesson_id="1", text="Wait for EMA cross confirmation.", symbol="BTCUSD")
    )
    runtime = LLMRuntime(client=FakeLLM(), memory=memory, rag_top_k=3, max_lesson_chars=200)
    records = runtime.fetch_learnings("BTCUSD RSI")
    prompt_block = runtime.format_learnings_for_prompt(records)
    assert "EMA cross" in prompt_block
    assert "BTCUSD" in prompt_block


def test_learning_refiner_uses_llm() -> None:
    refiner = LLMFactory.create_learning_refiner(FakeLLM(), max_chars=120)
    out = refiner.refine("Lost money on FOMO entry at RSI 78.")
    assert "RSI" in out or "volume" in out or len(out) > 10
