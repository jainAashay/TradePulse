from pathlib import Path

import pytest

from delta_agent.config.settings import load_settings


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "settings.yaml"
WATCHLIST = ROOT / "config" / "watchlist.yaml"


def test_load_settings_india_testnet(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DELTA_AGENT_ENV", raising=False)
    settings = load_settings(config_path=CONFIG, watchlist_path=WATCHLIST)
    assert settings.active_profile == "india_testnet"
    assert settings.profile.delta.rest_url.startswith("https://")
    assert len(settings.watchlist.watchlist) >= 1
    assert settings.risk.max_orders_per_day == 20
    assert settings.llm.model.startswith("gemini/")


def test_env_profile_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DELTA_AGENT_ENV", "india_mainnet")
    settings = load_settings(config_path=CONFIG, watchlist_path=WATCHLIST)
    assert settings.active_profile == "india_mainnet"
    assert "india.delta.exchange" in settings.profile.delta.rest_url
