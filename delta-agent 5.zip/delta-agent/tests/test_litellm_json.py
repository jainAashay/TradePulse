from delta_agent.llm.litellm_client import _parse_json_object


def test_parse_json_with_fence() -> None:
    raw = 'Here you go:\n```json\n{"action": "LONG", "confidence": 0.8}\n```'
    assert _parse_json_object(raw)["action"] == "LONG"
