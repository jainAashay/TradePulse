# delta-agent — Agentic Trading Bot for Delta Exchange

A 24/7 autonomous trading agent for Delta Exchange perpetual futures. Uses a unified `MarketDataStore` to compute technical indicators on every closed candle, builds a factual price-action narrative, sends a hybrid narrative + CSV prompt to an LLM (Gemini via LiteLLM) for chain-of-thought decisions, enforces hard risk rules, executes bracket orders, monitors active positions per-candle for early exit, and continuously learns from closed trades via ChromaDB vector memory.

---

## System Diagram

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║                          DELTA AGENT — 24/7 RUNTIME                            ║
╚══════════════════════════════════════════════════════════════════════════════════╝

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                        STAGE 1 — MARKET DATA & SCREENER                     │
  │                                                                             │
  │   Delta Exchange WebSocket (wss://)                                         │
  │   ┌─────────────────────────────┐                                           │
  │   │  candlestick_1m / _5m feed  │  auto-reconnect (exp backoff 1s→60s)     │
  │   └────────────┬────────────────┘                                           │
  │                │ closed bar only                                             │
  │                ▼                                                             │
  │   ┌────────────────────┐   push()   ┌────────────────────────────────────┐ │
  │   │     DeltaFeed      │ ─────────▶ │      MarketDataStore               │ │
  │   │   (feed.py)        │            │  Rolling DataFrame per             │ │
  │   └────────────────────┘            │  (symbol, timeframe)               │ │
  │                                     │  OHLCV + all indicator columns     │ │
  │                                     │  computed on every push()          │ │
  │                                     └─────────────┬──────────────────────┘ │
  │                                                   │ get_latest_signals()    │
  │                                                   │ get_df()               │
  │                                                   ▼                        │
  │                                    open position for symbol?               │
  │                                   ┌───────┴──────┐                         │
  │                                  YES             NO                         │
  │                                   │               │                         │
  │                                   │               ▼                         │
  │                                   │   ┌─────────────────────┐              │
  │                                   │   │    TriggerGate      │              │
  │                                   │   │ Python rule registry│              │
  │                                   │   │ YAML thresholds     │              │
  │                                   │   │ cooldown + dedup    │              │
  │                                   │   └──────────┬──────────┘              │
  │                     push directly │     TriggerEvent                       │
  │                     every candle  │              │                          │
  │                     (watch_mode)  │              │                          │
  └───────────────────────────────────┴──────────────┼──────────────────────────┘
                                                      │
  ┌───────────────────────────────────────────────────▼──────────────────────────┐
  │                   STAGE 2 — AGENT LOOP (two-mode state machine)               │
  │                                                                              │
  │         SCAN MODE                         WATCH MODE                        │
  │   (no open position)                (open position exists)                  │
  │   rule-gated entry                  every closed candle                     │
  │         │                                     │                             │
  └─────────┼─────────────────────────────────────┼──────────────────────────────┘
            │                                     │
  ┌─────────▼─────────────────────────────────────▼──────────────────────────────┐
  │                    STAGE 2b — ANALYZER (LLM BRAIN) — both modes              │
  │                                                                              │
  │  MarketDataStore.get_df()  ──▶  PriceActionNarrator                         │
  │                                  Factual deterministic observations          │
  │                                  (trend direction, EMA stack, RSI zone,     │
  │                                   MACD cross, BB squeeze, ATR%, volume)     │
  │                                         │                                   │
  │                                         ▼                                   │
  │              ┌──────────────────────────────────────────────────────┐       │
  │              │              Hybrid LLM Prompt                       │       │
  │              │  [1] Prior Lessons (ChromaDB RAG — injected FIRST)  │       │
  │              │  [2] ## Market Narrative (Python-computed facts)     │       │
  │              │  [3] ## Supporting Data (CSV — source of truth)      │       │
  │              │      last 15 candles: close, volume, ema_9, rsi_14, │       │
  │              │      macd_hist, bb_pct_b, atr_14                    │       │
  │              │  [4] ## Current Market Structure                     │       │
  │              │      ema_21/50/200, macd_line/signal, BB levels,    │       │
  │              │      vwap, stoch_k/d, all cross events              │       │
  │              │  [5] ## Recent News Headlines (age-labeled, no       │       │
  │              │         pre-computed sentiment — LLM judges)         │       │
  │              │  [6] Risk Parameters                                 │       │
  │              │  WATCH MODE adds: entry price, current price,       │       │
  │              │    unrealised PnL%, time held, SL/TP levels         │       │
  │              └────────────────────┬─────────────────────────────────┘       │
  │                                   │                                          │
  │                    ┌──────────────▼──────────┐                              │
  │                    │  LLM (Gemini/LiteLLM)   │                              │
  │                    │  CoT → JSON decision     │                              │
  │                    └──────────────┬──────────┘                              │
  │                                   │                                          │
  │   SCAN returns:   LONG / SHORT / HOLD                                       │
  │   WATCH returns:  HOLD / EXIT                                               │
  └────────────────────────────────────────────────────────────────────────────┘
        │                                    │
        │ EXIT                               │ LONG / SHORT
        ▼                                    ▼
  cancel bracket             ┌──────────────────────────────────────────────────┐
  market close               │              STAGE 3 — RISK ENGINE               │
  → reflection               │  ✓ confidence · leverage · positions · daily     │
                             │    orders · daily loss · consecutive losses       │
                             │    circuit breaker · trading_enabled              │
                             └────────────────────┬─────────────────────────────┘
                                                  │ APPROVED
                                                  ▼
                             ┌──────────────────────────────────────────────────┐
                             │              STAGE 4 — EXECUTION                  │
                             │  bracket order: entry + SL + TP                  │
                             │  quantity from watchlist.yaml                     │
                             │  persist → SQLite · timeout watcher               │
                             │  Telegram alert                                   │
                             └────────────────────┬─────────────────────────────┘
                                                  │ trade closes
                                                  ▼
                             ┌──────────────────────────────────────────────────┐
                             │           STAGE 5 — REFLECTION & LEARNING         │
                             │  batch fills poll (every 30s, capped N hours)    │
                             │  intersect unreflected local orders               │
                             │  LLM post-mortem → compact lesson → ChromaDB     │
                             │  mark_reflected() after ChromaDB write            │
                             │  update risk counters                             │
                             └──────────────────────────────────────────────────┘
                                      │ lessons loop back into Stage 2b RAG ▲
                                      └─────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════════
  BACKGROUND SERVICES (always running in parallel)
═══════════════════════════════════════════════════════════════════════════════════

  ┌─────────────────────┐   ┌──────────────────────┐   ┌──────────────────────┐
  │   NewsPoller        │   │  TelegramBot          │   │  Health Server       │
  │                     │   │                       │   │                      │
  │  CryptoNews API     │   │  /pause  → DB flag    │   │  GET /health         │
  │  poll every 60s*    │   │  /resume → DB flag    │   │  POST /reset-cb      │
  │  TTL cache 120s*    │   │  /status → live state │   │  port :8080          │
  │  age label per item │   │  /reset  → clear CB   │   │                      │
  │  no pre-labelled    │   │  /disable_trading     │   │                      │
  │  sentiment (LLM     │   │  (Telegram only)      │   │                      │
  │  judges itself)     │   │                       │   │                      │
  └─────────────────────┘   └──────────────────────┘   └──────────────────────┘

  * configurable via news.poll_interval_seconds / news.cache_ttl_seconds

═══════════════════════════════════════════════════════════════════════════════════
  PERSISTENCE (SQLite — survives restarts)
═══════════════════════════════════════════════════════════════════════════════════

  analysis_cycles   IN_FLIGHT cycles → marked CRASHED on restart (no double-entry)
  orders            PENDING→OPEN→CLOSED + PnL + reflected flag; reconciled on startup
  risk_state        daily counters recomputed from orders table on startup
  agent_config      trading_enabled flag (Telegram-controlled, persists across restarts)
```

---

## Two-Mode Agent Loop

The core design of delta-agent: the LLM has **full visibility into active trades** and can act on them every closed candle.

| Mode | When active | Trigger | LLM decision |
|---|---|---|---|
| **Scan** | No open position for symbol | Rule fires (RSI, EMA cross, momentum, etc.) + cooldown elapsed | `LONG` / `SHORT` / `HOLD` |
| **Watch** | Open position exists for symbol | Every closed candle — no rule gate, no cooldown | `HOLD` / `EXIT` |

Watch mode injects into the prompt: entry price, current price, unrealised PnL%, time held (minutes), stop-loss and take-profit levels, plus the full indicator CSV and narrative.

If the LLM returns `EXIT`, the agent cancels the bracket order and closes the position at market immediately, then triggers reflection.

---

## Hybrid LLM Prompt Design

Each LLM call receives three data sections:

| Section | Source | Role |
|---|---|---|
| **Market Narrative** | `PriceActionNarrator` (Python) | Deterministic, factual observations (EMA stack, RSI zone, MACD cross, BB squeeze, ATR, volume ratio) — computed, not hallucinated |
| **Supporting Data CSV** | `MarketDataStore` DataFrame tail | Last 15 candles of `close, volume, ema_9, rsi_14, macd_hist, bb_pct_b, atr_14` — explicitly marked as **source of truth** |
| **Current Market Structure** | Latest row from `MarketDataStore` | Slow-moving indicators + all cross events: `ema_21/50/200`, MACD line/signal, BB levels, VWAP, stoch, all boolean cross flags |

The prompt instructs the LLM: *"If the narrative conflicts with what you observe in the CSV data, trust the CSV."*

---

## Package Structure

```
src/delta_agent/
  config/           settings.py (RiskConfig, ScreenerConfig, NewsConfig, WatchlistInstrument)
  screener/         feed.py, market_data_store.py, rules.py, trigger.py
                    (bar_store.py + indicators.py kept for reference, not used at runtime)
  analyzer/         context.py (Analyzer + OpenPosition), narrator.py (PriceActionNarrator),
                    prompts.py (scan + watch hybrid prompts), decision.py (TradeDecision)
  risk/             engine.py (stateless validator), state.py (SQLite-persisted counters)
  agent/            loop.py (scan mode + watch mode state machine)
  execution/        client.py (CCXT + Delta REST + close_position), manager.py (enter/exit),
                    orders.py (OrderStatus constants)
  reflection/       detector.py (batch fills + intersection), pipeline.py (post-mortem → ChromaDB)
  memory/           protocols.py, chroma_store.py (ChromaDB), stub.py (no-op fallback)
  llm/              protocols.py, litellm_client.py, factory.py, langchain_bridge.py
  news/             poller.py (CryptoNews API + configurable TTL NewsCache)
  health/           server.py (FastAPI /health), alerter.py (Telegram), telegram_bot.py
  persistence/      db.py (SQLite: 4 tables + all DAOs)
  logging_setup.py  structlog JSON logs
  __main__.py       boots all subsystems, runs asyncio.gather
```

---

## Indicators

All computed inside `MarketDataStore.push()` on every closed bar and stored as columns in the per-(symbol, timeframe) DataFrame.

**Scalar values (TABLE_COLUMNS — in the CSV sent to LLM):**

| Column | Description |
|---|---|
| `close` | Close price |
| `volume` | Bar volume |
| `ema_9` | EMA 9 |
| `rsi_14` | RSI 14 |
| `macd_hist` | MACD histogram |
| `bb_pct_b` | Bollinger %B (0=lower band, 1=upper band) |
| `atr_14` | Average True Range 14 |

**STRUCTURE_COLUMNS (snapshot block in LLM prompt):**

`ema_21`, `ema_50`, `ema_200`, `macd_line`, `macd_signal`, `bb_upper`, `bb_lower`, `bb_mid`, `bb_bandwidth`, `vwap`, `stoch_k`, `stoch_d`

**Cross / event signals (boolean as float 1.0 / 0.0):**

| Signal key | Meaning |
|---|---|
| `ema_cross_up` | EMA 9 crossed above EMA 21 on this candle |
| `ema_cross_down` | EMA 9 crossed below EMA 21 |
| `ema_trend_bullish` | EMA 9 currently above EMA 21 |
| `ema_longterm_bullish` | EMA 50 currently above EMA 200 |
| `macd_cross_up` | MACD line crossed above signal line |
| `macd_cross_down` | MACD line crossed below signal line |
| `macd_above_zero` | MACD line is positive |
| `stoch_cross_up` | Stoch %K crossed above %D |
| `stoch_cross_down` | Stoch %K crossed below %D |

---

## Screener Rules

Registered with `@rule("name")` in `screener/rules.py`. Thresholds from `watchlist.yaml` per symbol. Only apply in **scan mode**.

| Rule | Signal used | Key thresholds |
|---|---|---|
| `rsi_oversold` | `rsi_14` | `threshold` (default 30) |
| `rsi_overbought` | `rsi_14` | `threshold` (default 70) |
| `ema_cross_up` | `ema_cross_up` | — |
| `ema_cross_down` | `ema_cross_down` | — |
| `candle_momentum` | `close` | `candles`, `min_pct`, `direction` |
| `volume_spike` | `volume` | `lookback`, `multiplier` |
| `price_near_ema` | `close`, `ema_N` | `ema_length`, `within_pct` |

---

## Risk Rules (all must pass — scan mode only)

| Rule | Config key | Default |
|---|---|---|
| Confidence ≥ threshold | `risk.min_confidence` | 0.65 |
| Leverage ≤ cap | `risk.max_leverage` | 20x |
| Open positions < max | `risk.max_positions` | 3 |
| Daily orders < max | `risk.max_orders_per_day` | 20 |
| Daily loss < max | `risk.max_daily_loss_usd` | $100 |
| Consecutive losses < max | `risk.max_consecutive_losses` | 3 |
| Circuit breaker OFF | auto-trips on consecutive loss limit | — |
| `trading_enabled` | Telegram `/pause` | true |

---

## Key Design Decisions

| Topic | Decision |
|---|---|
| Market data | `MarketDataStore` — single unified DataFrame per (symbol, timeframe); OHLCV + all indicator columns per row; free historical indicator access via `df.tail(n)` |
| Indicator history | Stored in DataFrame rows, not recomputed per call; enables CSV export and divergence detection |
| Prompt design | Hybrid: Python-computed factual narrative + raw CSV (source of truth) + structure snapshot. LLM validates narrative against data, not the reverse |
| Exchange API | CCXT async for balance/positions/orders/cancel; Delta REST `/v2/orders` for bracket orders and market close |
| WebSocket | Native `websockets` lib; auto-reconnect with exponential backoff (1s→60s cap) |
| Trigger rules | Python `@rule()` registry; thresholds per symbol in `watchlist.yaml`; OR semantics |
| Trigger dedup | Latest-wins map per symbol — stale pending triggers replaced, no queue backlog |
| Two-mode loop | Scan = rule-gated entry; Watch = every candle while position open |
| Early exit | Cancel bracket + `reduce_only` market order; feeds reflection pipeline |
| LLM provider | Gemini via LiteLLM; swap model in `settings.yaml` with no code changes |
| Vector memory | ChromaDB + `all-MiniLM-L6-v2` local embeddings; lessons ≤400 chars; injected first in system prompt |
| Position sizing | Fixed `quantity` + `leverage` from `watchlist.yaml` per symbol |
| Risk engine | Stateless; all counters recomputed from SQLite on startup |
| Reflection dedup | `reflected` flag; `mark_reflected()` only after ChromaDB write succeeds; `replay_unreflected()` on startup |
| Fills API | Batch call capped at `fills_lookback_hours` (default 24h) |
| Restart resilience | `IN_FLIGHT` cycles crashed on boot; order reconciliation; `trading_enabled` persisted in SQLite |
| Kill switch | Telegram `/pause /resume /status /reset` — no redeploy needed |
| News | CryptoNews API; age label per headline; no pre-labelled sentiment (LLM judges); hard char cap |
| Logging | structlog JSON; `DEBUG` level for per-bar indicator values, rule evaluations, prompt details; `INFO` for decisions, orders, reflections |

---

## Configuration

**`config/settings.yaml`** — all tunable parameters:

| Key | Default | Description |
|---|---|---|
| `active_profile` | `india_testnet` | Switch between testnet and mainnet |
| `screener.bar_history_size` | 200 | Rolling OHLCV window per symbol/timeframe |
| `screener.trigger_cooldown_minutes` | 5 | Min gap between scan-mode triggers per symbol |
| `screener.price_action_candles` | 15 | Candle rows in the CSV sent to LLM |
| `screener.default_rules.*` | RSI 30/70 + EMA cross | Fallback if symbol has no rules in watchlist |
| `risk.*` | see table above | All risk limits |
| `llm.model` | `gemini/gemini-2.0-flash` | Any LiteLLM-supported model |
| `memory.rag_top_k` | 5 | Lessons injected per analysis cycle |
| `memory.max_lesson_chars` | 400 | Lesson size cap before ChromaDB storage |
| `execution.unfilled_limit_timeout_seconds` | 120 | Auto-cancel timeout for unfilled orders |
| `execution.fills_lookback_hours` | 24 | Exchange fill fetch window |
| `news.poll_interval_seconds` | 60 | How often to fetch news |
| `news.cache_ttl_seconds` | 120 | How long cached news stays fresh |
| `news.max_news_chars` | 1000 | Hard cap on news text injected into LLM prompt |

**`config/watchlist.yaml`** — per-symbol config:

```yaml
watchlist:
  - symbol: BTCUSD
    quantity: 1
    leverage: 10
    rules:
      - name: rsi_oversold
        thresholds:
          threshold: 30
      - name: ema_cross_up
        thresholds: {}
      - name: candle_momentum
        thresholds:
          candles: 4
          min_pct: 0.1
          direction: up
```

---

## SQLite Tables

| Table | Purpose |
|---|---|
| `analysis_cycles` | Per-trigger cycle state (`IN_FLIGHT`→`COMPLETED`/`REJECTED`/`CRASHED`) for crash recovery |
| `orders` | Full order lifecycle (PENDING→OPEN→CLOSED), PnL, `reflected` flag for dedup |
| `risk_state` | Daily counters: orders placed, loss USD, consecutive losses, circuit breaker flag |
| `agent_config` | Runtime flags: `trading_enabled` (toggled via Telegram) |

---

## Telegram Commands

| Command | Effect |
|---|---|
| `/pause` | Stops all new trades (sets `trading_enabled=false` in SQLite) |
| `/resume` | Re-enables trading |
| `/status` | Shows enabled flag, open positions, daily PnL, circuit breaker state |
| `/reset` | Manually resets circuit breaker |

---

## Environment Variables

```
DELTA_AGENT_ENV=india_testnet      # or india_mainnet
DELTA_API_KEY=
DELTA_API_SECRET=
GEMINI_API_KEY=
TELEGRAM_BOT_TOKEN=               # optional
TELEGRAM_CHAT_ID=                 # optional
CRYPTONEWS_API_KEY=               # optional — news disabled silently if missing
```

---

## Log Reference

All logs are structured JSON via structlog. Key events:

| Log event | Level | Where | Meaning |
|---|---|---|---|
| `bar_closed` | DEBUG | feed.py | Closed bar emitted for symbol/timeframe |
| `mds_bar_pushed` | DEBUG | market_data_store | Bar + indicators stored in DataFrame |
| `rule_evaluated` | DEBUG | trigger.py | Per-rule pass/fail result |
| `trigger_cooldown_active` | DEBUG | trigger.py | Cooldown still running, remaining seconds |
| `trigger_fired` | INFO | trigger.py | Rule matched, TriggerEvent enqueued |
| `on_bar_watch_mode` | INFO | \_\_main\_\_ | Open position found — bypassing gate |
| `scan_cycle_start` | INFO | loop.py | Processing new scan trigger |
| `analyzer_calling_llm` | INFO | context.py | LLM call about to be made |
| `analyzer_decision` | INFO | context.py | LLM returned action + confidence |
| `risk_approved` / `risk_rejected` | INFO | engine.py | Risk verdict with reason |
| `order_submitted` | INFO | manager.py | Bracket order sent to exchange |
| `watch_decision` | INFO | loop.py | Watch-mode HOLD or EXIT |
| `early_exit_initiated` | INFO | manager.py | Cancelling bracket + market close |
| `detector_poll` | DEBUG | detector.py | Fill poll cycle |
| `reflection_processing` | INFO | pipeline.py | Post-mortem started |
| `reflection_complete` | INFO | pipeline.py | Lesson stored in ChromaDB |

---

## Milestone Status

| Milestone | What | Status |
|---|---|---|
| M1 | Config, logging, LLM factory, memory interfaces | ✅ Done |
| M2 | WebSocket feed, BarStore, indicators, trigger gate | ✅ Done |
| M3 | Agent loop, analyzer, risk engine, SQLite persistence | ✅ Done |
| M4 | Exchange client (CCXT + Delta REST bracket orders), order lifecycle, startup reconciliation | ✅ Done |
| M5 | ChromaDB vector store, reflection pipeline, RAG injection | ✅ Done |
| M6 | News poller, Telegram alerts + bot, health endpoint, Docker + supervisord | ✅ Done |
| M7 | Two-mode agent loop: scan (entry) + watch (per-candle position monitoring + early EXIT) | ✅ Done |
| M8 | MarketDataStore (unified DataFrame), PriceActionNarrator, hybrid CSV+narrative LLM prompt, debug log layer | ✅ Done |
