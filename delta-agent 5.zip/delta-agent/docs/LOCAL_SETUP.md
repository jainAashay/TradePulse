# Local Setup Guide

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Python | 3.11+ | 3.12 recommended |
| pip | latest | `pip install --upgrade pip` |
| Git | any | |
| Docker + Docker Compose | 24+ | Only for Docker run — not needed for bare Python |
| Delta Exchange account | — | Testnet: [testnet.delta.exchange](https://testnet.delta.exchange) |
| Gemini API key | — | [aistudio.google.com](https://aistudio.google.com) — free tier sufficient |
| Telegram bot | optional | For alerts + kill switch |
| CryptoNews API key | optional | [cryptonews-api.com](https://cryptonews-api.com) — news disabled if missing |

---

## 1. Clone and install

```bash
git clone <repo-url>
cd delta-agent

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install --upgrade pip
pip install -r requirements.txt
pip install -e .                   # installs delta_agent as editable package
```

---

## 2. Environment variables

Copy the example and fill in your secrets:

```bash
cp .env.example .env
```

Edit `.env`:

```env
# Required
DELTA_API_KEY=your_delta_api_key
DELTA_API_SECRET=your_delta_api_secret
GEMINI_API_KEY=your_gemini_api_key

# Profile — testnet (safe for testing) or mainnet (real money)
DELTA_AGENT_ENV=india_testnet

# Optional — Telegram alerts + kill switch
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id

# Optional — news sentiment
CRYPTONEWS_API_KEY=your_cryptonews_key
```

### Getting a Telegram bot

1. Message `@BotFather` on Telegram → `/newbot`
2. Copy the token into `TELEGRAM_BOT_TOKEN`
3. Start a chat with your bot, then run:
   ```bash
   curl "https://api.telegram.org/bot<TOKEN>/getUpdates"
   ```
   Find `"chat": {"id": <number>}` → that is your `TELEGRAM_CHAT_ID`

---

## 3. Configuration

All tunable parameters live in `config/settings.yaml`. You do not need to edit it to get started — defaults are safe for testnet.

Key things you may want to change before first run:

```yaml
active_profile: india_testnet    # change to india_mainnet for real trading

risk:
  max_daily_loss_usd: 100        # stop trading if daily loss exceeds this
  max_orders_per_day: 20
  max_positions: 3

screener:
  trigger_cooldown_minutes: 5    # min gap between signals per symbol

news:
  poll_interval_seconds: 60      # how aggressively to fetch news
  cache_ttl_seconds: 120
```

Per-symbol settings (quantity, leverage, which rules to use) are in `config/watchlist.yaml`:

```yaml
watchlist:
  - symbol: BTCUSD
    quantity: 1          # number of contracts per order
    leverage: 10
    indicators:
      - name: ema
        length: 9
      - name: ema
        length: 21
      - name: rsi
        length: 14
    rules:
      - name: rsi_oversold
        thresholds:
          threshold: 30
      - name: ema_cross_up
        thresholds: {}
```

---

## 4. Run locally (Python)

```bash
source .venv/bin/activate
python -m delta_agent
```

The agent will:
1. Connect to Delta Exchange WebSocket
2. Start consuming candlestick bars
3. Log structured JSON to stdout
4. Expose health endpoint at `http://localhost:8080/health`

To verify it is running:
```bash
curl http://localhost:8080/health
```

Expected response:
```json
{
  "status": "ok",
  "trading_enabled": true,
  "circuit_breaker": false,
  "open_positions": 0,
  "daily_orders": 0,
  "daily_loss_usd": 0.0
}
```

---

## 5. Run with Docker

```bash
cp .env.example .env    # fill in secrets if not done yet
docker-compose up --build
```

Data persists across redeploys via the `./data` bind mount:
- `./data/agent_state.db` — SQLite (orders, cycles, risk state)
- `./data/chroma/` — ChromaDB vector store (trade lessons)

To stop:
```bash
docker-compose down
```

To tail logs:
```bash
docker-compose logs -f delta-agent
```

To reset the circuit breaker without restarting:
```bash
curl -X POST http://localhost:8080/health/reset-circuit-breaker
```

---

## 6. Switching between testnet and mainnet

In `.env`:
```env
DELTA_AGENT_ENV=india_mainnet
```

Or per-run without editing `.env`:
```bash
DELTA_AGENT_ENV=india_mainnet python -m delta_agent
```

**Testnet endpoints** (configured in `settings.yaml` under `profiles.india_testnet`):
- REST: `https://cdn-ind.testnet.deltaex.org`
- WebSocket: `wss://socket-ind.testnet.deltaex.org`

**Mainnet endpoints** (under `profiles.india_mainnet`):
- REST: `https://api.india.delta.exchange`
- WebSocket: `wss://socket.india.delta.exchange`

---

## 7. Telegram kill switch

Once the bot is running and `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` are set:

| Command | Effect |
|---|---|
| `/pause` | Stops all new trades immediately (no restart needed) |
| `/resume` | Re-enables trading |
| `/status` | Shows live risk state: positions, daily PnL, circuit breaker |
| `/reset` | Manually clears the circuit breaker |

---

## 8. Adding a new trading symbol

Edit `config/watchlist.yaml`:

```yaml
  - symbol: SOLUSD
    quantity: 5
    leverage: 10
    indicators:
      - name: ema
        length: 9
      - name: ema
        length: 21
      - name: rsi
        length: 14
    rules:
      - name: rsi_oversold
        thresholds:
          threshold: 28
      - name: volume_spike
        thresholds:
          lookback: 20
          multiplier: 2.5
```

Restart the agent — no code changes needed.

---

## 9. Adding a custom screener rule

Open `src/delta_agent/screener/rules.py` and add:

```python
@rule("my_rule")
def my_rule(df: pd.DataFrame, signals: dict, thresholds: dict) -> bool:
    # df has columns: open, high, low, close, volume, timestamp
    # signals has computed indicator values: rsi_14, ema_9, ema_21, etc.
    # thresholds come from watchlist.yaml per symbol
    my_threshold = float(thresholds.get("my_param", 1.0))
    return signals.get("rsi_14", 50) < my_threshold
```

Then reference it in `watchlist.yaml`:

```yaml
rules:
  - name: my_rule
    thresholds:
      my_param: 25.0
```

No restart of other subsystems needed — rules are loaded at boot.

---

## 10. Changing the LLM

In `config/settings.yaml`:

```yaml
llm:
  model: openai/gpt-4o           # any LiteLLM-supported model string
  api_key_env: OPENAI_API_KEY    # env var name for the key
```

Add the corresponding key to `.env`:
```env
OPENAI_API_KEY=sk-...
```

Supported providers: Gemini, OpenAI, Anthropic, Mistral, Groq, Azure, Ollama (local) — see [LiteLLM docs](https://docs.litellm.ai/docs/providers) for the full list.

---

## 11. Data directory layout

```
data/
├── agent_state.db        SQLite — all persistent state
└── chroma/               ChromaDB — trade learnings vector store
    ├── chroma.sqlite3
    └── <collection-uuid>/
```

Both are created automatically on first run. Back up `data/` before any destructive operations.

To wipe all state and start fresh:
```bash
rm -rf data/
```

---

## 12. Troubleshooting

**Agent connects but no triggers fire**
- Check that `config/watchlist.yaml` symbols match Delta Exchange symbol names exactly (e.g. `BTCUSD` not `BTC/USD`)
- Lower `screener.trigger_cooldown_minutes` temporarily to see if rules are firing
- Add `log_level: DEBUG` in `settings.yaml` to see per-bar indicator values

**`ModuleNotFoundError: No module named 'delta_agent'`**
```bash
pip install -e .
# or
PYTHONPATH=src python -m delta_agent
```

**`LLM API key missing`**
- Ensure `.env` is in the project root and `load_dotenv()` can find it
- Check `llm.api_key_env` in `settings.yaml` matches the key name in `.env`

**Circuit breaker tripped**
```bash
curl -X POST http://localhost:8080/health/reset-circuit-breaker
# or via Telegram: /reset
```

**News not appearing in logs**
- `CRYPTONEWS_API_KEY` missing → news silently disabled (agent still works)
- Check API key at [cryptonews-api.com](https://cryptonews-api.com) dashboard

**Docker: data not persisting**
- Ensure `./data` directory exists before `docker-compose up` or let Docker create it
- Check `docker-compose.yml` volume mount: `./data:/app/data`
