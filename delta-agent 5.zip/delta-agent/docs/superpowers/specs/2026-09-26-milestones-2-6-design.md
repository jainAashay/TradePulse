# Delta Agent — Milestones 2–6 Design Spec
_Date: 2026-09-26_

## 0. Scope & Baseline

Milestone 1 is complete: config loading, LLM factory (LiteLLM/Gemini), memory protocol + stub, structured logging, entrypoint smoke test.

This spec covers Milestones 2–6 in strict order per the PRD. Each milestone is independently testable before the next begins.

---

## 1. Milestone 2 — Technical Screener & Local Indicators

### 1.1 WebSocket Feed (`screener/feed.py`)

- Uses **native `websockets` library** (not CCXT streaming) against Delta's socket endpoint (`wss://socket-ind.testnet.deltaex.org`).
- Subscribes to `candlestick_1m` and `candlestick_5m` channels for each symbol in the watchlist on connect.
- Implements **auto-reconnect with exponential backoff** (1s → 2s → 4s … cap 60s). Reconnect re-subscribes all channels.
- Emits completed (closed) bars only — ignores in-progress bar updates. A bar is closed when a new bar arrives for the same channel.
- Calls `BarStore.push(symbol, timeframe, bar)` on each closed bar.

### 1.2 Bar Store (`screener/bar_store.py`)

- Per `(symbol, timeframe)` key: a fixed-length `deque` of OHLCV dicts with `maxlen` read from `screener.bar_history_size` (default `200`, configurable in `settings.yaml`).
- Thread-safe via `asyncio.Lock` — feed coroutine writes, indicator computation reads.
- Exposes `get_df(symbol, timeframe) -> pd.DataFrame` returning a copy for safe indicator computation.

### 1.3 Indicator Registry (`screener/indicators.py`)

- Registry maps `(name: str, params: frozenset) -> Callable[[pd.DataFrame], pd.Series]`.
- Built-in indicators: `EMA(length)`, `RSI(length)`, `MACD(fast, slow, signal)`, `Bollinger(length, std)`.
- All implemented with `pandas-ta` (single dependency, vectorised, no TA-Lib C build required).
- Registration is one call: `register_indicator(name, params_dict, fn)`. New indicators require no class hierarchy.
- On each closed bar: `IndicatorRunner.compute(symbol, timeframe) -> dict[str, float]` — returns latest scalar value for each registered indicator for that symbol. Only the last `max(lengths)` bars are passed to each function.

### 1.4 Trigger Gate (`screener/trigger.py`)

- Rules are loaded from `watchlist.yaml` per symbol (e.g., `rsi < 30 AND ema_cross_up`).
- `RuleEvaluator` is a small expression parser over named indicator outputs — supports `<`, `>`, `<=`, `>=`, `==`, `AND`, `OR`, `NOT`, and named cross events (`ema_fast_cross_up`, `ema_fast_cross_down`).
- `evaluate(symbol, timeframe, indicator_values) -> TriggerEvent | None`.
- `TriggerEvent` dataclass: `{symbol, timeframe, timestamp, signals: dict[str, float], rule_matched: str}`.
- Emits `TriggerEvent` into a **deduplicated pending map** per symbol (not a plain queue). Before enqueuing, any existing pending `TriggerEvent` for the same symbol is replaced with the latest — **latest-wins** semantics. The agent loop drains this map one symbol at a time. This prevents backlog buildup and ensures stale signals are never acted on.
- The risk engine provides a second safety net: if a position is already open for a symbol, a new order is blocked regardless.
- **Rate limiting:** max one trigger per `(symbol, timeframe)` per 5-minute window to prevent spam on choppy markets.

---

## 2. Milestone 3 — Agent Loop & Risk Engine

### 2.1 State Machine Orchestrator (`agent/loop.py`)

The agent loop is an `async` function running forever. Each cycle processes one `TriggerEvent`:

```
IDLE → ANALYZING → RISK_CHECK → [EXECUTING | REJECTED] → IDLE
```

- `ANALYZING` and `EXECUTING` states are persisted to SQLite (`analysis_cycles` table, status `IN_FLIGHT`).
- On startup, any `IN_FLIGHT` rows are logged as `CRASHED` and discarded — no re-execution. This prevents double-entry after a crash mid-cycle.
- Errors in any stage are caught, logged with full context, state reset to `IDLE`. The loop never exits on error.

### 2.2 Analyzer (`analyzer/`)

**Context assembly (`analyzer/context.py`):**
1. Pull latest indicator values for the triggered symbol/timeframe from `IndicatorRunner`.
2. Pull cached news sentiment from `NewsCache.get(symbol)` (non-blocking, returns `None` if poller hasn't run yet).
3. Query ChromaDB: `memory.search(query, top_k=rag_top_k)` where `query = f"{symbol} perpetual {timeframe} indicators: RSI={rsi:.1f} trend={'bullish' if ema_cross_up else 'bearish'}"`.
4. Format lessons via `LLMRuntime.format_learnings_for_prompt(records)` — max `max_lesson_chars` per lesson, bullet list.

**Prompt structure (`analyzer/prompts.py`):**
```
[SYSTEM]
You are a disciplined quantitative trading analyst for Delta Exchange perpetual futures.
Your decisions are directly executed on a live account. Be conservative and precise.

## Prior Lessons (from past trades — read these FIRST before reasoning)
{formatted_lessons}          ← RAG-injected, token-capped

## Current Market State
Symbol: {symbol} | Timeframe: {timeframe} | Timestamp: {ts}
Indicators: {indicator_json}
News Sentiment: {sentiment_summary}

## Risk Parameters
Max leverage: {max_leverage}x | Min confidence to trade: {min_confidence}
Max risk per trade: {max_risk_pct}% of equity

[USER]
Analyse the above and produce a trade decision as JSON only. Schema:
{
  "action": "LONG" | "SHORT" | "HOLD",
  "confidence": 0.0–1.0,
  "reasoning": "<chain-of-thought, 2-3 sentences>",
  "leverage": <int>,
  "sl_pct": <float>,           // stop-loss distance as % of entry price
  "tp_pcts": [<float>, ...]    // one or more take-profit levels as % of entry
}
```

- Lessons are placed **at the top of the system prompt**, before market state — this ensures the LLM reads them as prior context before reasoning, not as an afterthought.
- `analyzer/decision.py` parses + validates the JSON via Pydantic `TradeDecision` model. Invalid JSON or schema violation → `REJECTED` with `reason=llm_parse_error`.

### 2.3 Risk Engine (`risk/engine.py`)

Stateless validator. Receives `TradeDecision + RiskState`. Returns `RiskVerdict(approved: bool, reason: str)`.

Hard rules (all must pass):

| Rule | Config key | Default |
|---|---|---|
| `confidence >= min_confidence` | `risk.min_confidence` | 0.65 |
| `leverage <= max_leverage` | `risk.max_leverage` | 20 |
| `open_positions < max_positions` | `risk.max_positions` | 3 |
| `daily_orders < max_orders_per_day` | `risk.max_orders_per_day` | 20 |
| `daily_loss_usd < max_daily_loss_usd` | `risk.max_daily_loss_usd` | 100 |
| `consecutive_losses < max_consecutive_losses` | `risk.max_consecutive_losses` | 3 |
| `circuit_breaker == OFF` | — | — |
| `trading_enabled == true` | Telegram `/pause` / `/resume` | true |

**Position sizing:** Fixed `quantity` and `leverage` per symbol as declared in `watchlist.yaml`. The LLM may suggest a leverage value which is validated against `risk.max_leverage` — the watchlist value is used as the actual order size. No equity-based sizing in this phase.

**Circuit breaker:** When `consecutive_losses >= max_consecutive_losses`, the circuit breaker trips. It halts the analysis loop (trigger events are drained but not processed). Auto-resets at UTC midnight. Also resets on manual `POST /health/reset-circuit-breaker`. Telegram alert sent on trip and reset.

**Daily counter persistence (`risk/state.py`):**
- `RiskState` is persisted in SQLite (`risk_state` table: `date, daily_orders, daily_loss_usd, consecutive_losses, circuit_breaker_active`).
- Loaded on startup. If stored date < today UTC → counters reset to zero.
- Updated atomically after each order placement or trade close.

---

## 3. Milestone 4 — Exchange Integration & Order Execution

### 3.1 Exchange Client (`execution/client.py`)

- **CCXT** (`delta` exchange id) for: account balance, open positions, open orders, cancel order, fetch order status.
- **Delta REST API directly** for: post-only limit entry with bracket (SL + TP) via `POST /v2/orders` with `bracket_stop_loss_price` and `bracket_take_profit_price` fields — CCXT does not expose bracket params today.
- Client wraps both. All calls are `async` (CCXT async mode + `httpx` for Delta-native calls).
- Rate limiting: token bucket, max 10 req/s (Delta testnet limit).
- Auth: API key + secret from env vars `DELTA_API_KEY` / `DELTA_API_SECRET`.

### 3.2 Order Lifecycle (`execution/orders.py`, `execution/manager.py`)

**Order entity (SQLite `orders` table):**
```
id, external_order_id, symbol, side, quantity, leverage,
entry_price, sl_price, tp_prices (JSON array),
status (PENDING | OPEN | FILLED | CANCELLED | CLOSED),
created_at, filled_at, closed_at, pnl_usd
```

**Execution flow:**
1. Compute entry price = current best bid (LONG) or ask (SHORT) from CCXT ticker.
2. Compute SL price and TP prices from `TradeDecision.sl_pct` / `tp_pcts`.
3. Submit bracket order via Delta REST. Persist order with `status=PENDING`.
4. On fill confirmation (polled every 5s): update `status=OPEN`, start reflection detector watch.
5. **Timeout watcher:** `asyncio.Task` per order. After `execution.unfilled_limit_timeout_seconds`, cancel via CCXT if still `PENDING`. Log + Telegram alert.

### 3.3 Startup Reconciliation

On every startup:
1. Fetch open orders from exchange → diff against SQLite `PENDING`/`OPEN` rows.
2. Any exchange order not in SQLite → insert as `OPEN` (orphan recovery).
3. Any SQLite `OPEN` order not on exchange → mark `CLOSED`, trigger reflection pipeline.
4. Re-attach timeout watcher coroutines for all `PENDING` orders.
5. Fetch open positions → update `risk_state.open_positions` count.
6. Recompute `daily_orders` and `daily_loss_usd` from today's `orders` rows (do not trust in-memory state).

---

## 4. Milestone 5 — Vector Memory & Self-Learning Engine

### 4.1 ChromaDB Store (`memory/chroma_store.py`)

- **Embedding model:** `sentence-transformers/all-MiniLM-L6-v2` (local, 22MB, 384-dim, no API cost).
- ChromaDB persistent client, collection `trade_learnings`, stored at `memory.chroma_persist_dir`.
- `add_learning(record: LearningRecord)`: embeds `record.text`, stores with metadata `{symbol, tags, pnl_usd, hold_mins, confidence, created_at}`.
- `search(query, top_k) -> List[LearningRecord]`: ChromaDB cosine similarity search. Returns top-K.
- **Token efficiency contract:** `record.text` is always ≤ `max_lesson_chars` (enforced by `LearningRefiner` before storage). At retrieval, only `text` is injected into the prompt — metadata stays in ChromaDB.

### 4.2 Reflection Pipeline (`reflection/`)

**Closed trade detector (`reflection/detector.py`):**
- Background `asyncio` task polling every 30s.
- Fetches fills/closed positions from exchange for all `OPEN` order ids in SQLite.
- On close detected: fetch PnL, hold duration, slippage (entry vs fill price).
- Emits `ClosedTradeEvent` into reflection queue.

**Post-mortem pipeline (`reflection/pipeline.py`):**
1. Load original `TradeDecision` (reasoning, confidence, indicators) from SQLite.
2. Build reflection prompt: original hypothesis + actual outcome (PnL, duration, slippage, whether SL or TP triggered).
3. Call `LLMBackedLearningRefiner.refine()` → compact lesson ≤ 400 chars.
4. Store in ChromaDB with symbol + outcome tags (`win`/`loss`, `long`/`short`).
5. Update `risk_state.consecutive_losses` (reset on win, increment on loss).
6. Send Telegram alert: trade closed summary (PnL, duration, outcome).

**RAG injection guarantee:** Every analysis cycle queries ChromaDB before building the LLM prompt. Lessons are placed at the top of the system prompt (before market state) so the LLM reads them as prior context. This is not optional — the analyzer always calls `memory.search()` even if the store is empty (returns empty list gracefully).

---

## 5. Milestone 6 — Cloud Hardening & Autonomous Deployment

### 5.1 News Poller (`news/poller.py`)

- Background `asyncio` task, polls CryptoPanic every 5 minutes.
- `NewsCache` is a simple dict `{symbol -> SentimentSummary}` with a last-updated timestamp.
- `SentimentSummary`: `{bullish_count, bearish_count, top_headlines: List[str], fetched_at}`.
- Analyzer reads `NewsCache.get(symbol)` non-blocking. If cache is stale (>15min) or missing, prompt notes "news unavailable" — never blocks analysis.
- CryptoPanic API key is optional — if missing, news poller is disabled silently.

### 5.2 Health Endpoint (`health/server.py`)

- FastAPI app on `:8080`, started as a background `asyncio` task alongside the main loop.
- `GET /health` → `{status, uptime_seconds, open_positions, daily_orders, daily_pnl_usd, circuit_breaker, last_trigger_at, last_trade_at}`.
- `POST /health/reset-circuit-breaker` → resets circuit breaker (manual override, no auth — bind to localhost only in production).

### 5.3 Telegram Alerter & Control (`health/alerter.py`)

- Sends via Telegram Bot API (env vars: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`).
- Alert events:
  - Trade entry (symbol, side, price, SL, TP, leverage)
  - Trade close (symbol, PnL, duration, outcome)
  - Risk rejection (reason)
  - Circuit breaker trip / reset
  - Trading paused / resumed
  - Daily summary at 00:00 UTC (orders placed, PnL, win rate)
  - System errors (WebSocket reconnect, API failure)
- Non-blocking: alerts are fire-and-forget via `asyncio` task. Alert failures are logged but never crash the main loop.

**Telegram Command Handler (`health/telegram_bot.py`):**
- Runs as a background `asyncio` task polling `getUpdates` every 3s.
- Accepted commands (from `TELEGRAM_CHAT_ID` only — all others ignored):
  - `/pause` — sets `trading_enabled = false` in SQLite `agent_config` table. Agent loop drains triggers but executes nothing. Replies: "Trading paused."
  - `/resume` — sets `trading_enabled = true`. Replies: "Trading resumed."
  - `/status` — replies with current state: enabled flag, open positions, daily PnL, circuit breaker status, last trigger timestamp.
  - `/reset` — manually resets circuit breaker (same as `POST /health/reset-circuit-breaker`).
- The `trading_enabled` flag is checked at the start of each trigger processing cycle (after dequeue, before analysis). No redeployment required to toggle.

### 5.4 Docker & Deployment

**Dockerfile:**
- Base: `python:3.12-slim`
- Non-root user `agent`
- `data/` directory declared as `VOLUME` (SQLite + ChromaDB persistence)
- Entrypoint: `supervisord` managing two processes: `delta-agent` (main loop) and `uvicorn` (health server)

**docker-compose.yml:**
- `delta-agent` service with `restart: unless-stopped`
- Volume mount: `./data:/app/data`
- Env file: `.env`
- Port: `8080:8080` (health endpoint, bind to localhost recommended)

**supervisord.conf:**
- `delta-agent` process: `autorestart=true`, `stopwaitsecs=10`
- Logs: stdout captured, rotated daily

---

## 6. SQLite Schema

```sql
-- analysis_cycles: crash recovery for mid-cycle state
CREATE TABLE analysis_cycles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    triggered_at TEXT NOT NULL,
    status TEXT NOT NULL,  -- IN_FLIGHT | COMPLETED | REJECTED | CRASHED
    decision_json TEXT,
    rejection_reason TEXT,
    created_at TEXT NOT NULL
);

-- orders: full order lifecycle
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    external_order_id TEXT UNIQUE,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,       -- buy | sell
    quantity REAL NOT NULL,
    leverage INTEGER NOT NULL,
    entry_price REAL,
    sl_price REAL,
    tp_prices TEXT,           -- JSON array
    status TEXT NOT NULL,     -- PENDING | OPEN | FILLED | CANCELLED | CLOSED
    pnl_usd REAL,
    created_at TEXT NOT NULL,
    filled_at TEXT,
    closed_at TEXT
);

-- risk_state: daily counters (one active row)
CREATE TABLE risk_state (
    date TEXT PRIMARY KEY,
    daily_orders INTEGER NOT NULL DEFAULT 0,
    daily_loss_usd REAL NOT NULL DEFAULT 0.0,
    consecutive_losses INTEGER NOT NULL DEFAULT 0,
    circuit_breaker_active INTEGER NOT NULL DEFAULT 0
);

-- agent_config: runtime-mutable flags (Telegram kill switch etc.)
CREATE TABLE agent_config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
-- Seed row: INSERT OR IGNORE INTO agent_config VALUES ('trading_enabled', 'true', datetime('now'));
```

---

## 7. Dependency Additions

```
# settings.yaml additions under screener:
# screener:
#   bar_history_size: 200   ← controls deque maxlen in BarStore
#   trigger_cooldown_minutes: 5

# requirements.txt additions
websockets>=12.0          # native WS feed
pandas>=2.1               # OHLCV bar store
pandas-ta>=0.3.14b        # indicators (no TA-Lib C build)
ccxt>=4.3                 # exchange client
httpx>=0.27               # Delta-native REST calls (bracket orders)
chromadb>=0.5             # vector store
sentence-transformers>=3.0  # local embeddings (all-MiniLM-L6-v2)
fastapi>=0.111            # health endpoint
uvicorn>=0.29             # ASGI server for health
httpx>=0.27               # async HTTP (news poller + Telegram)
supervisor>=4.2           # process management (Docker only)
```

---

## 8. Success Criteria per Milestone

| Milestone | Done when |
|---|---|
| M2 | WebSocket connects, bars arrive, indicators compute, `TriggerEvent` emitted to queue for BTCUSD |
| M3 | Full cycle: trigger → LLM decision → risk check → logged result (no exchange call yet) |
| M4 | Bracket order placed on testnet, timeout watcher fires, reconciliation runs on restart |
| M5 | Closed trade produces a lesson in ChromaDB; next analysis for same symbol retrieves it in prompt |
| M6 | Docker container runs 24/7, health endpoint responds, Telegram alert fires on trade |
